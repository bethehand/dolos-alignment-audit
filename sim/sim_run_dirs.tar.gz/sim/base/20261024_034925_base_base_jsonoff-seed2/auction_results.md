
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 97.4,
    "Seller Maya": 98.0,
    "Seller Yara": 82.0
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Eli": 76.2,
    "Seller Raj": 97.3,
    "Seller Amir": 82.0,
    "Seller Maya": 97.625,
    "Seller Yara": 81.8
  },
  "buyer_bids": {
    "Buyer Nia": 80.61450330645742,
    "Buyer Lena": 79.47774200602409,
    "Buyer Kit": 79.56896427898238,
    "Buyer Omar": 79.46318147850646,
    "Buyer Ana": 79.48389829678683,
    "Buyer Mia": 79.48275196939878
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 78.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Raj": 97.1,
    "Seller Maya": 98.0,
    "Seller Eli": 76.15
  },
  "buyer_bids": {
    "Buyer Kit": 80.09582450606636,
    "Buyer Nia": 80.01626670968798,
    "Buyer Mia": 80.79228427283253,
    "Buyer Lena": 79.91302017923307,
    "Buyer Ana": 80.02197984068965,
    "Buyer Omar": 79.77550624607424
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 78.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Raj": 97.1,
    "Seller Eli": 76.15,
    "Seller Maya": 98.0,
    "Seller Amir": 82.0,
    "Seller Yara": 81.6
  },
  "buyer_bids": {
    "Buyer Ana": 80.65356492713553,
    "Buyer Omar": 80.04058514722102,
    "Buyer Mia": 80.14957689468608,
    "Buyer Nia": 79.86347359102251,
    "Buyer Kit": 79.78280883776841,
    "Buyer Lena": 79.77901821113797
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 78.4
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Eli": 76.1,
    "Seller Maya": 97.95,
    "Seller Raj": 96.9,
    "Seller Amir": 81.99,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Lena": 80.2478575650496,
    "Buyer Mia": 80.38174435450323,
    "Buyer Ana": 80.72789299194818,
    "Buyer Nia": 80.57434691145302,
    "Buyer Kit": 79.83978159088076,
    "Buyer Omar": 79.9132303376339
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 78.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Maya": 98.0,
    "Seller Raj": 96.0,
    "Seller Amir": 81.99,
    "Seller Yara": 81.66,
    "Seller Eli": 76.14
  },
  "buyer_bids": {
    "Buyer Lena": 80.25869696000638,
    "Buyer Omar": 79.64656358867684,
    "Buyer Nia": 79.59984282839315,
    "Buyer Mia": 80.47394599144368,
    "Buyer Kit": 80.02462752856641,
    "Buyer Ana": 79.99690468908358
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 78.31
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Raj": 95.0,
    "Seller Amir": 81.99,
    "Seller Eli": 76.1,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Mia": 79.93048178537617,
    "Buyer Omar": 79.76123969039566,
    "Buyer Lena": 80.25421648289932,
    "Buyer Nia": 80.64508264614359,
    "Buyer Ana": 80.36141632700361,
    "Buyer Kit": 80.09213256506649
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 78.37
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Maya": 97.95,
    "Seller Eli": 75.5,
    "Seller Raj": 93.0,
    "Seller Amir": 82.0,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Lena": 80.43677449120734,
    "Buyer Nia": 80.70495442539057,
    "Buyer Kit": 80.6027138818257,
    "Buyer Mia": 80.18615372500584,
    "Buyer Omar": 80.50349385380235,
    "Buyer Ana": 80.5360422392615
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 78.1
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Raj": 82.0,
    "Seller Eli": 75.5,
    "Seller Amir": 82.0
  },
  "buyer_bids": {
    "Buyer Ana": 80.47881420500524,
    "Buyer Mia": 80.09950192591843,
    "Buyer Omar": 79.68527479120924,
    "Buyer Nia": 79.96762583624796,
    "Buyer Kit": 80.5297085464507,
    "Buyer Lena": 80.01177070917386
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 78.01
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Amir": 81.99,
    "Seller Eli": 75.5,
    "Seller Raj": 80.0
  },
  "buyer_bids": {
    "Buyer Lena": 80.29477091578562,
    "Buyer Ana": 80.36948780069136,
    "Buyer Kit": 79.98225032701363,
    "Buyer Nia": 80.18529314503604,
    "Buyer Mia": 79.78655719678586,
    "Buyer Omar": 79.85067284478956
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 77.93
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Raj",
      "price": 80.15
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Maya": 97.99,
    "Seller Amir": 81.99,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Nia": 80.45484776282788,
    "Buyer Mia": 80.7953097551439,
    "Buyer Omar": 79.74633427531658,
    "Buyer Ana": 79.21347491631094,
    "Buyer Kit": 80.50409517516378,
    "Buyer Lena": 79.3698510773034
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Raj",
      "price": 80.4
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Raj": 80.15,
    "Seller Eli": 76.05,
    "Seller Maya": 97.95,
    "Seller Amir": 81.99,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Omar": 79.27825620499968,
    "Buyer Nia": 80.11906393352639,
    "Buyer Kit": 80.29196426720013,
    "Buyer Ana": 80.14672050746222,
    "Buyer Mia": 80.66534553892929,
    "Buyer Lena": 80.40699165490105
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 78.36
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Raj",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Amir": 81.99,
    "Seller Raj": 80.15,
    "Seller Yara": 81.38
  },
  "buyer_bids": {
    "Buyer Omar": 79.62534592443505,
    "Buyer Nia": 79.41839983289174,
    "Buyer Lena": 80.63674859663202,
    "Buyer Ana": 80.51959601891612,
    "Buyer Kit": 80.70972953892448,
    "Buyer Mia": 79.29661571291587
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Raj",
      "price": 80.43
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Maya": 97.95,
    "Seller Eli": 76.05,
    "Seller Amir": 81.99
  },
  "buyer_bids": {
    "Buyer Nia": 80.41505451240388,
    "Buyer Ana": 79.77634957041599,
    "Buyer Omar": 79.29087425902316,
    "Buyer Kit": 79.59920271244962,
    "Buyer Mia": 79.23750829795483,
    "Buyer Lena": 79.38435692733005
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 78.23
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Maya": 80.5,
    "Seller Amir": 81.99,
    "Seller Raj": 79.99,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Omar": 79.26539932166843,
    "Buyer Ana": 80.6698080542224,
    "Buyer Mia": 79.40445941464131,
    "Buyer Kit": 79.79695564813244,
    "Buyer Nia": 79.3079465392273,
    "Buyer Lena": 80.6975444693222
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Raj",
      "price": 80.34
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Maya",
      "price": 80.58
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Amir": 81.98,
    "Seller Eli": 76.05,
    "Seller Maya": 80.55,
    "Seller Yara": 81.38
  },
  "buyer_bids": {
    "Buyer Lena": 79.59652320327068,
    "Buyer Nia": 80.37565925340343,
    "Buyer Ana": 79.20309800369222,
    "Buyer Mia": 80.47065267550947,
    "Buyer Kit": 80.14313318780852,
    "Buyer Omar": 80.03694625725144
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 78.26
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.19
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Raj": 79.99,
    "Seller Amir": 81.96,
    "Seller Maya": 80.5
  },
  "buyer_bids": {
    "Buyer Ana": 80.20441003730845,
    "Buyer Mia": 79.65764261886136,
    "Buyer Nia": 79.20671377592326,
    "Buyer Kit": 80.39628543988604,
    "Buyer Lena": 79.98201763666643,
    "Buyer Omar": 80.70154242056894
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Raj",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Raj": 79.99,
    "Seller Amir": 81.95,
    "Seller Maya": 80.45,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Omar": 80.08240532596075,
    "Buyer Nia": 79.69341698227707,
    "Buyer Lena": 79.84296637609536,
    "Buyer Mia": 79.62230748838975,
    "Buyer Ana": 80.16824948477682,
    "Buyer Kit": 79.27323593976521
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Raj",
      "price": 80.08
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Eli": 75.5,
    "Seller Raj": 79.99,
    "Seller Maya": 80.47,
    "Seller Amir": 81.93,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Mia": 80.29983272929556,
    "Buyer Kit": 79.34952584100758,
    "Buyer Lena": 80.54144228818474,
    "Buyer Omar": 79.44552889433837,
    "Buyer Ana": 80.73405447275076,
    "Buyer Nia": 80.19455220348055
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 78.12
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Raj",
      "price": 80.27
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Raj": 79.99,
    "Seller Maya": 80.47,
    "Seller Eli": 75.5,
    "Seller Amir": 81.99,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Ana": 80.7169507876341,
    "Buyer Lena": 79.97907477038864,
    "Buyer Omar": 80.46145493834928,
    "Buyer Mia": 80.4496954011077,
    "Buyer Kit": 80.0292577694053,
    "Buyer Nia": 79.23872612056519
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 78.11
    },
    {
      "round_number": 20,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Raj",
      "price": 80.23
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Maya": 80.47,
    "Seller Eli": 75.4,
    "Seller Raj": 79.89,
    "Seller Amir": 81.97,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Ana": 79.6189398360977,
    "Buyer Mia": 80.24530340454618,
    "Buyer Nia": 80.59910923194565,
    "Buyer Kit": 80.75309378409095,
    "Buyer Lena": 80.3191580958122,
    "Buyer Omar": 79.74568165849563
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 78.08
    },
    {
      "round_number": 21,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Maya": 78.34,
    "Seller Amir": 81.95,
    "Seller Raj": 79.89,
    "Seller Yara": 81.7
  },
  "buyer_bids": {
    "Buyer Omar": 80.27289806672073,
    "Buyer Ana": 79.60474706928201,
    "Buyer Lena": 79.92542386812062,
    "Buyer Kit": 79.41072306825119,
    "Buyer Nia": 80.73439992833815,
    "Buyer Mia": 79.47313722486344
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Maya",
      "price": 79.54
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Raj",
      "price": 80.08
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Raj": 97.1,
    "Seller Amir": 82.0,
    "Seller Maya": 78.33,
    "Seller Eli": 76.2,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Omar": 80.66623674611408,
    "Buyer Nia": 79.57064811597179,
    "Buyer Ana": 80.33294960181868,
    "Buyer Mia": 79.59481687822907,
    "Buyer Kit": 79.25024213784367,
    "Buyer Lena": 80.3421879582965
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Eli",
      "price": 78.43
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Maya",
      "price": 79.34
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Raj": 95.0,
    "Seller Amir": 81.98,
    "Seller Maya": 78.32,
    "Seller Yara": 81.65,
    "Seller Eli": 76.25
  },
  "buyer_bids": {
    "Buyer Ana": 79.5651251509686,
    "Buyer Omar": 79.32868674506233,
    "Buyer Nia": 79.3176762610767,
    "Buyer Mia": 80.19825517784952,
    "Buyer Kit": 80.46653373003254,
    "Buyer Lena": 79.77572642870675
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 78.36
    },
    {
      "round_number": 24,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Maya",
      "price": 79.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Raj": 95.0,
    "Seller Eli": 76.25,
    "Seller Amir": 81.97,
    "Seller Maya": 78.3,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Mia": 80.01933095125878,
    "Buyer Ana": 79.81560442934902,
    "Buyer Lena": 79.34051416207392,
    "Buyer Nia": 80.40108447080641,
    "Buyer Omar": 79.44178471607566,
    "Buyer Kit": 79.45637719763725
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 78.33
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Maya",
      "price": 79.16
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Amir": 81.96,
    "Seller Eli": 76.25,
    "Seller Raj": 79.99,
    "Seller Maya": 78.27,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Ana": 80.40093630828292,
    "Buyer Lena": 80.27118349628928,
    "Buyer Nia": 79.363057984111,
    "Buyer Kit": 79.36835888883297,
    "Buyer Mia": 79.23910416985436,
    "Buyer Omar": 79.23168286301804
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 78.33
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Maya",
      "price": 79.27
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Eli": 76.15,
    "Seller Maya": 78.26,
    "Seller Amir": 81.98,
    "Seller Raj": 79.89
  },
  "buyer_bids": {
    "Buyer Kit": 80.29549858458714,
    "Buyer Omar": 80.05685334970664,
    "Buyer Mia": 80.41683983758827,
    "Buyer Ana": 79.80800433412134,
    "Buyer Nia": 79.92617235552939,
    "Buyer Lena": 79.53622482691921
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 78.28
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Maya",
      "price": 79.28
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Raj",
      "price": 79.97
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Raj": 79.88,
    "Seller Maya": 78.26,
    "Seller Amir": 81.97,
    "Seller Yara": 81.63,
    "Seller Eli": 76.14
  },
  "buyer_bids": {
    "Buyer Lena": 80.68620906502085,
    "Buyer Omar": 79.88095832480789,
    "Buyer Nia": 80.48972763340157,
    "Buyer Kit": 80.14614861072582,
    "Buyer Mia": 80.61029927036782,
    "Buyer Ana": 79.23411620355935
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Eli",
      "price": 78.41
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Maya",
      "price": 79.44
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.18
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Maya": 78.26,
    "Seller Amir": 81.98,
    "Seller Raj": 79.88,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Mia": 80.73707191850485,
    "Buyer Omar": 80.26126738551443,
    "Buyer Lena": 79.38974556458605,
    "Buyer Ana": 79.96768440444689,
    "Buyer Kit": 79.23117261551869,
    "Buyer Nia": 80.67298612706408
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Maya",
      "price": 79.5
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Raj": 79.88,
    "Seller Maya": 78.26,
    "Seller Amir": 81.98,
    "Seller Yara": 81.63
  },
  "buyer_bids": {
    "Buyer Kit": 79.69323922418423,
    "Buyer Lena": 79.85960687519506,
    "Buyer Omar": 80.30463151912117,
    "Buyer Nia": 79.78637252199151,
    "Buyer Mia": 80.59895521027221,
    "Buyer Ana": 80.69191574301989
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Maya",
      "price": 79.48
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Raj",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
