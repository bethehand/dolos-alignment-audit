
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Tara": 80.1,
    "Seller Kai": 80.0,
    "Seller Mia": 80.0,
    "Seller Eli": 80.0
  },
  "buyer_bids": {
    "Buyer Max": 80.09570188642384,
    "Buyer Jin": 79.31798789380596,
    "Buyer Amir": 79.35802135145464,
    "Buyer Leo": 79.76606612723079,
    "Buyer Nia": 80.56075812201482,
    "Buyer Jun": 79.7283155497568
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 80.28
    },
    {
      "round_number": 1,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Kai",
      "price": 80.05
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Kai": 80.05,
    "Seller Eli": 80.01,
    "Seller Mia": 80.0,
    "Seller Raj": 80.0,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Nia": 79.5271643992258,
    "Buyer Amir": 79.70591471923454,
    "Buyer Leo": 80.034165814644,
    "Buyer Max": 79.90830937463414,
    "Buyer Jun": 80.08403788181555,
    "Buyer Jin": 80.22467744246734
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.11
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.04
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.02
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Kai": 80.1,
    "Seller Tara": 80.15,
    "Seller Mia": 80.0,
    "Seller Raj": 80.05,
    "Seller Eli": 80.28
  },
  "buyer_bids": {
    "Buyer Jin": 80.66954383312105,
    "Buyer Nia": 80.66559116857101,
    "Buyer Amir": 79.29964734083447,
    "Buyer Max": 80.54414594648867,
    "Buyer Jun": 79.34923498296386,
    "Buyer Leo": 80.33640547781998
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.33
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.36
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Kai",
      "price": 80.32
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Kai": 80.2,
    "Seller Tara": 80.0,
    "Seller Mia": 80.0,
    "Seller Eli": 80.28,
    "Seller Raj": 80.05
  },
  "buyer_bids": {
    "Buyer Max": 79.73301621966256,
    "Buyer Leo": 80.36844572216516,
    "Buyer Nia": 80.17903533570264,
    "Buyer Jun": 80.52490124544624,
    "Buyer Jin": 80.20042532683782,
    "Buyer Amir": 80.45607641539758
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.26
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Tara",
      "price": 80.23
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.21
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Kai",
      "price": 80.2
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Kai": 80.24,
    "Seller Tara": 80.0,
    "Seller Mia": 80.02,
    "Seller Raj": 80.05,
    "Seller Eli": 80.3
  },
  "buyer_bids": {
    "Buyer Leo": 79.42799103025412,
    "Buyer Jun": 79.5547262339427,
    "Buyer Max": 80.48535208663392,
    "Buyer Amir": 80.32582807386483,
    "Buyer Jin": 79.30077483881792,
    "Buyer Nia": 80.6672303505839
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Tara",
      "price": 80.33
    },
    {
      "round_number": 5,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.25
    },
    {
      "round_number": 5,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 80.19
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Raj": 80.06,
    "Seller Tara": 80.0,
    "Seller Kai": 80.3,
    "Seller Eli": 80.35,
    "Seller Mia": 80.02
  },
  "buyer_bids": {
    "Buyer Leo": 79.98285884987185,
    "Buyer Amir": 80.06878393230402,
    "Buyer Jin": 79.34594552612836,
    "Buyer Max": 80.7967546097378,
    "Buyer Jun": 80.60013965973783,
    "Buyer Nia": 80.78915448570316
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Tara",
      "price": 80.4
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.4
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.33
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Raj": 80.06,
    "Seller Kai": 80.08,
    "Seller Eli": 80.35,
    "Seller Tara": 80.0,
    "Seller Mia": 80.02
  },
  "buyer_bids": {
    "Buyer Jun": 79.73240082042774,
    "Buyer Leo": 79.52512296395109,
    "Buyer Max": 80.67559956956248,
    "Buyer Jin": 79.6657450760193,
    "Buyer Amir": 79.68231486739239,
    "Buyer Nia": 79.39969714340498
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Tara",
      "price": 80.34
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Raj": 80.06,
    "Seller Eli": 80.35,
    "Seller Tara": 80.1,
    "Seller Kai": 80.25
  },
  "buyer_bids": {
    "Buyer Jin": 80.07556817039986,
    "Buyer Leo": 79.70727495641293,
    "Buyer Max": 80.47669603091362,
    "Buyer Jun": 79.34661135192259,
    "Buyer Amir": 80.47908337835295,
    "Buyer Nia": 79.66025162273633
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Mia",
      "price": 80.25
    },
    {
      "round_number": 8,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.27
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Eli": 80.34,
    "Seller Raj": 80.05,
    "Seller Tara": 80.0,
    "Seller Kai": 80.3,
    "Seller Mia": 80.0
  },
  "buyer_bids": {
    "Buyer Jin": 80.77007958479713,
    "Buyer Leo": 79.40835912080729,
    "Buyer Max": 80.28595833489422,
    "Buyer Nia": 79.61608993383086,
    "Buyer Jun": 79.31053639757424,
    "Buyer Amir": 79.2527558638188
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.39
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Tara",
      "price": 80.14
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Raj": 80.05,
    "Seller Eli": 80.33,
    "Seller Tara": 80.05,
    "Seller Mia": 80.0
  },
  "buyer_bids": {
    "Buyer Leo": 80.29359741677398,
    "Buyer Jin": 79.26182651331973,
    "Buyer Max": 80.52697737861395,
    "Buyer Amir": 79.43928053287722,
    "Buyer Jun": 80.31891648677686,
    "Buyer Nia": 79.32839730856625
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.26
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.18
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.17
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Eli": 80.33,
    "Seller Kai": 80.12,
    "Seller Tara": 80.08,
    "Seller Raj": 80.06,
    "Seller Mia": 80.0
  },
  "buyer_bids": {
    "Buyer Jin": 79.57680277644975,
    "Buyer Leo": 79.87107718681925,
    "Buyer Nia": 79.54432207220839,
    "Buyer Amir": 80.0348641611532,
    "Buyer Max": 80.52042127787786,
    "Buyer Jun": 80.28715897309542
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.26
    },
    {
      "round_number": 11,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.17
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Kai": 80.0,
    "Seller Eli": 80.33,
    "Seller Mia": 80.0,
    "Seller Raj": 80.04,
    "Seller Tara": 80.11
  },
  "buyer_bids": {
    "Buyer Leo": 79.77178807356802,
    "Buyer Max": 80.77193661681801,
    "Buyer Amir": 79.64033730567172,
    "Buyer Jin": 79.98824861836725,
    "Buyer Nia": 80.22591491933177,
    "Buyer Jun": 80.32036083837679
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Kai",
      "price": 80.39
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.16
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.13
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Eli": 80.33,
    "Seller Mia": 80.0,
    "Seller Raj": 80.1,
    "Seller Tara": 80.11,
    "Seller Kai": 79.9
  },
  "buyer_bids": {
    "Buyer Jun": 79.73643276506755,
    "Buyer Jin": 79.38455958946281,
    "Buyer Amir": 79.71891974941234,
    "Buyer Max": 79.50460615447801,
    "Buyer Nia": 80.13931952274021,
    "Buyer Leo": 79.2259344426571
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.02
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Raj": 80.06,
    "Seller Kai": 79.8,
    "Seller Eli": 80.33,
    "Seller Mia": 80.0,
    "Seller Tara": 80.1
  },
  "buyer_bids": {
    "Buyer Jin": 79.79529630892972,
    "Buyer Leo": 80.45298961575457,
    "Buyer Amir": 80.32853298450065,
    "Buyer Nia": 79.47277083793325,
    "Buyer Jun": 79.88180981655017,
    "Buyer Max": 79.29950792909393
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.13
    },
    {
      "round_number": 14,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Mia",
      "price": 80.16
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Kai": 80.05,
    "Seller Raj": 80.06,
    "Seller Eli": 80.33,
    "Seller Tara": 80.1,
    "Seller Mia": 80.0
  },
  "buyer_bids": {
    "Buyer Leo": 80.16347277975784,
    "Buyer Amir": 80.56851619121636,
    "Buyer Nia": 80.5073924848302,
    "Buyer Jin": 79.55003769451659,
    "Buyer Jun": 80.21473026168366,
    "Buyer Max": 80.69843154590366
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.35
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Kai",
      "price": 80.31
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.28
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Tara",
      "price": 80.16
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Raj": 80.06,
    "Seller Mia": 80.0,
    "Seller Kai": 80.05,
    "Seller Eli": 80.33,
    "Seller Tara": 80.05
  },
  "buyer_bids": {
    "Buyer Jin": 79.50163299568102,
    "Buyer Nia": 80.52813780994359,
    "Buyer Amir": 79.39910995525122,
    "Buyer Jun": 79.39151275624286,
    "Buyer Leo": 80.53415108895918,
    "Buyer Max": 79.34645096504855
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Mia",
      "price": 80.27
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.29
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Eli": 80.33,
    "Seller Raj": 80.06,
    "Seller Kai": 80.05,
    "Seller Mia": 80.0,
    "Seller Tara": 80.09
  },
  "buyer_bids": {
    "Buyer Nia": 79.51134552909173,
    "Buyer Jin": 80.16880667235418,
    "Buyer Amir": 79.38567382140627,
    "Buyer Max": 80.34898132233495,
    "Buyer Jun": 80.75310706120696,
    "Buyer Leo": 79.96677384627553
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.38
    },
    {
      "round_number": 17,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Kai",
      "price": 80.2
    },
    {
      "round_number": 17,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.11
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Mia": 80.0,
    "Seller Raj": 80.09,
    "Seller Eli": 80.33,
    "Seller Kai": 80.05
  },
  "buyer_bids": {
    "Buyer Jun": 80.07077665836357,
    "Buyer Nia": 80.28695551184157,
    "Buyer Jin": 79.29773583337033,
    "Buyer Max": 80.19295995356441,
    "Buyer Amir": 80.36344836712773,
    "Buyer Leo": 80.53744424891377
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Mia",
      "price": 80.27
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Kai",
      "price": 80.21
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.19
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Tara",
      "price": 80.14
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Raj": 80.09,
    "Seller Eli": 80.33,
    "Seller Mia": 80.0,
    "Seller Kai": 80.05,
    "Seller Tara": 80.09
  },
  "buyer_bids": {
    "Buyer Leo": 79.82604191540904,
    "Buyer Jin": 79.2976679027514,
    "Buyer Amir": 79.89770983672521,
    "Buyer Max": 80.31891700015349,
    "Buyer Nia": 79.94740996407722,
    "Buyer Jun": 80.15437587619927
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.16
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.1
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Mia": 80.0,
    "Seller Raj": 80.1,
    "Seller Eli": 80.33,
    "Seller Kai": 80.05,
    "Seller Tara": 80.09
  },
  "buyer_bids": {
    "Buyer Jun": 80.64368677042106,
    "Buyer Jin": 80.64703781284807,
    "Buyer Amir": 79.61621320675081,
    "Buyer Max": 80.11162966691762,
    "Buyer Leo": 80.3163153132515,
    "Buyer Nia": 79.95234585807712
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.32
    },
    {
      "round_number": 20,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.35
    },
    {
      "round_number": 20,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.2
    },
    {
      "round_number": 20,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.11
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Mia": 80.0,
    "Seller Raj": 80.1,
    "Seller Kai": 79.95,
    "Seller Eli": 80.15,
    "Seller Tara": 80.09
  },
  "buyer_bids": {
    "Buyer Leo": 80.04715875686034,
    "Buyer Amir": 79.52546349723994,
    "Buyer Nia": 80.46183726401568,
    "Buyer Max": 79.45912651231662,
    "Buyer Jun": 79.45313380772382,
    "Buyer Jin": 80.42775734732211
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.21
    },
    {
      "round_number": 21,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Kai": 80.05,
    "Seller Mia": 80.0,
    "Seller Raj": 80.1,
    "Seller Eli": 80.14,
    "Seller Tara": 80.09
  },
  "buyer_bids": {
    "Buyer Nia": 79.22112601365596,
    "Buyer Jun": 80.29004908096678,
    "Buyer Jin": 80.2649693152287,
    "Buyer Leo": 80.59968751083136,
    "Buyer Amir": 80.67426943114178,
    "Buyer Max": 80.64015688382523
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Mia",
      "price": 80.34
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Kai",
      "price": 80.35
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.34
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.2
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Eli",
      "price": 80.2
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Raj": 80.09,
    "Seller Kai": 80.04,
    "Seller Eli": 80.14,
    "Seller Tara": 80.16,
    "Seller Mia": 80.06
  },
  "buyer_bids": {
    "Buyer Leo": 80.30531641259714,
    "Buyer Nia": 79.82182758853031,
    "Buyer Amir": 80.66801779641445,
    "Buyer Jin": 80.23829358049811,
    "Buyer Max": 79.44546043349028,
    "Buyer Jun": 80.25218591989199
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Kai",
      "price": 80.35
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Mia",
      "price": 80.18
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.17
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Eli",
      "price": 80.19
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Mia": 80.0,
    "Seller Eli": 80.28,
    "Seller Raj": 80.09,
    "Seller Tara": 80.18
  },
  "buyer_bids": {
    "Buyer Jun": 79.97092333259852,
    "Buyer Nia": 80.41946664992724,
    "Buyer Max": 80.17621704683158,
    "Buyer Jin": 79.4157401709572,
    "Buyer Leo": 80.27744553517343,
    "Buyer Amir": 80.07091119624236
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.21
    },
    {
      "round_number": 24,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.18
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Kai": 80.05,
    "Seller Mia": 80.0,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Max": 79.69647613034269,
    "Buyer Amir": 80.14444429811127,
    "Buyer Jin": 80.62710966627296,
    "Buyer Jun": 79.41175084967159,
    "Buyer Leo": 80.39757740991615,
    "Buyer Nia": 80.56603900934549
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.31
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.31
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.27
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Tara": 80.15,
    "Seller Kai": 80.09,
    "Seller Mia": 80.0,
    "Seller Eli": 80.28,
    "Seller Raj": 80.09
  },
  "buyer_bids": {
    "Buyer Amir": 79.91701652262984,
    "Buyer Leo": 80.5947011077622,
    "Buyer Max": 79.25047276499589,
    "Buyer Jun": 80.59926023977286,
    "Buyer Nia": 80.2780403204936,
    "Buyer Jin": 80.33655996174124
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.3
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.34
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.21
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Tara",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Kai": 80.09,
    "Seller Raj": 80.09,
    "Seller Mia": 80.0,
    "Seller Eli": 80.3,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Jin": 80.4354971487784,
    "Buyer Nia": 80.33440965469813,
    "Buyer Jun": 79.46507995659533,
    "Buyer Max": 79.30221809457811,
    "Buyer Leo": 80.32242586800679,
    "Buyer Amir": 80.10795574686797
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.22
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.21
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Kai": 80.1,
    "Seller Mia": 80.0,
    "Seller Eli": 80.3,
    "Seller Raj": 80.09,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Max": 79.20011066059917,
    "Buyer Nia": 80.65286377145534,
    "Buyer Jun": 80.16636382049899,
    "Buyer Jin": 80.61591281279641,
    "Buyer Amir": 79.91418353948085,
    "Buyer Leo": 79.26225629442433
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.33
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.35
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.13
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Mia": 80.0,
    "Seller Kai": 80.12,
    "Seller Raj": 80.09,
    "Seller Tara": 80.15,
    "Seller Eli": 80.3
  },
  "buyer_bids": {
    "Buyer Jun": 80.51635187715311,
    "Buyer Nia": 79.27977119456584,
    "Buyer Leo": 79.86421985850336,
    "Buyer Jin": 80.54037894567124,
    "Buyer Amir": 79.72151024713585,
    "Buyer Max": 80.75868301167984
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.38
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.32
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.32
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Mia": 80.0,
    "Seller Eli": 80.3,
    "Seller Raj": 80.09,
    "Seller Tara": 80.15,
    "Seller Kai": 80.13
  },
  "buyer_bids": {
    "Buyer Nia": 80.53991742999023,
    "Buyer Jun": 79.4088348029473,
    "Buyer Jin": 80.76571480135283,
    "Buyer Amir": 80.74086043397294,
    "Buyer Max": 79.22356685879012,
    "Buyer Leo": 80.71927605484146
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.38
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 80.42
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.42
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Tara",
      "price": 80.34
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
