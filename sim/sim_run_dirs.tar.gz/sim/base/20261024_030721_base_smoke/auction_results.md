
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Nia": 98.04
  },
  "buyer_bids": {
    "Buyer Jin": 79.77287899951199,
    "Buyer Amir": 80.74847999187227
  },
  "trades": [],
  "seller_messages": {
    "Seller Nia": "No message to send."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Jun": 80.0,
    "Seller Nia": 98.06
  },
  "buyer_bids": {
    "Buyer Amir": 80.62665705571308,
    "Buyer Jin": 79.54950836306436
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Jun",
      "price": 80.31
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Jun": 80.0,
    "Seller Nia": 98.06
  },
  "buyer_bids": {
    "Buyer Jin": 79.42359325594668,
    "Buyer Amir": 79.42283792831704
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
