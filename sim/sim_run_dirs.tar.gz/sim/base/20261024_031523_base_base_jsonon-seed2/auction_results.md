
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 97.9,
    "Seller Maya": 97.34,
    "Seller Eli": 97.0,
    "Seller Yara": 96.25
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Eli": 97.0,
    "Seller Raj": 97.9,
    "Seller Amir": 97.5,
    "Seller Yara": 96.3
  },
  "buyer_bids": {
    "Buyer Omar": 79.46318147850646,
    "Buyer Mia": 79.48275196939878,
    "Buyer Kit": 79.56896427898238,
    "Buyer Nia": 80.61450330645742,
    "Buyer Ana": 79.48389829678683,
    "Buyer Lena": 79.47774200602409
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Amir": 97.36,
    "Seller Raj": 97.9,
    "Seller Yara": 96.32,
    "Seller Maya": 97.25
  },
  "buyer_bids": {
    "Buyer Mia": 80.79228427283253,
    "Buyer Lena": 79.91302017923307,
    "Buyer Nia": 80.01626670968798,
    "Buyer Ana": 80.02197984068965,
    "Buyer Omar": 79.77550624607424,
    "Buyer Kit": 80.09582450606636
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Raj": 97.9,
    "Seller Amir": 97.36,
    "Seller Yara": 96.35,
    "Seller Maya": 97.23,
    "Seller Eli": 97.0
  },
  "buyer_bids": {
    "Buyer Nia": 79.86347359102251,
    "Buyer Omar": 80.04058514722102,
    "Buyer Mia": 80.14957689468608,
    "Buyer Lena": 79.77901821113797,
    "Buyer Kit": 79.78280883776841,
    "Buyer Ana": 80.65356492713553
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Amir": 97.36,
    "Seller Yara": 96.37,
    "Seller Maya": 97.45,
    "Seller Eli": 96.95,
    "Seller Raj": 97.9
  },
  "buyer_bids": {
    "Buyer Ana": 80.72789299194818,
    "Buyer Kit": 79.83978159088076,
    "Buyer Omar": 79.9132303376339,
    "Buyer Nia": 80.57434691145302,
    "Buyer Mia": 80.38174435450323,
    "Buyer Lena": 80.2478575650496
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Amir": 97.36,
    "Seller Raj": 97.9,
    "Seller Eli": 96.4,
    "Seller Maya": 97.55,
    "Seller Yara": 96.38
  },
  "buyer_bids": {
    "Buyer Ana": 79.99690468908358,
    "Buyer Kit": 80.02462752856641,
    "Buyer Nia": 79.59984282839315,
    "Buyer Omar": 79.64656358867684,
    "Buyer Mia": 80.47394599144368,
    "Buyer Lena": 80.25869696000638
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Eli": 96.4,
    "Seller Amir": 97.36,
    "Seller Maya": 97.54,
    "Seller Raj": 97.9
  },
  "buyer_bids": {
    "Buyer Mia": 80.09213256506649,
    "Buyer Nia": 79.92750205874086,
    "Buyer Omar": 80.64508264614359,
    "Buyer Kit": 80.36141632700361,
    "Buyer Ana": 79.76123969039566,
    "Buyer Lena": 79.93048178537617
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Amir": 97.36,
    "Seller Eli": 96.7,
    "Seller Yara": 96.39,
    "Seller Raj": 97.9,
    "Seller Maya": 97.56
  },
  "buyer_bids": {
    "Buyer Mia": 80.6027138818257,
    "Buyer Nia": 80.25421648289932,
    "Buyer Ana": 80.50349385380235,
    "Buyer Lena": 80.18615372500584,
    "Buyer Omar": 80.70495442539057,
    "Buyer Kit": 80.5360422392615
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Raj": 97.9,
    "Seller Amir": 97.36,
    "Seller Eli": 96.6,
    "Seller Maya": 97.56,
    "Seller Yara": 96.4
  },
  "buyer_bids": {
    "Buyer Nia": 80.43677449120734,
    "Buyer Lena": 80.09950192591843,
    "Buyer Mia": 80.5297085464507,
    "Buyer Omar": 79.96762583624796,
    "Buyer Ana": 79.68527479120924,
    "Buyer Kit": 80.47881420500524
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Amir": 97.36,
    "Seller Eli": 96.6,
    "Seller Yara": 96.41,
    "Seller Maya": 97.56,
    "Seller Raj": 97.9
  },
  "buyer_bids": {
    "Buyer Nia": 80.01177070917386,
    "Buyer Kit": 80.36948780069136,
    "Buyer Omar": 80.18529314503604,
    "Buyer Ana": 79.85067284478956,
    "Buyer Mia": 79.98225032701363,
    "Buyer Lena": 79.78655719678586
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Amir": 97.36,
    "Seller Eli": 96.6,
    "Seller Maya": 97.56,
    "Seller Raj": 97.9,
    "Seller Yara": 96.4
  },
  "buyer_bids": {
    "Buyer Nia": 80.29477091578562,
    "Buyer Omar": 80.611311269705,
    "Buyer Lena": 80.50409517516378,
    "Buyer Kit": 79.74633427531658,
    "Buyer Ana": 80.45484776282788,
    "Buyer Mia": 79.21347491631094
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Amir": 97.36,
    "Seller Raj": 97.9,
    "Seller Eli": 96.4,
    "Seller Yara": 96.41
  },
  "buyer_bids": {
    "Buyer Nia": 80.7953097551439,
    "Buyer Lena": 80.29196426720013,
    "Buyer Ana": 80.11906393352639,
    "Buyer Omar": 79.3698510773034,
    "Buyer Kit": 79.27825620499968,
    "Buyer Mia": 80.14672050746222
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Eli": 96.4,
    "Seller Maya": 97.66,
    "Seller Amir": 97.41,
    "Seller Raj": 97.9,
    "Seller Yara": 96.41
  },
  "buyer_bids": {
    "Buyer Ana": 79.41839983289174,
    "Buyer Omar": 80.40699165490105,
    "Buyer Lena": 80.70972953892448,
    "Buyer Mia": 80.51959601891612,
    "Buyer Kit": 79.62534592443505,
    "Buyer Nia": 80.66534553892929
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Amir": 97.41,
    "Seller Maya": 97.56,
    "Seller Eli": 96.4,
    "Seller Yara": 96.41,
    "Seller Raj": 97.9
  },
  "buyer_bids": {
    "Buyer Omar": 80.63674859663202,
    "Buyer Nia": 79.29661571291587,
    "Buyer Lena": 79.59920271244962,
    "Buyer Kit": 79.29087425902316,
    "Buyer Mia": 79.77634957041599,
    "Buyer Ana": 80.41505451240388
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Eli": 96.4,
    "Seller Yara": 96.42,
    "Seller Amir": 97.41,
    "Seller Maya": 97.56,
    "Seller Raj": 97.9
  },
  "buyer_bids": {
    "Buyer Nia": 79.23750829795483,
    "Buyer Omar": 79.38435692733005,
    "Buyer Kit": 79.26539932166843,
    "Buyer Lena": 79.79695564813244,
    "Buyer Mia": 80.6698080542224,
    "Buyer Ana": 79.3079465392273
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Amir": 97.41,
    "Seller Eli": 96.4,
    "Seller Raj": 97.9,
    "Seller Maya": 97.56
  },
  "buyer_bids": {
    "Buyer Kit": 80.03694625725144,
    "Buyer Nia": 79.40445941464131,
    "Buyer Mia": 79.20309800369222,
    "Buyer Lena": 80.14313318780852,
    "Buyer Omar": 80.6975444693222,
    "Buyer Ana": 80.37565925340343
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Amir": 97.6,
    "Seller Eli": 96.95,
    "Seller Raj": 97.9,
    "Seller Maya": 97.53
  },
  "buyer_bids": {
    "Buyer Ana": 80.75330760522209,
    "Buyer Kit": 79.20671377592326,
    "Buyer Mia": 80.70154242056894,
    "Buyer Nia": 80.47065267550947,
    "Buyer Lena": 80.20441003730845,
    "Buyer Omar": 79.59652320327068
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Amir": 97.9,
    "Seller Raj": 97.9,
    "Seller Yara": 96.42,
    "Seller Maya": 97.56
  },
  "buyer_bids": {
    "Buyer Kit": 79.69341698227707,
    "Buyer Omar": 79.65764261886136,
    "Buyer Nia": 80.39628543988604,
    "Buyer Mia": 80.08240532596075,
    "Buyer Ana": 79.98201763666643,
    "Buyer Lena": 80.16824948477682
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Eli": 96.5,
    "Seller Amir": 97.8,
    "Seller Raj": 97.9,
    "Seller Maya": 97.56
  },
  "buyer_bids": {
    "Buyer Nia": 79.27323593976521,
    "Buyer Mia": 79.44552889433837,
    "Buyer Omar": 79.62230748838975,
    "Buyer Lena": 80.73405447275076,
    "Buyer Ana": 79.84296637609536,
    "Buyer Kit": 80.19455220348055
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Raj": 97.9,
    "Seller Amir": 97.8,
    "Seller Eli": 96.5,
    "Seller Maya": 97.58,
    "Seller Yara": 96.45
  },
  "buyer_bids": {
    "Buyer Kit": 79.23872612056519,
    "Buyer Lena": 80.7169507876341,
    "Buyer Ana": 80.54144228818474,
    "Buyer Nia": 79.34952584100758,
    "Buyer Omar": 80.29983272929556,
    "Buyer Mia": 80.46145493834928
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Raj": 97.9,
    "Seller Eli": 96.45,
    "Seller Maya": 97.58,
    "Seller Amir": 97.9,
    "Seller Yara": 96.46
  },
  "buyer_bids": {
    "Buyer Nia": 80.0292577694053,
    "Buyer Lena": 79.74568165849563,
    "Buyer Mia": 80.59910923194565,
    "Buyer Ana": 79.97907477038864,
    "Buyer Kit": 79.7247373002032,
    "Buyer Omar": 80.4496954011077
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Eli": 96.45,
    "Seller Raj": 97.9,
    "Seller Yara": 96.47,
    "Seller Maya": 97.59,
    "Seller Amir": 97.9
  },
  "buyer_bids": {
    "Buyer Nia": 79.6189398360977,
    "Buyer Omar": 80.75309378409095,
    "Buyer Mia": 80.73439992833815,
    "Buyer Ana": 80.24530340454618,
    "Buyer Kit": 80.3191580958122,
    "Buyer Lena": 80.27289806672073
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Eli": 96.45,
    "Seller Raj": 97.9,
    "Seller Amir": 97.9,
    "Seller Maya": 97.61,
    "Seller Yara": 96.46
  },
  "buyer_bids": {
    "Buyer Nia": 79.60474706928201,
    "Buyer Mia": 79.57064811597179,
    "Buyer Omar": 79.41072306825119,
    "Buyer Ana": 79.47313722486344,
    "Buyer Kit": 79.92542386812062,
    "Buyer Lena": 80.66623674611408
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Eli": 96.45,
    "Seller Raj": 97.8,
    "Seller Amir": 97.41,
    "Seller Yara": 96.46,
    "Seller Maya": 97.62
  },
  "buyer_bids": {
    "Buyer Ana": 79.59481687822907,
    "Buyer Nia": 80.33294960181868,
    "Buyer Kit": 80.3421879582965,
    "Buyer Mia": 79.3176762610767,
    "Buyer Omar": 79.25024213784367,
    "Buyer Lena": 79.32868674506233
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Amir": 97.62,
    "Seller Raj": 97.95,
    "Seller Maya": 97.63,
    "Seller Yara": 96.45
  },
  "buyer_bids": {
    "Buyer Lena": 79.64597941072213,
    "Buyer Mia": 80.29529699591419,
    "Buyer Omar": 80.46653373003254,
    "Buyer Nia": 79.5651251509686,
    "Buyer Ana": 80.19825517784952,
    "Buyer Kit": 79.77572642870675
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Amir": 97.62,
    "Seller Eli": 96.5,
    "Seller Raj": 97.95,
    "Seller Yara": 96.4,
    "Seller Maya": 97.59
  },
  "buyer_bids": {
    "Buyer Omar": 79.44178471607566,
    "Buyer Ana": 79.81560442934902,
    "Buyer Lena": 79.34051416207392,
    "Buyer Kit": 79.45637719763725,
    "Buyer Mia": 80.01933095125878,
    "Buyer Nia": 80.40108447080641
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Eli": 96.3,
    "Seller Amir": 97.62,
    "Seller Yara": 96.4,
    "Seller Maya": 97.63
  },
  "buyer_bids": {
    "Buyer Ana": 80.40093630828292,
    "Buyer Omar": 79.23168286301804,
    "Buyer Mia": 79.23910416985436,
    "Buyer Lena": 80.27118349628928,
    "Buyer Kit": 79.36835888883297,
    "Buyer Nia": 79.363057984111
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Eli": 96.3,
    "Seller Amir": 97.62,
    "Seller Raj": 97.95,
    "Seller Maya": 97.65
  },
  "buyer_bids": {
    "Buyer Mia": 80.41683983758827,
    "Buyer Lena": 79.53622482691921,
    "Buyer Nia": 79.92617235552939,
    "Buyer Ana": 79.80800433412134,
    "Buyer Omar": 80.05685334970664,
    "Buyer Kit": 80.29549858458714
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Eli": 96.4,
    "Seller Amir": 97.65,
    "Seller Yara": 96.35,
    "Seller Maya": 97.66,
    "Seller Raj": 98.0
  },
  "buyer_bids": {
    "Buyer Lena": 80.68620906502085,
    "Buyer Nia": 80.48972763340157,
    "Buyer Omar": 79.88095832480789,
    "Buyer Mia": 80.61029927036782,
    "Buyer Kit": 80.14614861072582,
    "Buyer Ana": 79.23411620355935
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Amir": 97.9,
    "Seller Yara": 96.36,
    "Seller Eli": 96.48,
    "Seller Maya": 97.66
  },
  "buyer_bids": {
    "Buyer Kit": 79.96768440444689,
    "Buyer Nia": 80.13014561153918,
    "Buyer Omar": 80.67298612706408,
    "Buyer Lena": 80.73707191850485,
    "Buyer Ana": 80.26126738551443,
    "Buyer Mia": 79.23117261551869
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
