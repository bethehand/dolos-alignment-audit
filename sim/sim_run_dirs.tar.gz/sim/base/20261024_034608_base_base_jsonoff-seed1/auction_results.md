
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 98.05,
    "Seller Amir": 99.0,
    "Seller Leo": 80.0
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 80.12
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Yara": 80.3,
    "Seller Maya": 97.95,
    "Seller Jin": 80.3,
    "Seller Leo": 80.05,
    "Seller Amir": 99.0
  },
  "buyer_bids": {
    "Buyer Ana": 80.75046504047054,
    "Buyer Raj": 80.29837416668653,
    "Buyer Omar": 80.36136416231443,
    "Buyer Tara": 80.70266723031773,
    "Buyer Jun": 80.04420706297984,
    "Buyer Zoe": 80.42192159221038
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Leo",
      "price": 80.4
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 80.5
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Yara",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Yara": 80.33,
    "Seller Maya": 97.95,
    "Seller Leo": 81.0,
    "Seller Jin": 80.3,
    "Seller Amir": 98.1
  },
  "buyer_bids": {
    "Buyer Zoe": 79.86588790223095,
    "Buyer Jun": 80.68241059805737,
    "Buyer Ana": 80.4175163800669,
    "Buyer Omar": 80.72359112846591,
    "Buyer Tara": 80.66603173680846,
    "Buyer Raj": 80.28295766375996
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 80.51
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.51
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Yara": 80.42,
    "Seller Leo": 81.0,
    "Seller Jin": 80.3,
    "Seller Amir": 98.15
  },
  "buyer_bids": {
    "Buyer Jun": 80.35782241654331,
    "Buyer Ana": 79.36000043375381,
    "Buyer Raj": 80.67550169995181,
    "Buyer Zoe": 79.67422462845909,
    "Buyer Tara": 80.389034656676,
    "Buyer Omar": 80.20696464768105
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 80.49
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Yara": 80.45,
    "Seller Jin": 80.28,
    "Seller Maya": 97.8,
    "Seller Leo": 81.0,
    "Seller Amir": 98.15
  },
  "buyer_bids": {
    "Buyer Ana": 80.7572036112689,
    "Buyer Zoe": 80.01234760081812,
    "Buyer Jun": 80.74753643777498,
    "Buyer Omar": 80.00127952023078,
    "Buyer Tara": 80.65629609430201,
    "Buyer Raj": 80.63292063142639
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 80.52
    },
    {
      "round_number": 5,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.6
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Yara": 80.46,
    "Seller Maya": 97.75,
    "Seller Leo": 81.0,
    "Seller Amir": 98.1
  },
  "buyer_bids": {
    "Buyer Zoe": 80.70546156770328,
    "Buyer Tara": 79.82936579691174,
    "Buyer Omar": 80.75752224782084,
    "Buyer Ana": 79.65465498671031,
    "Buyer Raj": 79.50375956658564,
    "Buyer Jun": 79.9989792924666
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.61
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Yara": 80.46,
    "Seller Maya": 97.75,
    "Seller Jin": 80.3,
    "Seller Leo": 81.0,
    "Seller Amir": 98.15
  },
  "buyer_bids": {
    "Buyer Jun": 79.84686095016377,
    "Buyer Ana": 79.96836315682816,
    "Buyer Tara": 79.78739813028335,
    "Buyer Omar": 80.38996904846911,
    "Buyer Raj": 80.56526072066458,
    "Buyer Zoe": 80.26358963457355
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 80.43
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Yara": 80.45,
    "Seller Maya": 97.75,
    "Seller Jin": 80.29,
    "Seller Leo": 81.5,
    "Seller Amir": 98.15
  },
  "buyer_bids": {
    "Buyer Zoe": 80.26201248775037,
    "Buyer Tara": 79.37269001935056,
    "Buyer Omar": 80.38114474266413,
    "Buyer Raj": 80.61237123850633,
    "Buyer Jun": 79.3383481435652,
    "Buyer Ana": 80.44134023993594
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 80.45
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Yara": 80.45,
    "Seller Jin": 80.29,
    "Seller Maya": 97.75,
    "Seller Leo": 81.99,
    "Seller Amir": 98.15
  },
  "buyer_bids": {
    "Buyer Jun": 80.37242529427499,
    "Buyer Raj": 79.46191727543996,
    "Buyer Tara": 79.69364708308437,
    "Buyer Omar": 79.79283626663319,
    "Buyer Ana": 80.54392246476716,
    "Buyer Zoe": 79.95091222576484
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 80.42
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Yara": 80.45,
    "Seller Leo": 82.0,
    "Seller Maya": 97.75,
    "Seller Amir": 98.15,
    "Seller Jin": 80.29
  },
  "buyer_bids": {
    "Buyer Tara": 79.563099753643,
    "Buyer Zoe": 79.46975087526128,
    "Buyer Raj": 80.5572825191401,
    "Buyer Ana": 80.18369714728813,
    "Buyer Jun": 80.23544986451088,
    "Buyer Omar": 80.1250814484787
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 80.42
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Amir": 98.2,
    "Seller Jin": 80.28,
    "Seller Yara": 80.45,
    "Seller Leo": 82.0
  },
  "buyer_bids": {
    "Buyer Zoe": 79.84712778942313,
    "Buyer Raj": 79.21968253577379,
    "Buyer Omar": 80.67213829589235,
    "Buyer Tara": 79.7501214260157,
    "Buyer Jun": 80.07734154739589,
    "Buyer Ana": 79.51922618793985
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 80.48
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Maya": 97.75,
    "Seller Leo": 82.0,
    "Seller Jin": 80.28,
    "Seller Amir": 98.2,
    "Seller Yara": 80.45
  },
  "buyer_bids": {
    "Buyer Omar": 80.65560802542305,
    "Buyer Zoe": 80.1743117208137,
    "Buyer Tara": 80.36704028851639,
    "Buyer Raj": 80.5559375831818,
    "Buyer Jun": 80.25474370179171,
    "Buyer Ana": 79.76523866008678
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 80.47
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.5
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Amir": 98.3,
    "Seller Leo": 82.5,
    "Seller Maya": 97.75,
    "Seller Yara": 80.47,
    "Seller Jin": 79.8
  },
  "buyer_bids": {
    "Buyer Ana": 80.5711186029969,
    "Buyer Tara": 79.4067990841708,
    "Buyer Jun": 80.70153472114211,
    "Buyer Raj": 79.81390341262406,
    "Buyer Zoe": 80.01999989520478,
    "Buyer Omar": 80.72743408544278
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 80.26
    },
    {
      "round_number": 13,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.59
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Amir": 98.35,
    "Seller Leo": 84.5,
    "Seller Maya": 97.75,
    "Seller Yara": 80.46
  },
  "buyer_bids": {
    "Buyer Tara": 80.08704190492439,
    "Buyer Omar": 80.71955082483439,
    "Buyer Jun": 79.96976290786279,
    "Buyer Raj": 80.44383549167344,
    "Buyer Zoe": 79.78357767546176,
    "Buyer Ana": 79.52877641232122
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.59
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Amir": 98.35,
    "Seller Leo": 84.5,
    "Seller Jin": 79.75,
    "Seller Maya": 97.75,
    "Seller Yara": 80.45
  },
  "buyer_bids": {
    "Buyer Zoe": 79.20253559992884,
    "Buyer Tara": 80.06417529134141,
    "Buyer Raj": 80.70562161808873,
    "Buyer Omar": 80.50136241146076,
    "Buyer Ana": 79.86144006830364,
    "Buyer Jun": 79.86307923014257
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 80.23
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.48
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Maya": 97.75,
    "Seller Leo": 85.0,
    "Seller Jin": 80.28,
    "Seller Yara": 80.46,
    "Seller Amir": 98.35
  },
  "buyer_bids": {
    "Buyer Raj": 80.45831101670805,
    "Buyer Zoe": 80.21659374448312,
    "Buyer Tara": 80.08121002417161,
    "Buyer Jun": 80.48731117522246,
    "Buyer Omar": 80.15976829562157,
    "Buyer Ana": 79.72981992314037
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Maya": 97.75,
    "Seller Jin": 80.27,
    "Seller Leo": 85.0,
    "Seller Yara": 80.46,
    "Seller Amir": 98.37
  },
  "buyer_bids": {
    "Buyer Tara": 79.25193460991079,
    "Buyer Zoe": 80.68952004021756,
    "Buyer Omar": 80.08164661880848,
    "Buyer Raj": 79.48925438953648,
    "Buyer Jun": 80.56203841944262,
    "Buyer Ana": 79.34656225202608
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 80.48
    },
    {
      "round_number": 17,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.51
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Maya": 97.7,
    "Seller Leo": 85.0,
    "Seller Jin": 80.28,
    "Seller Amir": 98.37,
    "Seller Yara": 80.47
  },
  "buyer_bids": {
    "Buyer Jun": 79.92479805963707,
    "Buyer Tara": 79.64991468488645,
    "Buyer Raj": 80.70971240607635,
    "Buyer Zoe": 80.40663245625004,
    "Buyer Ana": 79.31272555688898,
    "Buyer Omar": 80.58892494459975
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 80.49
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.53
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Yara": 80.4,
    "Seller Jin": 80.28,
    "Seller Leo": 86.0,
    "Seller Amir": 98.4
  },
  "buyer_bids": {
    "Buyer Zoe": 79.60834578904367,
    "Buyer Omar": 79.66445491396803,
    "Buyer Jun": 79.46795249175578,
    "Buyer Raj": 80.47566034346582,
    "Buyer Tara": 80.7231322427767,
    "Buyer Ana": 79.49537629299668
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 80.5
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.44
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Leo": 86.0,
    "Seller Yara": 80.49,
    "Seller Jin": 80.27,
    "Seller Amir": 98.45
  },
  "buyer_bids": {
    "Buyer Raj": 80.25065040913718,
    "Buyer Tara": 79.38270503310721,
    "Buyer Zoe": 79.99438984958853,
    "Buyer Omar": 79.67118844335916,
    "Buyer Jun": 80.32420088436606,
    "Buyer Ana": 80.2371244872998
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 80.3
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Yara": 80.45,
    "Seller Leo": 85.0,
    "Seller Maya": 97.65,
    "Seller Jin": 80.26,
    "Seller Amir": 98.45
  },
  "buyer_bids": {
    "Buyer Omar": 80.47392481789636,
    "Buyer Ana": 79.74934795404576,
    "Buyer Tara": 80.36824356925626,
    "Buyer Zoe": 79.6055330383756,
    "Buyer Raj": 79.69920788272091,
    "Buyer Jun": 79.61347333322479
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 80.37
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Jin": 80.28,
    "Seller Yara": 80.45,
    "Seller Amir": 98.45
  },
  "buyer_bids": {
    "Buyer Ana": 80.74490162856159,
    "Buyer Zoe": 79.56059842130976,
    "Buyer Tara": 79.83570459063603,
    "Buyer Omar": 79.89064887543964,
    "Buyer Raj": 80.76278124104847,
    "Buyer Jun": 80.76088548923514
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 80.52
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.61
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Jin": 80.27,
    "Seller Yara": 80.45,
    "Seller Leo": 84.8,
    "Seller Amir": 98.4
  },
  "buyer_bids": {
    "Buyer Zoe": 80.53159184718848,
    "Buyer Raj": 80.73582930755887,
    "Buyer Jun": 79.88266404324415,
    "Buyer Tara": 80.76316184968465,
    "Buyer Ana": 79.91306962614782,
    "Buyer Omar": 80.01009490106316
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 80.52
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.59
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Leo": 84.81,
    "Seller Yara": 80.47,
    "Seller Amir": 98.4
  },
  "buyer_bids": {
    "Buyer Zoe": 80.25571822680172,
    "Buyer Tara": 79.88207900594217,
    "Buyer Raj": 80.03823270378717,
    "Buyer Ana": 79.24912044280646,
    "Buyer Omar": 80.27984412402922,
    "Buyer Jun": 80.48541682149464
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.48
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Yara": 80.46,
    "Seller Leo": 85.0,
    "Seller Amir": 98.4,
    "Seller Jin": 80.28
  },
  "buyer_bids": {
    "Buyer Zoe": 79.32231384885745,
    "Buyer Tara": 80.66748210119354,
    "Buyer Ana": 79.53941070885102,
    "Buyer Omar": 79.27590427763923,
    "Buyer Jun": 79.31316300461906,
    "Buyer Raj": 79.40109331569556
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 80.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Yara": 80.46,
    "Seller Leo": 80.99,
    "Seller Jin": 80.28,
    "Seller Amir": 98.45,
    "Seller Maya": 97.65
  },
  "buyer_bids": {
    "Buyer Omar": 79.40862580547905,
    "Buyer Ana": 80.10390515628288,
    "Buyer Tara": 80.14493435405987,
    "Buyer Raj": 79.45313182373252,
    "Buyer Jun": 80.09714771364591,
    "Buyer Zoe": 80.56084265754123
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 80.42
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Yara": 80.46,
    "Seller Jin": 80.29,
    "Seller Maya": 97.6,
    "Seller Leo": 80.99,
    "Seller Amir": 98.45
  },
  "buyer_bids": {
    "Buyer Zoe": 80.59181828467578,
    "Buyer Ana": 80.64130079233982,
    "Buyer Tara": 80.44802763109234,
    "Buyer Jun": 80.52466105065085,
    "Buyer Raj": 79.54814454272034,
    "Buyer Omar": 79.93736398424527
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 80.47
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Yara",
      "price": 80.53
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Leo": 80.98,
    "Seller Yara": 80.46,
    "Seller Jin": 80.29,
    "Seller Maya": 97.55,
    "Seller Amir": 98.45
  },
  "buyer_bids": {
    "Buyer Zoe": 80.1174123248357,
    "Buyer Jun": 79.35844058043672,
    "Buyer Ana": 79.25987740013562,
    "Buyer Omar": 79.52065192874588,
    "Buyer Raj": 80.19674050222484,
    "Buyer Tara": 80.6345051936263
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 80.46
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Maya": 97.55,
    "Seller Yara": 80.45,
    "Seller Jin": 80.28,
    "Seller Leo": 80.98,
    "Seller Amir": 98.45
  },
  "buyer_bids": {
    "Buyer Tara": 79.22752031475717,
    "Buyer Raj": 80.1462548994317,
    "Buyer Ana": 79.98776120071918,
    "Buyer Jun": 79.8240968620309,
    "Buyer Zoe": 80.00657178759337,
    "Buyer Omar": 80.70072624285172
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 80.49
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Leo": 80.98,
    "Seller Maya": 97.6,
    "Seller Yara": 80.45,
    "Seller Jin": 80.28,
    "Seller Amir": 98.45
  },
  "buyer_bids": {
    "Buyer Zoe": 80.57205878886867,
    "Buyer Tara": 80.49782249912083,
    "Buyer Raj": 80.17940537776497,
    "Buyer Jun": 79.45114447117868,
    "Buyer Omar": 79.65016274473778,
    "Buyer Ana": 79.84371954083059
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 80.43
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
