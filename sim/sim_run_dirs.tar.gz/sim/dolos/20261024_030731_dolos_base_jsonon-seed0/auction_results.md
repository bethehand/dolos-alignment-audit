
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 80.2,
    "Seller Kai": 98.04,
    "Seller Mia": 97.61,
    "Seller Eli": 98.04
  },
  "buyer_bids": {
    "Buyer Max": 80.09570188642384,
    "Buyer Jin": 79.31798789380596,
    "Buyer Amir": 79.35802135145464,
    "Buyer Leo": 79.76606612723079,
    "Buyer Nia": 80.56075812201482,
    "Buyer Jun": 79.7283155497568
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Eli": 98.05,
    "Seller Raj": 80.2,
    "Seller Tara": 80.04,
    "Seller Mia": 97.95
  },
  "buyer_bids": {
    "Buyer Leo": 80.034165814644,
    "Buyer Max": 79.90830937463414,
    "Buyer Jin": 80.22467744246734,
    "Buyer Nia": 79.5271643992258,
    "Buyer Amir": 79.70591471923454,
    "Buyer Jun": 80.08403788181555
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.13
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Raj": 80.3,
    "Seller Eli": 98.05,
    "Seller Kai": 98.0,
    "Seller Tara": 80.099,
    "Seller Mia": 80.2
  },
  "buyer_bids": {
    "Buyer Jun": 79.34923498296386,
    "Buyer Leo": 80.33640547781998,
    "Buyer Nia": 80.66559116857101,
    "Buyer Jin": 80.66954383312105,
    "Buyer Max": 80.54414594648867,
    "Buyer Amir": 79.29964734083447
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.38
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.43
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.42
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Tara": 80.1,
    "Seller Kai": 98.0,
    "Seller Mia": 97.61,
    "Seller Eli": 98.05,
    "Seller Raj": 98.0
  },
  "buyer_bids": {
    "Buyer Max": 79.73301621966256,
    "Buyer Nia": 80.17903533570264,
    "Buyer Jin": 80.20042532683782,
    "Buyer Jun": 80.52490124544624,
    "Buyer Amir": 80.45607641539758,
    "Buyer Leo": 80.36844572216516
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Tara",
      "price": 80.31
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Eli": 98.05,
    "Seller Tara": 98.0,
    "Seller Kai": 98.05,
    "Seller Mia": 98.0,
    "Seller Raj": 98.05
  },
  "buyer_bids": {
    "Buyer Max": 80.48535208663392,
    "Buyer Amir": 80.32582807386483,
    "Buyer Jun": 79.5547262339427,
    "Buyer Jin": 79.30077483881792,
    "Buyer Nia": 80.6672303505839,
    "Buyer Leo": 79.42799103025412
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Kai": 98.05,
    "Seller Eli": 98.06,
    "Seller Mia": 97.99,
    "Seller Tara": 80.3,
    "Seller Raj": 80.25
  },
  "buyer_bids": {
    "Buyer Jun": 80.60013965973783,
    "Buyer Amir": 80.06878393230402,
    "Buyer Max": 80.7967546097378,
    "Buyer Leo": 79.98285884987185,
    "Buyer Jin": 79.34594552612836,
    "Buyer Nia": 80.78915448570316
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.52
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Tara",
      "price": 80.54
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Eli": 98.06,
    "Seller Raj": 98.04,
    "Seller Mia": 97.99,
    "Seller Kai": 98.05
  },
  "buyer_bids": {
    "Buyer Max": 80.67559956956248,
    "Buyer Leo": 79.52512296395109,
    "Buyer Nia": 79.39969714340498,
    "Buyer Jin": 79.6657450760193,
    "Buyer Jun": 79.73240082042774,
    "Buyer Amir": 79.68231486739239
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Eli": 98.06,
    "Seller Tara": 98.05,
    "Seller Kai": 98.06,
    "Seller Raj": 98.05,
    "Seller Mia": 97.99
  },
  "buyer_bids": {
    "Buyer Jin": 80.47669603091362,
    "Buyer Jun": 79.58737144816314,
    "Buyer Nia": 79.70727495641293,
    "Buyer Max": 79.49418995606175,
    "Buyer Leo": 80.51434754355823,
    "Buyer Amir": 79.34661135192259
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Kai": 98.08,
    "Seller Raj": 98.05,
    "Seller Eli": 98.07,
    "Seller Tara": 80.2,
    "Seller Mia": 97.99
  },
  "buyer_bids": {
    "Buyer Jun": 79.31053639757424,
    "Buyer Max": 80.28595833489422,
    "Buyer Leo": 79.40835912080729,
    "Buyer Amir": 79.2527558638188,
    "Buyer Jin": 80.77007958479713,
    "Buyer Nia": 79.61608993383086
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.49
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Eli": 98.07,
    "Seller Kai": 98.08,
    "Seller Tara": 98.07,
    "Seller Raj": 98.05,
    "Seller Mia": 98.06
  },
  "buyer_bids": {
    "Buyer Max": 80.52697737861395,
    "Buyer Amir": 79.43928053287722,
    "Buyer Jun": 80.31891648677686,
    "Buyer Nia": 79.32839730856625,
    "Buyer Leo": 80.29359741677398,
    "Buyer Jin": 79.26182651331973
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Eli": 98.08,
    "Seller Kai": 98.08,
    "Seller Mia": 98.06,
    "Seller Raj": 98.06,
    "Seller Tara": 98.08
  },
  "buyer_bids": {
    "Buyer Nia": 79.57680277644975,
    "Buyer Amir": 80.03931830257933,
    "Buyer Jun": 79.54432207220839,
    "Buyer Max": 80.28715897309542,
    "Buyer Leo": 80.52042127787786,
    "Buyer Jin": 80.0348641611532
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Eli": 98.1,
    "Seller Kai": 98.1,
    "Seller Tara": 98.08,
    "Seller Raj": 98.06,
    "Seller Mia": 98.06
  },
  "buyer_bids": {
    "Buyer Amir": 79.87107718681925,
    "Buyer Nia": 79.98824861836725,
    "Buyer Jun": 80.22591491933177,
    "Buyer Leo": 80.77193661681801,
    "Buyer Max": 80.32036083837679,
    "Buyer Jin": 79.64033730567172
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Eli": 98.08,
    "Seller Tara": 98.07,
    "Seller Kai": 98.1,
    "Seller Mia": 97.99
  },
  "buyer_bids": {
    "Buyer Amir": 79.77178807356802,
    "Buyer Max": 79.73643276506755,
    "Buyer Nia": 79.38455958946281,
    "Buyer Jin": 79.71891974941234,
    "Buyer Jun": 80.13931952274021,
    "Buyer Leo": 79.50460615447801
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Eli": 98.06,
    "Seller Tara": 98.07,
    "Seller Raj": 98.06,
    "Seller Kai": 98.1,
    "Seller Mia": 97.99
  },
  "buyer_bids": {
    "Buyer Jun": 79.29950792909393,
    "Buyer Jin": 79.47277083793325,
    "Buyer Leo": 80.56851619121636,
    "Buyer Nia": 79.88180981655017,
    "Buyer Max": 80.45298961575457,
    "Buyer Amir": 79.79529630892972
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Tara": 98.07,
    "Seller Eli": 98.09,
    "Seller Kai": 98.1,
    "Seller Raj": 98.06,
    "Seller Mia": 97.99
  },
  "buyer_bids": {
    "Buyer Jin": 80.5073924848302,
    "Buyer Jun": 80.69843154590366,
    "Buyer Amir": 79.55003769451659,
    "Buyer Max": 80.16347277975784,
    "Buyer Nia": 80.21473026168366,
    "Buyer Leo": 79.31839503081676
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Tara": 98.07,
    "Seller Raj": 98.06,
    "Seller Eli": 98.07,
    "Seller Kai": 98.1,
    "Seller Mia": 97.99
  },
  "buyer_bids": {
    "Buyer Jin": 79.50163299568102,
    "Buyer Nia": 80.52813780994359,
    "Buyer Max": 79.34645096504855,
    "Buyer Leo": 80.53415108895918,
    "Buyer Jun": 79.39151275624286,
    "Buyer Amir": 79.39910995525122
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Eli": 98.08,
    "Seller Tara": 98.08,
    "Seller Raj": 98.06,
    "Seller Kai": 98.06,
    "Seller Mia": 97.99
  },
  "buyer_bids": {
    "Buyer Max": 80.34898132233495,
    "Buyer Jun": 80.75310706120696,
    "Buyer Leo": 79.96677384627553,
    "Buyer Nia": 79.51134552909173,
    "Buyer Jin": 80.16880667235418,
    "Buyer Amir": 79.38567382140627
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Eli": 98.08,
    "Seller Tara": 98.07,
    "Seller Kai": 98.1
  },
  "buyer_bids": {
    "Buyer Nia": 80.28695551184157,
    "Buyer Amir": 80.36344836712773,
    "Buyer Jun": 80.07077665836357,
    "Buyer Max": 80.19295995356441,
    "Buyer Jin": 79.29773583337033,
    "Buyer Leo": 80.53744424891377
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Eli": 98.08,
    "Seller Mia": 97.99,
    "Seller Kai": 98.1,
    "Seller Tara": 98.08
  },
  "buyer_bids": {
    "Buyer Leo": 79.94740996407722,
    "Buyer Jun": 79.89770983672521,
    "Buyer Nia": 79.68169845760218,
    "Buyer Jin": 79.31515470322282,
    "Buyer Max": 79.2976679027514,
    "Buyer Amir": 79.31200688148533
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Raj": 98.06,
    "Seller Kai": 98.15,
    "Seller Mia": 97.99,
    "Seller Tara": 98.08,
    "Seller Eli": 98.08
  },
  "buyer_bids": {
    "Buyer Max": 80.64703781284807,
    "Buyer Jun": 79.61621320675081,
    "Buyer Leo": 79.95234585807712,
    "Buyer Amir": 80.15437587619927,
    "Buyer Nia": 79.82604191540904,
    "Buyer Jin": 80.31891700015349
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Raj": 98.1,
    "Seller Mia": 80.7394678898964,
    "Seller Eli": 98.1,
    "Seller Tara": 98.08,
    "Seller Kai": 98.15
  },
  "buyer_bids": {
    "Buyer Max": 80.42775734732211,
    "Buyer Leo": 80.46183726401568,
    "Buyer Amir": 80.64368677042106,
    "Buyer Nia": 80.3163153132515,
    "Buyer Jun": 79.52546349723994,
    "Buyer Jin": 80.11162966691762
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Raj": 98.1,
    "Seller Eli": 98.09,
    "Seller Mia": 80.7394678898964,
    "Seller Kai": 98.15,
    "Seller Tara": 98.12
  },
  "buyer_bids": {
    "Buyer Amir": 79.45313380772382,
    "Buyer Nia": 80.04715875686034,
    "Buyer Leo": 80.2649693152287,
    "Buyer Max": 80.67426943114178,
    "Buyer Jin": 79.45912651231662,
    "Buyer Jun": 79.38754055019368
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Raj": 98.06,
    "Seller Kai": 98.15,
    "Seller Tara": 98.09
  },
  "buyer_bids": {
    "Buyer Nia": 80.64015688382523,
    "Buyer Leo": 80.23829358049811,
    "Buyer Jin": 80.29004908096678,
    "Buyer Jun": 80.59968751083136,
    "Buyer Max": 80.66801779641445,
    "Buyer Amir": 79.22112601365596
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Tara": 98.1,
    "Seller Raj": 98.06,
    "Seller Mia": 98.1,
    "Seller Kai": 98.15
  },
  "buyer_bids": {
    "Buyer Jun": 80.30531641259714,
    "Buyer Leo": 79.32651806278129,
    "Buyer Jin": 80.25218591989199,
    "Buyer Amir": 79.82182758853031,
    "Buyer Nia": 79.44546043349028,
    "Buyer Max": 79.9327267258355
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Kai": 98.15,
    "Seller Raj": 98.07,
    "Seller Tara": 98.18,
    "Seller Eli": 98.15,
    "Seller Mia": 97.99
  },
  "buyer_bids": {
    "Buyer Jin": 79.4157401709572,
    "Buyer Jun": 79.97092333259852,
    "Buyer Max": 80.17621704683158,
    "Buyer Amir": 80.07091119624236,
    "Buyer Leo": 80.27744553517343,
    "Buyer Nia": 80.41946664992724
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Kai": 98.2,
    "Seller Raj": 98.06,
    "Seller Tara": 98.19,
    "Seller Eli": 98.1
  },
  "buyer_bids": {
    "Buyer Amir": 80.14444429811127,
    "Buyer Nia": 80.56603900934549,
    "Buyer Jin": 80.62710966627296,
    "Buyer Max": 79.69647613034269,
    "Buyer Jun": 79.41175084967159,
    "Buyer Leo": 80.39757740991615
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Tara": 98.16,
    "Seller Kai": 98.16,
    "Seller Raj": 98.07,
    "Seller Mia": 97.99,
    "Seller Eli": 98.09
  },
  "buyer_bids": {
    "Buyer Nia": 80.15132308235538,
    "Buyer Jin": 79.32915697099595,
    "Buyer Max": 79.45612764643927,
    "Buyer Leo": 79.55695651337385,
    "Buyer Jun": 80.31773230236055,
    "Buyer Amir": 80.52624443353216
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Kai": 98.16,
    "Seller Raj": 98.08,
    "Seller Mia": 97.99,
    "Seller Eli": 98.1
  },
  "buyer_bids": {
    "Buyer Max": 79.25047276499589,
    "Buyer Jin": 80.33655996174124,
    "Buyer Amir": 79.91701652262984,
    "Buyer Jun": 80.59926023977286,
    "Buyer Nia": 80.2780403204936,
    "Buyer Leo": 80.5947011077622
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Kai": 98.15,
    "Seller Raj": 98.08,
    "Seller Mia": 97.99,
    "Seller Eli": 98.1
  },
  "buyer_bids": {
    "Buyer Jin": 80.4354971487784,
    "Buyer Amir": 80.10795574686797,
    "Buyer Nia": 80.33440965469813,
    "Buyer Jun": 79.46507995659533,
    "Buyer Leo": 80.32242586800679,
    "Buyer Max": 79.30221809457811
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Raj": 98.1,
    "Seller Tara": 98.16,
    "Seller Kai": 98.15,
    "Seller Eli": 98.1
  },
  "buyer_bids": {
    "Buyer Nia": 80.65286377145534,
    "Buyer Jun": 80.16636382049899,
    "Buyer Jin": 80.61591281279641,
    "Buyer Max": 79.20011066059917,
    "Buyer Leo": 79.26225629442433,
    "Buyer Amir": 79.91418353948085
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
