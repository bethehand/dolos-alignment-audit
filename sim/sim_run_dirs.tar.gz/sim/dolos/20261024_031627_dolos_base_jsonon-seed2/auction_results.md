
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 97.3,
    "Seller Maya": 80.64,
    "Seller Eli": 96.31,
    "Seller Yara": 96.0
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Maya",
      "price": 80.67
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Yara": 96.1,
    "Seller Eli": 96.32,
    "Seller Maya": 80.65,
    "Seller Amir": 97.34,
    "Seller Raj": 97.0
  },
  "buyer_bids": {
    "Buyer Ana": 79.48389829678683,
    "Buyer Nia": 80.61450330645742,
    "Buyer Omar": 79.46318147850646,
    "Buyer Mia": 79.48275196939878,
    "Buyer Lena": 79.47774200602409,
    "Buyer Kit": 79.56896427898238
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Eli": 96.33,
    "Seller Yara": 96.0,
    "Seller Maya": 80.65,
    "Seller Amir": 93.15,
    "Seller Raj": 96.9
  },
  "buyer_bids": {
    "Buyer Nia": 80.01626670968798,
    "Buyer Lena": 79.91302017923307,
    "Buyer Kit": 80.09582450606636,
    "Buyer Ana": 80.02197984068965,
    "Buyer Omar": 79.77550624607424,
    "Buyer Mia": 80.79228427283253
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Maya",
      "price": 80.72
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Eli": 96.33,
    "Seller Amir": 95.2,
    "Seller Maya": 80.67,
    "Seller Raj": 97.0,
    "Seller Yara": 96.0
  },
  "buyer_bids": {
    "Buyer Nia": 79.86347359102251,
    "Buyer Mia": 80.14957689468608,
    "Buyer Kit": 79.78280883776841,
    "Buyer Omar": 80.04058514722102,
    "Buyer Lena": 79.77901821113797,
    "Buyer Ana": 80.65356492713553
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Eli": 96.32,
    "Seller Maya": 80.67,
    "Seller Yara": 96.0,
    "Seller Raj": 96.9,
    "Seller Amir": 95.2
  },
  "buyer_bids": {
    "Buyer Omar": 79.9132303376339,
    "Buyer Mia": 80.38174435450323,
    "Buyer Kit": 79.83978159088076,
    "Buyer Ana": 80.72789299194818,
    "Buyer Nia": 80.57434691145302,
    "Buyer Lena": 80.2478575650496
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Maya",
      "price": 80.7
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Raj": 96.9,
    "Seller Amir": 95.7,
    "Seller Maya": 80.75,
    "Seller Eli": 96.33,
    "Seller Yara": 96.05
  },
  "buyer_bids": {
    "Buyer Omar": 79.64656358867684,
    "Buyer Nia": 79.59984282839315,
    "Buyer Kit": 80.02462752856641,
    "Buyer Lena": 80.25869696000638,
    "Buyer Ana": 79.99690468908358,
    "Buyer Mia": 80.47394599144368
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Amir": 95.3,
    "Seller Eli": 96.33,
    "Seller Raj": 96.9,
    "Seller Maya": 80.79,
    "Seller Yara": 96.05
  },
  "buyer_bids": {
    "Buyer Nia": 79.92750205874086,
    "Buyer Omar": 80.64508264614359,
    "Buyer Mia": 80.09213256506649,
    "Buyer Lena": 79.93048178537617,
    "Buyer Ana": 79.76123969039566,
    "Buyer Kit": 80.36141632700361
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Raj": 96.8,
    "Seller Maya": 80.75,
    "Seller Eli": 96.36,
    "Seller Yara": 96.05,
    "Seller Amir": 95.2
  },
  "buyer_bids": {
    "Buyer Ana": 80.50349385380235,
    "Buyer Lena": 80.18615372500584,
    "Buyer Kit": 80.5360422392615,
    "Buyer Omar": 80.70495442539057,
    "Buyer Mia": 80.6027138818257,
    "Buyer Nia": 80.25421648289932
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Maya": 80.75,
    "Seller Raj": 96.85,
    "Seller Eli": 96.35,
    "Seller Amir": 95.25,
    "Seller Yara": 96.05
  },
  "buyer_bids": {
    "Buyer Nia": 80.43677449120734,
    "Buyer Kit": 80.47881420500524,
    "Buyer Lena": 80.09950192591843,
    "Buyer Mia": 80.5297085464507,
    "Buyer Ana": 79.68527479120924,
    "Buyer Omar": 79.96762583624796
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Eli": 96.35,
    "Seller Raj": 96.85,
    "Seller Amir": 93.0,
    "Seller Yara": 96.05,
    "Seller Maya": 80.74
  },
  "buyer_bids": {
    "Buyer Lena": 79.78655719678586,
    "Buyer Omar": 80.18529314503604,
    "Buyer Kit": 80.36948780069136,
    "Buyer Nia": 80.01177070917386,
    "Buyer Mia": 79.98225032701363,
    "Buyer Ana": 79.85067284478956
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Raj": 96.85,
    "Seller Eli": 96.35,
    "Seller Maya": 80.73,
    "Seller Amir": 93.05,
    "Seller Yara": 96.05
  },
  "buyer_bids": {
    "Buyer Ana": 79.74633427531658,
    "Buyer Kit": 79.21347491631094,
    "Buyer Lena": 80.7953097551439,
    "Buyer Omar": 80.45484776282788,
    "Buyer Mia": 80.50409517516378,
    "Buyer Nia": 80.611311269705
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Maya",
      "price": 80.76
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Eli": 96.33,
    "Seller Maya": 80.73,
    "Seller Yara": 96.05,
    "Seller Amir": 95.35,
    "Seller Raj": 96.85
  },
  "buyer_bids": {
    "Buyer Ana": 79.27825620499968,
    "Buyer Nia": 79.3698510773034,
    "Buyer Lena": 80.66534553892929,
    "Buyer Omar": 80.11906393352639,
    "Buyer Mia": 80.29196426720013,
    "Buyer Kit": 80.14672050746222
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Maya": 80.67,
    "Seller Eli": 96.33,
    "Seller Amir": 95.5,
    "Seller Yara": 96.04,
    "Seller Raj": 96.85
  },
  "buyer_bids": {
    "Buyer Nia": 80.40699165490105,
    "Buyer Ana": 79.62534592443505,
    "Buyer Kit": 80.51959601891612,
    "Buyer Lena": 79.29661571291587,
    "Buyer Mia": 80.70972953892448,
    "Buyer Omar": 79.41839983289174
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Maya",
      "price": 80.69
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Maya": 80.67,
    "Seller Eli": 96.33,
    "Seller Yara": 96.06,
    "Seller Raj": 96.8,
    "Seller Amir": 95.5
  },
  "buyer_bids": {
    "Buyer Lena": 79.23750829795483,
    "Buyer Nia": 80.63674859663202,
    "Buyer Omar": 80.41505451240388,
    "Buyer Mia": 79.59920271244962,
    "Buyer Ana": 79.29087425902316,
    "Buyer Kit": 79.77634957041599
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Raj": 96.75,
    "Seller Eli": 96.33,
    "Seller Maya": 80.72,
    "Seller Yara": 96.1,
    "Seller Amir": 95.35
  },
  "buyer_bids": {
    "Buyer Ana": 79.26539932166843,
    "Buyer Nia": 79.38435692733005,
    "Buyer Omar": 79.3079465392273,
    "Buyer Lena": 79.40445941464131,
    "Buyer Kit": 80.6698080542224,
    "Buyer Mia": 79.79695564813244
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Raj": 96.8,
    "Seller Maya": 80.72,
    "Seller Eli": 96.35,
    "Seller Amir": 95.85
  },
  "buyer_bids": {
    "Buyer Kit": 79.20309800369222,
    "Buyer Mia": 80.14313318780852,
    "Buyer Ana": 80.03694625725144,
    "Buyer Nia": 80.6975444693222,
    "Buyer Omar": 80.37565925340343,
    "Buyer Lena": 80.47065267550947
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Eli": 96.36,
    "Seller Amir": 95.75,
    "Seller Maya": 80.73,
    "Seller Raj": 96.85,
    "Seller Yara": 96.1
  },
  "buyer_bids": {
    "Buyer Lena": 80.39628543988604,
    "Buyer Kit": 80.70154242056894,
    "Buyer Nia": 79.59652320327068,
    "Buyer Ana": 79.20671377592326,
    "Buyer Omar": 80.75330760522209,
    "Buyer Mia": 80.20441003730845
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Maya",
      "price": 80.74
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Yara": 96.1,
    "Seller Raj": 96.75,
    "Seller Eli": 96.36,
    "Seller Maya": 80.73,
    "Seller Amir": 95.35
  },
  "buyer_bids": {
    "Buyer Mia": 80.16824948477682,
    "Buyer Lena": 79.27323593976521,
    "Buyer Kit": 80.08240532596075,
    "Buyer Omar": 79.98201763666643,
    "Buyer Nia": 79.65764261886136,
    "Buyer Ana": 79.69341698227707
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Eli": 96.36,
    "Seller Amir": 96.06,
    "Seller Yara": 96.1,
    "Seller Maya": 80.73,
    "Seller Raj": 96.85
  },
  "buyer_bids": {
    "Buyer Ana": 80.19455220348055,
    "Buyer Kit": 79.44552889433837,
    "Buyer Nia": 79.62230748838975,
    "Buyer Mia": 80.73405447275076,
    "Buyer Omar": 79.84296637609536,
    "Buyer Lena": 79.34952584100758
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Maya",
      "price": 80.73
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Maya": 80.73,
    "Seller Amir": 95.5,
    "Seller Raj": 96.85,
    "Seller Yara": 96.06
  },
  "buyer_bids": {
    "Buyer Mia": 80.7169507876341,
    "Buyer Kit": 80.46145493834928,
    "Buyer Omar": 80.54144228818474,
    "Buyer Nia": 80.29983272929556,
    "Buyer Lena": 80.0292577694053,
    "Buyer Ana": 79.23872612056519
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Eli": 96.33,
    "Seller Amir": 95.85,
    "Seller Maya": 80.73,
    "Seller Raj": 96.9,
    "Seller Yara": 96.1
  },
  "buyer_bids": {
    "Buyer Nia": 80.4496954011077,
    "Buyer Ana": 79.7247373002032,
    "Buyer Omar": 79.97907477038864,
    "Buyer Lena": 79.6189398360977,
    "Buyer Kit": 80.59910923194565,
    "Buyer Mia": 79.74568165849563
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Eli": 96.33,
    "Seller Yara": 96.1,
    "Seller Raj": 97.2,
    "Seller Amir": 96.06
  },
  "buyer_bids": {
    "Buyer Omar": 80.73439992833815,
    "Buyer Mia": 79.41072306825119,
    "Buyer Kit": 79.60474706928201,
    "Buyer Lena": 79.47313722486344,
    "Buyer Nia": 80.3191580958122,
    "Buyer Ana": 80.27289806672073
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Eli": 96.33,
    "Seller Raj": 96.97,
    "Seller Yara": 80.27289806672073
  },
  "buyer_bids": {
    "Buyer Lena": 79.59481687822907,
    "Buyer Nia": 79.92542386812062,
    "Buyer Ana": 80.66623674611408,
    "Buyer Omar": 79.57064811597179,
    "Buyer Mia": 79.25024213784367,
    "Buyer Kit": 80.33294960181868
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Yara": 96.1,
    "Seller Eli": 96.35,
    "Seller Raj": 96.98,
    "Seller Amir": 96.36
  },
  "buyer_bids": {
    "Buyer Lena": 79.64597941072213,
    "Buyer Omar": 80.46653373003254,
    "Buyer Kit": 79.77572642870675,
    "Buyer Mia": 80.29529699591419,
    "Buyer Ana": 80.19825517784952,
    "Buyer Nia": 79.5651251509686
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Raj": 96.85,
    "Seller Yara": 96.1,
    "Seller Amir": 95.34,
    "Seller Eli": 96.35
  },
  "buyer_bids": {
    "Buyer Nia": 80.40108447080641,
    "Buyer Kit": 79.45637719763725,
    "Buyer Omar": 79.44178471607566,
    "Buyer Mia": 80.01933095125878,
    "Buyer Ana": 79.81560442934902,
    "Buyer Lena": 79.34051416207392
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Raj": 96.98,
    "Seller Eli": 96.35,
    "Seller Yara": 96.1,
    "Seller Amir": 95.5
  },
  "buyer_bids": {
    "Buyer Lena": 80.27118349628928,
    "Buyer Ana": 80.40093630828292,
    "Buyer Kit": 79.36835888883297,
    "Buyer Nia": 79.363057984111,
    "Buyer Omar": 79.23168286301804,
    "Buyer Mia": 79.23910416985436
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Amir": 95.85,
    "Seller Raj": 96.98,
    "Seller Eli": 96.35,
    "Seller Yara": 96.1
  },
  "buyer_bids": {
    "Buyer Kit": 80.29549858458714,
    "Buyer Nia": 79.92617235552939,
    "Buyer Omar": 80.05685334970664,
    "Buyer Mia": 80.41683983758827,
    "Buyer Ana": 79.80800433412134,
    "Buyer Lena": 79.53622482691921
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Eli": 96.35,
    "Seller Amir": 95.25,
    "Seller Raj": 96.98,
    "Seller Yara": 96.1
  },
  "buyer_bids": {
    "Buyer Nia": 80.48972763340157,
    "Buyer Omar": 79.88095832480789,
    "Buyer Mia": 80.61029927036782,
    "Buyer Kit": 80.14614861072582,
    "Buyer Ana": 79.23411620355935,
    "Buyer Lena": 80.68620906502085
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Yara": 96.1,
    "Seller Amir": 95.5,
    "Seller Raj": 96.88,
    "Seller Eli": 96.4
  },
  "buyer_bids": {
    "Buyer Lena": 80.73707191850485,
    "Buyer Mia": 79.23117261551869,
    "Buyer Kit": 79.96768440444689,
    "Buyer Ana": 80.26126738551443,
    "Buyer Omar": 80.67298612706408,
    "Buyer Nia": 80.13014561153918
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Eli": 96.35,
    "Seller Amir": 95.85,
    "Seller Raj": 96.88,
    "Seller Yara": 96.1
  },
  "buyer_bids": {
    "Buyer Ana": 80.30463151912117,
    "Buyer Omar": 79.78637252199151,
    "Buyer Nia": 79.38974556458605,
    "Buyer Mia": 79.69323922418423,
    "Buyer Kit": 80.69191574301989,
    "Buyer Lena": 80.59895521027221
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
