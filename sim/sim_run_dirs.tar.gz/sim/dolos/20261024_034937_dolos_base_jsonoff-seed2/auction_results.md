
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 97.62,
    "Seller Maya": 97.62,
    "Seller Amir": 80.65,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Yara",
      "price": 80.4
    },
    {
      "round_number": 1,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Amir",
      "price": 80.65
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Amir": 80.65,
    "Seller Maya": 97.5,
    "Seller Eli": 80.55,
    "Seller Raj": 97.62,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Ana": 79.48389829678683,
    "Buyer Kit": 79.56896427898238,
    "Buyer Lena": 79.47774200602409,
    "Buyer Omar": 79.46318147850646,
    "Buyer Nia": 80.61450330645742,
    "Buyer Mia": 79.48275196939878
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Yara",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Eli": 80.55,
    "Seller Yara": 80.1,
    "Seller Maya": 97.5,
    "Seller Raj": 97.62
  },
  "buyer_bids": {
    "Buyer Lena": 79.86347359102251,
    "Buyer Omar": 80.02197984068965,
    "Buyer Nia": 79.77550624607424,
    "Buyer Kit": 80.79228427283253,
    "Buyer Ana": 80.09582450606636,
    "Buyer Mia": 79.91302017923307
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Yara",
      "price": 80.45
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Raj": 98.0,
    "Seller Maya": 97.5,
    "Seller Eli": 80.55
  },
  "buyer_bids": {
    "Buyer Ana": 79.78280883776841,
    "Buyer Mia": 79.77901821113797,
    "Buyer Kit": 80.14957689468608,
    "Buyer Nia": 80.04058514722102,
    "Buyer Lena": 80.57434691145302,
    "Buyer Omar": 80.65356492713553
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Eli",
      "price": 80.6
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Maya": 97.5,
    "Seller Amir": 80.65,
    "Seller Yara": 80.1,
    "Seller Raj": 98.0
  },
  "buyer_bids": {
    "Buyer Nia": 79.9132303376339,
    "Buyer Lena": 79.59984282839315,
    "Buyer Mia": 80.2478575650496,
    "Buyer Omar": 80.72789299194818,
    "Buyer Kit": 80.38174435450323,
    "Buyer Ana": 79.83978159088076
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Amir": 80.65,
    "Seller Maya": 97.65,
    "Seller Raj": 97.63,
    "Seller Yara": 80.1,
    "Seller Eli": 80.56
  },
  "buyer_bids": {
    "Buyer Omar": 80.02462752856641,
    "Buyer Kit": 80.25869696000638,
    "Buyer Mia": 79.92750205874086,
    "Buyer Ana": 80.47394599144368,
    "Buyer Nia": 79.99690468908358,
    "Buyer Lena": 80.64508264614359
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Yara",
      "price": 80.37
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Yara": 80.1,
    "Seller Raj": 97.63,
    "Seller Amir": 80.75,
    "Seller Eli": 80.56,
    "Seller Maya": 97.65
  },
  "buyer_bids": {
    "Buyer Lena": 80.70495442539057,
    "Buyer Mia": 80.25421648289932,
    "Buyer Nia": 79.76123969039566,
    "Buyer Ana": 80.09213256506649,
    "Buyer Kit": 79.93048178537617,
    "Buyer Omar": 80.36141632700361
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Yara",
      "price": 80.4
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Maya": 97.63,
    "Seller Raj": 97.63,
    "Seller Eli": 80.58,
    "Seller Amir": 80.75,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Mia": 79.68527479120924,
    "Buyer Lena": 80.47881420500524,
    "Buyer Ana": 80.43677449120734,
    "Buyer Kit": 79.96762583624796,
    "Buyer Nia": 80.6027138818257,
    "Buyer Omar": 80.18615372500584
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Yara",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Raj": 97.62,
    "Seller Yara": 80.1,
    "Seller Amir": 80.75,
    "Seller Eli": 80.57
  },
  "buyer_bids": {
    "Buyer Lena": 79.98225032701363,
    "Buyer Mia": 80.36948780069136,
    "Buyer Kit": 79.85067284478956,
    "Buyer Ana": 80.18529314503604,
    "Buyer Omar": 80.01177070917386,
    "Buyer Nia": 80.09950192591843
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Yara",
      "price": 80.23
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Raj": 97.62,
    "Seller Eli": 80.58,
    "Seller Yara": 80.1,
    "Seller Maya": 97.65,
    "Seller Amir": 80.9
  },
  "buyer_bids": {
    "Buyer Mia": 79.74633427531658,
    "Buyer Kit": 80.45484776282788,
    "Buyer Omar": 80.29477091578562,
    "Buyer Lena": 79.21347491631094,
    "Buyer Ana": 80.611311269705,
    "Buyer Nia": 79.78655719678586
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Eli": 80.56,
    "Seller Maya": 97.65,
    "Seller Yara": 80.1,
    "Seller Raj": 97.63
  },
  "buyer_bids": {
    "Buyer Ana": 80.11906393352639,
    "Buyer Nia": 80.7953097551439,
    "Buyer Lena": 80.29196426720013,
    "Buyer Mia": 80.14672050746222,
    "Buyer Kit": 79.27825620499968,
    "Buyer Omar": 79.3698510773034
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Yara",
      "price": 80.45
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Raj": 97.63,
    "Seller Amir": 80.65,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Nia": 79.41839983289174,
    "Buyer Lena": 80.63674859663202,
    "Buyer Mia": 79.29661571291587,
    "Buyer Ana": 80.51959601891612,
    "Buyer Omar": 79.62534592443505,
    "Buyer Kit": 80.70972953892448
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Yara",
      "price": 80.4
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Eli": 80.58,
    "Seller Amir": 97.63,
    "Seller Raj": 97.65
  },
  "buyer_bids": {
    "Buyer Ana": 79.77634957041599,
    "Buyer Nia": 80.41505451240388,
    "Buyer Mia": 79.23750829795483,
    "Buyer Omar": 79.29087425902316,
    "Buyer Lena": 79.38435692733005,
    "Buyer Kit": 79.59920271244962
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Amir": 97.58,
    "Seller Yara": 80.1,
    "Seller Raj": 97.63,
    "Seller Eli": 80.59
  },
  "buyer_bids": {
    "Buyer Lena": 80.6975444693222,
    "Buyer Kit": 79.79695564813244,
    "Buyer Mia": 79.40445941464131,
    "Buyer Nia": 79.3079465392273,
    "Buyer Omar": 79.26539932166843,
    "Buyer Ana": 80.6698080542224
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Yara",
      "price": 80.4
    },
    {
      "round_number": 14,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 80.63
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Amir": 97.58,
    "Seller Eli": 80.59,
    "Seller Raj": 97.63,
    "Seller Yara": 80.1,
    "Seller Maya": 97.65
  },
  "buyer_bids": {
    "Buyer Nia": 80.37565925340343,
    "Buyer Kit": 80.14313318780852,
    "Buyer Lena": 79.59652320327068,
    "Buyer Mia": 80.47065267550947,
    "Buyer Omar": 80.03694625725144,
    "Buyer Ana": 79.20309800369222
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Yara",
      "price": 80.29
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Amir": 97.59,
    "Seller Maya": 97.65,
    "Seller Raj": 97.63,
    "Seller Eli": 80.61,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Ana": 80.20441003730845,
    "Buyer Kit": 80.39628543988604,
    "Buyer Nia": 79.20671377592326,
    "Buyer Mia": 79.65764261886136,
    "Buyer Omar": 80.70154242056894,
    "Buyer Lena": 79.98201763666643
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.4
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Amir": 97.59,
    "Seller Maya": 97.62,
    "Seller Raj": 97.63,
    "Seller Eli": 80.62,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Ana": 80.16824948477682,
    "Buyer Omar": 80.08240532596075,
    "Buyer Lena": 79.84296637609536,
    "Buyer Kit": 79.27323593976521,
    "Buyer Mia": 79.62230748838975,
    "Buyer Nia": 79.69341698227707
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.13
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Amir": 97.63,
    "Seller Raj": 97.63,
    "Seller Yara": 80.1,
    "Seller Eli": 80.58
  },
  "buyer_bids": {
    "Buyer Nia": 80.19455220348055,
    "Buyer Ana": 80.73405447275076,
    "Buyer Kit": 79.34952584100758,
    "Buyer Lena": 80.54144228818474,
    "Buyer Mia": 80.29983272929556,
    "Buyer Omar": 79.44552889433837
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.42
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Amir": 97.58,
    "Seller Maya": 97.65,
    "Seller Eli": 80.65,
    "Seller Yara": 80.1,
    "Seller Raj": 97.63
  },
  "buyer_bids": {
    "Buyer Omar": 80.7169507876341,
    "Buyer Ana": 80.0292577694053,
    "Buyer Mia": 79.97907477038864,
    "Buyer Lena": 79.7247373002032,
    "Buyer Nia": 80.46145493834928,
    "Buyer Kit": 80.4496954011077
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Amir": 97.61,
    "Seller Maya": 97.65,
    "Seller Eli": 80.58
  },
  "buyer_bids": {
    "Buyer Ana": 79.6189398360977,
    "Buyer Mia": 80.24530340454618,
    "Buyer Kit": 80.75309378409095,
    "Buyer Nia": 80.59910923194565,
    "Buyer Omar": 79.74568165849563,
    "Buyer Lena": 80.3191580958122
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 80.67
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Maya": 97.67,
    "Seller Raj": 97.63,
    "Seller Amir": 97.63
  },
  "buyer_bids": {
    "Buyer Lena": 79.57064811597179,
    "Buyer Kit": 79.47313722486344,
    "Buyer Mia": 79.92542386812062,
    "Buyer Nia": 80.27289806672073,
    "Buyer Ana": 79.41072306825119,
    "Buyer Omar": 79.60474706928201
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Amir": 97.63,
    "Seller Eli": 80.63
  },
  "buyer_bids": {
    "Buyer Omar": 79.59481687822907,
    "Buyer Lena": 79.5651251509686,
    "Buyer Kit": 79.3176762610767,
    "Buyer Ana": 80.3421879582965,
    "Buyer Mia": 79.32868674506233,
    "Buyer Nia": 79.25024213784367
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Amir": 97.65,
    "Seller Raj": 97.63,
    "Seller Yara": 80.1,
    "Seller Eli": 80.63
  },
  "buyer_bids": {
    "Buyer Kit": 80.29529699591419,
    "Buyer Ana": 79.77572642870675,
    "Buyer Mia": 79.64597941072213,
    "Buyer Lena": 80.40108447080641,
    "Buyer Omar": 80.19825517784952,
    "Buyer Nia": 80.46653373003254
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Yara",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Eli": 80.58,
    "Seller Amir": 97.63,
    "Seller Maya": 97.65,
    "Seller Yara": 80.1,
    "Seller Raj": 97.63
  },
  "buyer_bids": {
    "Buyer Mia": 79.23168286301804,
    "Buyer Lena": 80.40093630828292,
    "Buyer Omar": 80.01933095125878,
    "Buyer Ana": 79.34051416207392,
    "Buyer Nia": 79.45637719763725,
    "Buyer Kit": 79.363057984111
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Yara",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Amir": 97.63,
    "Seller Raj": 97.63,
    "Seller Maya": 97.64
  },
  "buyer_bids": {
    "Buyer Omar": 79.23910416985436,
    "Buyer Lena": 79.80800433412134,
    "Buyer Kit": 79.92617235552939,
    "Buyer Mia": 80.05685334970664,
    "Buyer Ana": 80.27118349628928,
    "Buyer Nia": 79.36835888883297
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Raj": 97.63,
    "Seller Amir": 97.63,
    "Seller Eli": 80.65,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Lena": 80.26126738551443,
    "Buyer Omar": 80.61029927036782,
    "Buyer Kit": 80.13014561153918,
    "Buyer Ana": 80.68620906502085,
    "Buyer Nia": 80.14614861072582,
    "Buyer Mia": 80.67298612706408
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.39
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 80.66
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Amir": 97.63,
    "Seller Maya": 97.62,
    "Seller Yara": 80.1,
    "Seller Raj": 97.67,
    "Seller Eli": 80.63
  },
  "buyer_bids": {
    "Buyer Lena": 79.51742616701856,
    "Buyer Mia": 79.36802642710117,
    "Buyer Ana": 80.59895521027221,
    "Buyer Kit": 79.85960687519506,
    "Buyer Nia": 80.69191574301989,
    "Buyer Omar": 79.69323922418423
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Yara",
      "price": 80.4
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Yara": 80.1,
    "Seller Maya": 97.65,
    "Seller Raj": 97.63,
    "Seller Amir": 97.63,
    "Seller Eli": 80.66
  },
  "buyer_bids": {
    "Buyer Nia": 80.49929664673117,
    "Buyer Omar": 79.29598523867935,
    "Buyer Mia": 80.62326704965527,
    "Buyer Ana": 80.21967169625596,
    "Buyer Lena": 80.18169059841382,
    "Buyer Kit": 79.94134372721012
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Yara",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Raj": 97.67,
    "Seller Eli": 80.66,
    "Seller Yara": 80.13
  },
  "buyer_bids": {
    "Buyer Omar": 79.9847126387639,
    "Buyer Lena": 79.42346449796653,
    "Buyer Ana": 79.38522939171258,
    "Buyer Kit": 79.79743118753171,
    "Buyer Nia": 79.55066444581729,
    "Buyer Mia": 80.34547948197394
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Yara",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Maya": 97.65,
    "Seller Amir": 97.63,
    "Seller Yara": 80.13,
    "Seller Raj": 97.68,
    "Seller Eli": 80.67
  },
  "buyer_bids": {
    "Buyer Ana": 79.60665964033329,
    "Buyer Lena": 79.73517310191383,
    "Buyer Nia": 79.75190254920773,
    "Buyer Omar": 80.6203066840378,
    "Buyer Kit": 79.39673365450514,
    "Buyer Mia": 80.18646634638394
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
