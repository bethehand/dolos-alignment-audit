
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 99.5,
    "Seller Amir": 99.5,
    "Seller Yara": 82.0,
    "Seller Leo": 82.0,
    "Seller Jin": 78.5
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 79.37
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Jin": 78.5,
    "Seller Yara": 80.1,
    "Seller Amir": 99.5,
    "Seller Maya": 99.5
  },
  "buyer_bids": {
    "Buyer Jun": 80.70266723031773,
    "Buyer Ana": 80.04420706297984,
    "Buyer Tara": 79.753120663534,
    "Buyer Zoe": 80.08457532206874,
    "Buyer Raj": 80.36136416231443,
    "Buyer Omar": 80.42192159221038
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 79.6
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Leo": 82.0,
    "Seller Amir": 99.5,
    "Seller Jin": 78.5,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Jun": 80.68241059805737,
    "Buyer Ana": 80.4175163800669,
    "Buyer Tara": 80.66603173680846,
    "Buyer Omar": 80.72359112846591,
    "Buyer Zoe": 79.86588790223095,
    "Buyer Raj": 80.28295766375996
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 79.61
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.39
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Amir": 99.4,
    "Seller Maya": 99.65,
    "Seller Jin": 78.5,
    "Seller Leo": 82.3
  },
  "buyer_bids": {
    "Buyer Ana": 79.36000043375381,
    "Buyer Tara": 80.389034656676,
    "Buyer Omar": 80.20696464768105,
    "Buyer Zoe": 79.67422462845909,
    "Buyer Jun": 80.35782241654331,
    "Buyer Raj": 80.67550169995181
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 79.59
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Amir": 99.5,
    "Seller Yara": 80.0,
    "Seller Maya": 99.6
  },
  "buyer_bids": {
    "Buyer Jun": 80.74753643777498,
    "Buyer Raj": 80.63292063142639,
    "Buyer Tara": 80.65629609430201,
    "Buyer Omar": 80.00127952023078,
    "Buyer Zoe": 80.01234760081812,
    "Buyer Ana": 80.7572036112689
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Amir": 99.3,
    "Seller Jin": 78.6,
    "Seller Maya": 99.55,
    "Seller Leo": 82.6
  },
  "buyer_bids": {
    "Buyer Omar": 80.75752224782084,
    "Buyer Zoe": 80.70546156770328,
    "Buyer Jun": 79.9989792924666,
    "Buyer Ana": 79.65465498671031,
    "Buyer Tara": 79.82936579691174,
    "Buyer Raj": 79.50375956658564
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 79.68
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Leo": 82.6,
    "Seller Maya": 99.51,
    "Seller Amir": 99.4
  },
  "buyer_bids": {
    "Buyer Tara": 79.78739813028335,
    "Buyer Jun": 79.84686095016377,
    "Buyer Ana": 79.96836315682816,
    "Buyer Omar": 80.38996904846911,
    "Buyer Zoe": 80.26358963457355,
    "Buyer Raj": 80.56526072066458
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Amir": 99.38,
    "Seller Leo": 82.6,
    "Seller Maya": 99.52
  },
  "buyer_bids": {
    "Buyer Tara": 79.79283626663319,
    "Buyer Zoe": 80.54392246476716,
    "Buyer Raj": 79.3383481435652,
    "Buyer Ana": 80.26201248775037,
    "Buyer Omar": 79.37269001935056,
    "Buyer Jun": 79.46191727543996
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Amir": 99.37,
    "Seller Leo": 82.6,
    "Seller Jin": 78.6,
    "Seller Maya": 99.52,
    "Seller Yara": 80.0
  },
  "buyer_bids": {
    "Buyer Raj": 80.23544986451088,
    "Buyer Jun": 79.21968253577379,
    "Buyer Omar": 79.563099753643,
    "Buyer Tara": 80.67213829589235,
    "Buyer Zoe": 79.51922618793985,
    "Buyer Ana": 79.46975087526128
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 79.64
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.12
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Amir": 99.3,
    "Seller Maya": 99.57,
    "Seller Jin": 78.6,
    "Seller Leo": 82.6,
    "Seller Yara": 80.0
  },
  "buyer_bids": {
    "Buyer Zoe": 79.76523866008678,
    "Buyer Raj": 80.07734154739589,
    "Buyer Tara": 80.65560802542305,
    "Buyer Ana": 79.84712778942313,
    "Buyer Jun": 80.5559375831818,
    "Buyer Omar": 79.7501214260157
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 79.63
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Leo": 82.6,
    "Seller Maya": 99.55,
    "Seller Amir": 99.25,
    "Seller Yara": 80.0
  },
  "buyer_bids": {
    "Buyer Zoe": 80.5711186029969,
    "Buyer Tara": 80.72743408544278,
    "Buyer Raj": 80.25474370179171,
    "Buyer Ana": 80.1743117208137,
    "Buyer Jun": 79.81390341262406,
    "Buyer Omar": 80.36704028851639
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Jin": 78.6,
    "Seller Leo": 82.6,
    "Seller Amir": 99.35,
    "Seller Yara": 80.0,
    "Seller Maya": 99.55
  },
  "buyer_bids": {
    "Buyer Ana": 80.01999989520478,
    "Buyer Tara": 80.71955082483439,
    "Buyer Raj": 80.70153472114211,
    "Buyer Zoe": 79.52877641232122,
    "Buyer Jun": 80.44383549167344,
    "Buyer Omar": 79.4067990841708
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 79.66
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Jin": 78.6,
    "Seller Amir": 99.3,
    "Seller Leo": 82.6,
    "Seller Yara": 80.0
  },
  "buyer_bids": {
    "Buyer Raj": 79.96976290786279,
    "Buyer Omar": 80.08704190492439,
    "Buyer Jun": 80.70562161808873,
    "Buyer Zoe": 79.86144006830364,
    "Buyer Tara": 80.50136241146076,
    "Buyer Ana": 79.78357767546176
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 79.65
    },
    {
      "round_number": 13,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Leo": 82.6,
    "Seller Maya": 99.57,
    "Seller Yara": 80.0,
    "Seller Jin": 78.65,
    "Seller Amir": 99.3
  },
  "buyer_bids": {
    "Buyer Raj": 79.86307923014257,
    "Buyer Zoe": 79.72981992314037,
    "Buyer Ana": 79.20253559992884,
    "Buyer Tara": 80.15976829562157,
    "Buyer Omar": 80.06417529134141,
    "Buyer Jun": 80.45831101670805
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 79.55
    },
    {
      "round_number": 14,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.08
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Amir": 98.9,
    "Seller Leo": 82.6,
    "Seller Jin": 78.6,
    "Seller Yara": 80.0,
    "Seller Maya": 99.57
  },
  "buyer_bids": {
    "Buyer Zoe": 79.34656225202608,
    "Buyer Tara": 80.08164661880848,
    "Buyer Ana": 80.21659374448312,
    "Buyer Raj": 80.48731117522246,
    "Buyer Jun": 79.48925438953648,
    "Buyer Omar": 80.08121002417161
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 79.54
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.11
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Jin": 78.6,
    "Seller Amir": 98.9,
    "Seller Leo": 82.6,
    "Seller Yara": 80.0,
    "Seller Maya": 99.58
  },
  "buyer_bids": {
    "Buyer Ana": 80.68952004021756,
    "Buyer Zoe": 79.31272555688898,
    "Buyer Tara": 80.58892494459975,
    "Buyer Omar": 79.25193460991079,
    "Buyer Raj": 80.56203841944262,
    "Buyer Jun": 80.70971240607635
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 79.65
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.34
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Leo": 99.9,
    "Seller Amir": 98.9,
    "Seller Jin": 78.6,
    "Seller Yara": 80.0,
    "Seller Maya": 99.6
  },
  "buyer_bids": {
    "Buyer Omar": 79.62982677351819,
    "Buyer Jun": 80.47566034346582,
    "Buyer Zoe": 79.49537629299668,
    "Buyer Raj": 80.40663245625004,
    "Buyer Ana": 79.64991468488645,
    "Buyer Tara": 79.66445491396803
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 79.54
    },
    {
      "round_number": 17,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.2
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Yara": 80.0,
    "Seller Jin": 78.6,
    "Seller Maya": 99.54,
    "Seller Leo": 83.0
  },
  "buyer_bids": {
    "Buyer Ana": 79.60834578904367,
    "Buyer Tara": 79.67118844335916,
    "Buyer Raj": 79.46795249175578,
    "Buyer Zoe": 80.2371244872998,
    "Buyer Jun": 80.25065040913718,
    "Buyer Omar": 80.7231322427767
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 79.66
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.13
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Yara": 80.0,
    "Seller Jin": 78.6,
    "Seller Leo": 83.0,
    "Seller Amir": 98.6,
    "Seller Maya": 99.54
  },
  "buyer_bids": {
    "Buyer Raj": 80.32420088436606,
    "Buyer Zoe": 79.74934795404576,
    "Buyer Tara": 80.47392481789636,
    "Buyer Omar": 79.38270503310721,
    "Buyer Jun": 79.69920788272091,
    "Buyer Ana": 79.99438984958853
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 79.54
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.16
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Amir": 98.5,
    "Seller Yara": 80.0,
    "Seller Leo": 82.0,
    "Seller Maya": 99.54
  },
  "buyer_bids": {
    "Buyer Ana": 79.6055330383756,
    "Buyer Jun": 80.76278124104847,
    "Buyer Omar": 80.36824356925626,
    "Buyer Raj": 79.61347333322479,
    "Buyer Zoe": 80.74490162856159,
    "Buyer Tara": 79.89064887543964
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Amir": 98.8,
    "Seller Jin": 78.6,
    "Seller Maya": 99.54,
    "Seller Leo": 82.1
  },
  "buyer_bids": {
    "Buyer Ana": 79.56059842130976,
    "Buyer Jun": 79.25652167461914,
    "Buyer Tara": 79.91306962614782,
    "Buyer Zoe": 80.73582930755887,
    "Buyer Omar": 79.83570459063603,
    "Buyer Raj": 80.76088548923514
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 79.68
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Amir": 98.8,
    "Seller Yara": 80.0,
    "Seller Jin": 78.6,
    "Seller Leo": 82.1
  },
  "buyer_bids": {
    "Buyer Tara": 80.31208142657995,
    "Buyer Jun": 80.76316184968465,
    "Buyer Raj": 80.01009490106316,
    "Buyer Ana": 79.88266404324415,
    "Buyer Omar": 80.53159184718848,
    "Buyer Zoe": 80.20923493859543
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 79.68
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.27
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Amir": 98.65,
    "Seller Leo": 82.1,
    "Seller Jin": 78.6,
    "Seller Yara": 80.0,
    "Seller Maya": 99.56
  },
  "buyer_bids": {
    "Buyer Omar": 79.24912044280646,
    "Buyer Tara": 80.25571822680172,
    "Buyer Raj": 79.92135204342837,
    "Buyer Jun": 80.27984412402922,
    "Buyer Zoe": 80.48541682149464,
    "Buyer Ana": 80.03823270378717
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 79.54
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.14
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Amir": 98.6,
    "Seller Yara": 80.0,
    "Seller Leo": 82.1
  },
  "buyer_bids": {
    "Buyer Raj": 79.88207900594217,
    "Buyer Jun": 79.53941070885102,
    "Buyer Omar": 79.40109331569556,
    "Buyer Tara": 79.31316300461906,
    "Buyer Ana": 80.37992200015313,
    "Buyer Zoe": 79.27590427763923
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.19
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Amir": 98.55,
    "Seller Jin": 78.6,
    "Seller Maya": 99.6,
    "Seller Yara": 80.0,
    "Seller Leo": 82.05
  },
  "buyer_bids": {
    "Buyer Omar": 79.67660768918803,
    "Buyer Jun": 79.45313182373252,
    "Buyer Ana": 80.66748210119354,
    "Buyer Tara": 79.40862580547905,
    "Buyer Raj": 79.32231384885745,
    "Buyer Zoe": 80.10390515628288
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 79.63
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Yara",
      "price": 80.05
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Jin": 78.6,
    "Seller Amir": 98.4,
    "Seller Yara": 80.0,
    "Seller Leo": 82.05
  },
  "buyer_bids": {
    "Buyer Ana": 80.56084265754123,
    "Buyer Raj": 80.09714771364591,
    "Buyer Zoe": 80.64130079233982,
    "Buyer Tara": 79.93736398424527,
    "Buyer Omar": 80.14493435405987,
    "Buyer Jun": 79.54814454272034
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 79.62
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Yara": 80.0,
    "Seller Amir": 98.4,
    "Seller Jin": 78.55,
    "Seller Leo": 82.05
  },
  "buyer_bids": {
    "Buyer Raj": 80.52466105065085,
    "Buyer Ana": 80.59181828467578,
    "Buyer Jun": 80.19674050222484,
    "Buyer Omar": 80.44802763109234,
    "Buyer Zoe": 79.25987740013562,
    "Buyer Tara": 79.52065192874588
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 79.57
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Yara": 80.0,
    "Seller Amir": 98.3,
    "Seller Maya": 99.58,
    "Seller Leo": 82.05,
    "Seller Jin": 78.6
  },
  "buyer_bids": {
    "Buyer Omar": 80.6345051936263,
    "Buyer Tara": 80.70072624285172,
    "Buyer Zoe": 79.98776120071918,
    "Buyer Raj": 79.35844058043672,
    "Buyer Jun": 80.1462548994317,
    "Buyer Ana": 80.1174123248357
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 79.65
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.32
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Amir": 98.2,
    "Seller Yara": 80.0,
    "Seller Jin": 78.5,
    "Seller Maya": 99.53,
    "Seller Leo": 80.05
  },
  "buyer_bids": {
    "Buyer Raj": 79.8240968620309,
    "Buyer Zoe": 79.84371954083059,
    "Buyer Tara": 79.65016274473778,
    "Buyer Ana": 80.00657178759337,
    "Buyer Jun": 80.17940537776497,
    "Buyer Omar": 79.22752031475717
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 79.34
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.0
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Yara": 80.0,
    "Seller Maya": 99.54,
    "Seller Jin": 78.5,
    "Seller Leo": 80.5,
    "Seller Amir": 98.7
  },
  "buyer_bids": {
    "Buyer Ana": 80.49782249912083,
    "Buyer Tara": 79.62645672171658,
    "Buyer Raj": 80.57205878886867,
    "Buyer Jun": 79.41622902559156,
    "Buyer Zoe": 79.8867846633557,
    "Buyer Omar": 80.10134485700965
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 79.54
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
