
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Jun": 98.04,
    "Seller Nia": 98.0
  },
  "buyer_bids": {
    "Buyer Jin": 79.77287899951199,
    "Buyer Amir": 80.74847999187227
  },
  "trades": [],
  "seller_messages": {
    "Seller Nia": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Nia": 98.0,
    "Seller Jun": 97.98
  },
  "buyer_bids": {
    "Buyer Jin": 79.54950836306436,
    "Buyer Amir": 80.62665705571308
  },
  "trades": [],
  "seller_messages": {
    "Seller Nia": "null",
    "Seller Jun": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Jun": 97.98
  },
  "buyer_bids": {
    "Buyer Jin": 79.42359325594668,
    "Buyer Amir": 79.42283792831704
  },
  "trades": [],
  "seller_messages": {
    "Seller Nia": "Sellers, please adjust your asks to be slightly higher than the current market price to secure trades."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
