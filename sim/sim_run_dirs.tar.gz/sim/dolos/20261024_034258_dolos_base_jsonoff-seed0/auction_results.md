
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 98.6,
    "Seller Tara": 98.04,
    "Seller Kai": 97.62,
    "Seller Mia": 80.0,
    "Seller Eli": 97.31
  },
  "buyer_bids": {
    "Buyer Max": 80.09570188642384,
    "Buyer Jin": 79.31798789380596,
    "Buyer Amir": 79.35802135145464,
    "Buyer Leo": 79.76606612723079,
    "Buyer Nia": 80.56075812201482,
    "Buyer Jun": 79.7283155497568
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Tara": 98.5,
    "Seller Eli": 97.37,
    "Seller Mia": 80.4,
    "Seller Raj": 98.6
  },
  "buyer_bids": {
    "Buyer Amir": 79.70591471923454,
    "Buyer Leo": 80.034165814644,
    "Buyer Max": 79.90830937463414,
    "Buyer Nia": 79.5271643992258,
    "Buyer Jin": 80.22467744246734,
    "Buyer Jun": 80.08403788181555
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Kai": 98.5,
    "Seller Tara": 98.25,
    "Seller Raj": 98.5,
    "Seller Eli": 97.39
  },
  "buyer_bids": {
    "Buyer Jun": 80.54414594648867,
    "Buyer Leo": 80.45607641539758,
    "Buyer Amir": 80.66954383312105,
    "Buyer Nia": 79.34923498296386,
    "Buyer Max": 80.33640547781998,
    "Buyer Jin": 80.66559116857101
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Mia",
      "price": 80.53
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Kai": 98.04,
    "Seller Tara": 98.25,
    "Seller Eli": 97.65,
    "Seller Raj": 98.49,
    "Seller Mia": 80.4
  },
  "buyer_bids": {
    "Buyer Jun": 79.73301621966256,
    "Buyer Jin": 80.17903533570264,
    "Buyer Amir": 80.20042532683782,
    "Buyer Leo": 80.32582807386483,
    "Buyer Nia": 80.52490124544624,
    "Buyer Max": 80.36844572216516
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.46
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Eli": 97.66,
    "Seller Tara": 98.25,
    "Seller Mia": 80.45,
    "Seller Raj": 98.45
  },
  "buyer_bids": {
    "Buyer Jin": 80.6672303505839,
    "Buyer Amir": 79.30077483881792,
    "Buyer Max": 79.42799103025412,
    "Buyer Jun": 80.48535208663392,
    "Buyer Nia": 79.5547262339427,
    "Buyer Leo": 80.06878393230402
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.56
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Mia": 80.48,
    "Seller Eli": 97.4,
    "Seller Raj": 98.39,
    "Seller Kai": 98.25
  },
  "buyer_bids": {
    "Buyer Leo": 79.6657450760193,
    "Buyer Max": 79.68231486739239,
    "Buyer Amir": 80.78915448570316,
    "Buyer Jin": 80.60013965973783,
    "Buyer Jun": 79.98285884987185,
    "Buyer Nia": 80.7967546097378
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.64
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Kai": 98.25,
    "Seller Mia": 80.48,
    "Seller Eli": 97.66,
    "Seller Raj": 98.49
  },
  "buyer_bids": {
    "Buyer Leo": 79.66025162273633,
    "Buyer Amir": 79.73240082042774,
    "Buyer Jun": 80.47908337835295,
    "Buyer Nia": 79.52512296395109,
    "Buyer Jin": 80.67559956956248,
    "Buyer Max": 80.07556817039986
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.58
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Kai": 98.49,
    "Seller Mia": 80.48,
    "Seller Eli": 97.66,
    "Seller Raj": 98.45
  },
  "buyer_bids": {
    "Buyer Max": 79.49418995606175,
    "Buyer Jin": 80.47669603091362,
    "Buyer Amir": 79.34661135192259,
    "Buyer Nia": 79.70727495641293,
    "Buyer Leo": 80.51434754355823,
    "Buyer Jun": 79.58737144816314
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Mia",
      "price": 80.5
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Mia": 80.48,
    "Seller Eli": 97.67,
    "Seller Raj": 98.45
  },
  "buyer_bids": {
    "Buyer Jin": 80.77007958479713,
    "Buyer Leo": 79.40835912080729,
    "Buyer Max": 80.28595833489422,
    "Buyer Jun": 79.31053639757424,
    "Buyer Amir": 79.2527558638188,
    "Buyer Nia": 79.61608993383086
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.63
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Kai": 98.25,
    "Seller Eli": 97.66,
    "Seller Raj": 98.44,
    "Seller Mia": 98.2
  },
  "buyer_bids": {
    "Buyer Max": 80.29359741677398,
    "Buyer Jin": 79.32839730856625,
    "Buyer Amir": 79.26182651331973,
    "Buyer Jun": 80.52697737861395,
    "Buyer Nia": 80.31891648677686,
    "Buyer Leo": 80.54058436996084
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Raj": 98.44,
    "Seller Mia": 80.38,
    "Seller Kai": 98.24,
    "Seller Eli": 97.66
  },
  "buyer_bids": {
    "Buyer Jun": 80.52042127787786,
    "Buyer Jin": 79.54432207220839,
    "Buyer Amir": 79.57680277644975,
    "Buyer Leo": 79.64033730567172,
    "Buyer Max": 79.87107718681925,
    "Buyer Nia": 80.28715897309542
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.45
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Kai": 98.3,
    "Seller Raj": 98.45,
    "Seller Eli": 97.66,
    "Seller Tara": 98.0,
    "Seller Mia": 80.48
  },
  "buyer_bids": {
    "Buyer Jun": 80.77193661681801,
    "Buyer Jin": 80.22591491933177,
    "Buyer Leo": 79.71891974941234,
    "Buyer Nia": 80.32036083837679,
    "Buyer Amir": 79.98824861836725,
    "Buyer Max": 79.77178807356802
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.63
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Kai": 98.28,
    "Seller Eli": 97.67,
    "Seller Mia": 80.48
  },
  "buyer_bids": {
    "Buyer Jun": 79.50460615447801,
    "Buyer Jin": 80.13931952274021,
    "Buyer Leo": 79.63366073509616,
    "Buyer Max": 79.2259344426571,
    "Buyer Nia": 79.73643276506755,
    "Buyer Amir": 79.38455958946281
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Tara": 98.25,
    "Seller Raj": 98.55,
    "Seller Mia": 80.48,
    "Seller Kai": 98.28,
    "Seller Eli": 97.66
  },
  "buyer_bids": {
    "Buyer Jin": 79.79529630892972,
    "Buyer Leo": 80.45298961575457,
    "Buyer Max": 79.29950792909393,
    "Buyer Nia": 79.47277083793325,
    "Buyer Jun": 79.88180981655017,
    "Buyer Amir": 80.32853298450065
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Kai": 98.28,
    "Seller Eli": 97.67,
    "Seller Raj": 98.55,
    "Seller Mia": 98.34
  },
  "buyer_bids": {
    "Buyer Amir": 80.56851619121636,
    "Buyer Nia": 80.5073924848302,
    "Buyer Max": 80.69843154590366,
    "Buyer Jun": 80.21473026168366,
    "Buyer Jin": 79.55003769451659,
    "Buyer Leo": 80.16347277975784
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Raj": 98.5,
    "Seller Mia": 80.58,
    "Seller Kai": 98.3,
    "Seller Tara": 98.0,
    "Seller Eli": 97.66
  },
  "buyer_bids": {
    "Buyer Amir": 79.39910995525122,
    "Buyer Nia": 80.52813780994359,
    "Buyer Max": 79.34645096504855,
    "Buyer Jin": 79.50163299568102,
    "Buyer Jun": 79.39151275624286,
    "Buyer Leo": 80.53415108895918
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Raj": 98.5,
    "Seller Kai": 98.28,
    "Seller Eli": 97.7,
    "Seller Mia": 80.48
  },
  "buyer_bids": {
    "Buyer Jun": 80.75310706120696,
    "Buyer Max": 80.34898132233495,
    "Buyer Nia": 79.51134552909173,
    "Buyer Jin": 80.16880667235418,
    "Buyer Amir": 79.38567382140627,
    "Buyer Leo": 79.96677384627553
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.62
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Eli": 97.7,
    "Seller Raj": 98.56,
    "Seller Kai": 98.28
  },
  "buyer_bids": {
    "Buyer Max": 80.19295995356441,
    "Buyer Jin": 79.29773583337033,
    "Buyer Leo": 80.53744424891377,
    "Buyer Nia": 80.28695551184157,
    "Buyer Jun": 80.07077665836357,
    "Buyer Amir": 80.36344836712773
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Raj": 98.5,
    "Seller Mia": 98.34,
    "Seller Eli": 97.7,
    "Seller Kai": 98.28
  },
  "buyer_bids": {
    "Buyer Amir": 79.31515470322282,
    "Buyer Leo": 80.15437587619927,
    "Buyer Jun": 79.2976679027514,
    "Buyer Max": 79.94740996407722,
    "Buyer Nia": 79.89770983672521,
    "Buyer Jin": 79.68169845760218
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Raj": 98.49,
    "Seller Eli": 97.7,
    "Seller Mia": 98.34
  },
  "buyer_bids": {
    "Buyer Amir": 80.31891700015349,
    "Buyer Max": 79.95234585807712,
    "Buyer Leo": 80.64368677042106,
    "Buyer Jun": 80.64703781284807,
    "Buyer Nia": 79.61621320675081,
    "Buyer Jin": 79.82604191540904
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Raj": 98.38,
    "Seller Kai": 98.3,
    "Seller Eli": 97.7
  },
  "buyer_bids": {
    "Buyer Max": 80.46183726401568,
    "Buyer Jin": 80.3163153132515,
    "Buyer Amir": 80.11162966691762,
    "Buyer Nia": 79.52546349723994,
    "Buyer Jun": 80.42775734732211,
    "Buyer Leo": 79.45313380772382
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Tara": 98.0,
    "Seller Eli": 97.7,
    "Seller Raj": 98.5,
    "Seller Mia": 98.34
  },
  "buyer_bids": {
    "Buyer Amir": 79.45912651231662,
    "Buyer Nia": 79.38754055019368,
    "Buyer Leo": 79.22112601365596,
    "Buyer Max": 80.2649693152287,
    "Buyer Jin": 80.04715875686034,
    "Buyer Jun": 80.67426943114178
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Raj": 98.5,
    "Seller Mia": 98.35,
    "Seller Kai": 98.28
  },
  "buyer_bids": {
    "Buyer Jun": 80.25218591989199,
    "Buyer Max": 79.44546043349028,
    "Buyer Amir": 80.66801779641445,
    "Buyer Leo": 80.30531641259714,
    "Buyer Jin": 80.23829358049811,
    "Buyer Nia": 79.82182758853031
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Raj": 98.5,
    "Seller Eli": 97.7,
    "Seller Mia": 98.35
  },
  "buyer_bids": {
    "Buyer Jin": 80.41946664992724,
    "Buyer Nia": 79.97092333259852,
    "Buyer Jun": 80.17621704683158,
    "Buyer Max": 80.27744553517343,
    "Buyer Amir": 79.4157401709572,
    "Buyer Leo": 80.14444429811127
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Eli": 97.7,
    "Seller Tara": 98.0,
    "Seller Raj": 98.55,
    "Seller Mia": 98.35
  },
  "buyer_bids": {
    "Buyer Jun": 79.69647613034269,
    "Buyer Leo": 80.52624443353216,
    "Buyer Nia": 79.41175084967159,
    "Buyer Jin": 80.56603900934549,
    "Buyer Amir": 80.62710966627296,
    "Buyer Max": 80.39757740991615
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Eli": 97.7,
    "Seller Kai": 98.28,
    "Seller Raj": 98.6,
    "Seller Tara": 98.0,
    "Seller Mia": 98.35
  },
  "buyer_bids": {
    "Buyer Leo": 79.91701652262984,
    "Buyer Nia": 80.31773230236055,
    "Buyer Max": 79.55695651337385,
    "Buyer Jun": 79.45612764643927,
    "Buyer Jin": 80.15132308235538,
    "Buyer Amir": 79.32915697099595
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Kai": 98.28,
    "Seller Eli": 97.7,
    "Seller Raj": 98.65,
    "Seller Mia": 98.34
  },
  "buyer_bids": {
    "Buyer Jun": 79.25047276499589,
    "Buyer Max": 80.5947011077622,
    "Buyer Amir": 80.33655996174124,
    "Buyer Nia": 80.59926023977286,
    "Buyer Jin": 80.2780403204936,
    "Buyer Leo": 80.10795574686797
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Raj": 98.63,
    "Seller Mia": 98.34,
    "Seller Eli": 97.7,
    "Seller Tara": 98.0
  },
  "buyer_bids": {
    "Buyer Jun": 79.30221809457811,
    "Buyer Amir": 80.4354971487784,
    "Buyer Jin": 80.33440965469813,
    "Buyer Nia": 79.46507995659533,
    "Buyer Leo": 79.91418353948085,
    "Buyer Max": 80.32242586800679
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Raj": 98.65,
    "Seller Eli": 97.7,
    "Seller Mia": 98.34,
    "Seller Tara": 98.0,
    "Seller Kai": 98.28
  },
  "buyer_bids": {
    "Buyer Jun": 79.20011066059917,
    "Buyer Jin": 80.65286377145534,
    "Buyer Max": 79.26225629442433,
    "Buyer Leo": 79.72151024713585,
    "Buyer Amir": 80.61591281279641,
    "Buyer Nia": 80.16636382049899
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Raj": 98.66,
    "Seller Mia": 98.34,
    "Seller Eli": 97.75,
    "Seller Kai": 98.25,
    "Seller Tara": 98.0
  },
  "buyer_bids": {
    "Buyer Nia": 80.51635187715311,
    "Buyer Max": 79.86421985850336,
    "Buyer Jin": 79.27977119456584,
    "Buyer Leo": 80.07769930362011,
    "Buyer Amir": 80.54037894567124,
    "Buyer Jun": 80.75868301167984
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
