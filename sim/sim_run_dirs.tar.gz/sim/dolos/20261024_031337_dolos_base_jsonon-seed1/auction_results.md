
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 81.9,
    "Seller Amir": 82.25,
    "Seller Yara": 80.0,
    "Seller Leo": 96.62,
    "Seller Jin": 82.2
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Yara",
      "price": 80.12
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Yara": 82.7,
    "Seller Amir": 82.45,
    "Seller Jin": 82.0,
    "Seller Leo": 80.23927381684081,
    "Seller Maya": 81.9
  },
  "buyer_bids": {
    "Buyer Ana": 80.29837416668653,
    "Buyer Omar": 80.75046504047054,
    "Buyer Zoe": 80.04420706297984,
    "Buyer Tara": 80.42192159221038,
    "Buyer Jun": 80.36136416231443,
    "Buyer Raj": 80.60997417427545
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Leo",
      "price": 80.49
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Maya": 82.0,
    "Seller Yara": 82.2,
    "Seller Amir": 82.3,
    "Seller Jin": 80.75,
    "Seller Leo": 81.9
  },
  "buyer_bids": {
    "Buyer Tara": 80.72359112846591,
    "Buyer Zoe": 80.4175163800669,
    "Buyer Omar": 79.753120663534,
    "Buyer Raj": 80.70266723031773,
    "Buyer Ana": 80.08457532206874,
    "Buyer Jun": 80.28295766375996
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Yara": 82.4,
    "Seller Jin": 82.1,
    "Seller Maya": 81.9,
    "Seller Leo": 81.9
  },
  "buyer_bids": {
    "Buyer Zoe": 79.36000043375381,
    "Buyer Jun": 80.67550169995181,
    "Buyer Omar": 80.66603173680846,
    "Buyer Ana": 79.86588790223095,
    "Buyer Raj": 80.68241059805737,
    "Buyer Tara": 80.20696464768105
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Jin": 80.75,
    "Seller Yara": 82.6,
    "Seller Maya": 81.9,
    "Seller Leo": 81.9
  },
  "buyer_bids": {
    "Buyer Omar": 80.389034656676,
    "Buyer Jun": 80.63292063142639,
    "Buyer Zoe": 80.7572036112689,
    "Buyer Raj": 80.35782241654331,
    "Buyer Ana": 79.67422462845909,
    "Buyer Tara": 80.00127952023078
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 80.75
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Maya": 81.95,
    "Seller Yara": 82.65,
    "Seller Leo": 81.95,
    "Seller Amir": 82.45
  },
  "buyer_bids": {
    "Buyer Ana": 80.01234760081812,
    "Buyer Tara": 80.75752224782084,
    "Buyer Jun": 79.50375956658564,
    "Buyer Zoe": 79.65465498671031,
    "Buyer Omar": 80.65629609430201,
    "Buyer Raj": 80.74753643777498
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Leo": 81.95,
    "Seller Maya": 81.95,
    "Seller Amir": 82.45,
    "Seller Yara": 82.66
  },
  "buyer_bids": {
    "Buyer Raj": 79.9989792924666,
    "Buyer Tara": 80.38996904846911,
    "Buyer Omar": 79.82936579691174,
    "Buyer Ana": 80.70546156770328,
    "Buyer Jun": 80.56526072066458,
    "Buyer Zoe": 79.96836315682816
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Leo": 81.99,
    "Seller Yara": 82.65,
    "Seller Maya": 81.95,
    "Seller Amir": 82.35
  },
  "buyer_bids": {
    "Buyer Omar": 79.78739813028335,
    "Buyer Raj": 79.84686095016377,
    "Buyer Ana": 80.26358963457355,
    "Buyer Tara": 80.38114474266413,
    "Buyer Zoe": 80.44134023993594,
    "Buyer Jun": 80.61237123850633
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Yara": 82.66,
    "Seller Leo": 82.65,
    "Seller Amir": 82.5,
    "Seller Maya": 81.95
  },
  "buyer_bids": {
    "Buyer Omar": 79.37269001935056,
    "Buyer Zoe": 80.54392246476716,
    "Buyer Tara": 79.79283626663319,
    "Buyer Raj": 79.3383481435652,
    "Buyer Ana": 80.26201248775037,
    "Buyer Jun": 79.46191727543996
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Leo": 81.97,
    "Seller Yara": 82.66,
    "Seller Amir": 82.55,
    "Seller Maya": 81.95
  },
  "buyer_bids": {
    "Buyer Zoe": 80.18369714728813,
    "Buyer Tara": 80.1250814484787,
    "Buyer Omar": 79.69364708308437,
    "Buyer Ana": 79.95091222576484,
    "Buyer Raj": 80.37242529427499,
    "Buyer Jun": 80.5572825191401
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Yara": 82.65,
    "Seller Amir": 82.55,
    "Seller Maya": 81.95,
    "Seller Leo": 81.95
  },
  "buyer_bids": {
    "Buyer Zoe": 79.51922618793985,
    "Buyer Tara": 80.67213829589235,
    "Buyer Ana": 79.46975087526128,
    "Buyer Omar": 79.563099753643,
    "Buyer Raj": 80.23544986451088,
    "Buyer Jun": 79.21968253577379
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Yara": 82.65,
    "Seller Amir": 82.55,
    "Seller Maya": 81.95,
    "Seller Jin": 81.99,
    "Seller Leo": 81.98
  },
  "buyer_bids": {
    "Buyer Raj": 80.07734154739589,
    "Buyer Jun": 80.5559375831818,
    "Buyer Zoe": 79.76523866008678,
    "Buyer Ana": 79.84712778942313,
    "Buyer Tara": 80.65560802542305,
    "Buyer Omar": 79.7501214260157
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Yara": 82.65,
    "Seller Amir": 82.3,
    "Seller Leo": 82.85,
    "Seller Maya": 81.98
  },
  "buyer_bids": {
    "Buyer Jun": 79.81390341262406,
    "Buyer Tara": 80.72743408544278,
    "Buyer Raj": 80.25474370179171,
    "Buyer Zoe": 80.5711186029969,
    "Buyer Omar": 80.36704028851639,
    "Buyer Ana": 80.1743117208137
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Yara": 82.65,
    "Seller Maya": 81.98,
    "Seller Amir": 82.3,
    "Seller Leo": 82.66,
    "Seller Jin": 80.76
  },
  "buyer_bids": {
    "Buyer Ana": 79.4067990841708,
    "Buyer Raj": 80.01999989520478,
    "Buyer Tara": 79.96976290786279,
    "Buyer Zoe": 80.71955082483439,
    "Buyer Omar": 80.44383549167344,
    "Buyer Jun": 79.52877641232122
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Amir": 82.3,
    "Seller Yara": 82.65,
    "Seller Maya": 81.98,
    "Seller Leo": 82.7
  },
  "buyer_bids": {
    "Buyer Zoe": 80.50136241146076,
    "Buyer Tara": 79.86307923014257,
    "Buyer Jun": 79.86144006830364,
    "Buyer Raj": 79.78357767546176,
    "Buyer Omar": 80.70562161808873,
    "Buyer Ana": 80.08704190492439
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Leo": 81.95,
    "Seller Maya": 81.98,
    "Seller Yara": 82.65,
    "Seller Amir": 82.3
  },
  "buyer_bids": {
    "Buyer Zoe": 80.15976829562157,
    "Buyer Raj": 79.20253559992884,
    "Buyer Omar": 80.45831101670805,
    "Buyer Tara": 80.48731117522246,
    "Buyer Jun": 79.72981992314037,
    "Buyer Ana": 80.06417529134141
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Yara": 82.65,
    "Seller Jin": 80.76,
    "Seller Maya": 81.95,
    "Seller Amir": 82.3
  },
  "buyer_bids": {
    "Buyer Tara": 80.56203841944262,
    "Buyer Ana": 80.08121002417161,
    "Buyer Jun": 79.34656225202608,
    "Buyer Omar": 79.48925438953648,
    "Buyer Raj": 80.21659374448312,
    "Buyer Zoe": 80.08164661880848
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Jin": 81.99,
    "Seller Leo": 82.5,
    "Seller Yara": 82.65,
    "Seller Amir": 82.3
  },
  "buyer_bids": {
    "Buyer Omar": 80.70971240607635,
    "Buyer Zoe": 80.58892494459975,
    "Buyer Ana": 79.25193460991079,
    "Buyer Tara": 79.92479805963707,
    "Buyer Raj": 80.68952004021756,
    "Buyer Jun": 79.31272555688898
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Maya": 81.95,
    "Seller Leo": 82.66,
    "Seller Amir": 82.3
  },
  "buyer_bids": {
    "Buyer Omar": 79.62982677351819,
    "Buyer Jun": 80.47566034346582,
    "Buyer Zoe": 79.49537629299668,
    "Buyer Tara": 79.66445491396803,
    "Buyer Ana": 79.64991468488645,
    "Buyer Raj": 80.40663245625004
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Leo": 81.0,
    "Seller Amir": 82.3,
    "Seller Maya": 81.98
  },
  "buyer_bids": {
    "Buyer Tara": 79.67118844335916,
    "Buyer Zoe": 80.2371244872998,
    "Buyer Omar": 80.7231322427767,
    "Buyer Jun": 80.25065040913718,
    "Buyer Raj": 79.46795249175578,
    "Buyer Ana": 79.60834578904367
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Maya": 81.95,
    "Seller Amir": 82.4,
    "Seller Jin": 80.76,
    "Seller Leo": 81.0,
    "Seller Yara": 82.65
  },
  "buyer_bids": {
    "Buyer Omar": 79.38270503310721,
    "Buyer Raj": 80.32420088436606,
    "Buyer Tara": 80.47392481789636,
    "Buyer Ana": 79.99438984958853,
    "Buyer Zoe": 79.74934795404576,
    "Buyer Jun": 79.69920788272091
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Maya": 81.95,
    "Seller Jin": 80.77,
    "Seller Amir": 82.34,
    "Seller Yara": 82.65
  },
  "buyer_bids": {
    "Buyer Jun": 80.76278124104847,
    "Buyer Tara": 79.89064887543964,
    "Buyer Ana": 79.6055330383756,
    "Buyer Omar": 80.36824356925626,
    "Buyer Zoe": 80.74490162856159,
    "Buyer Raj": 79.61347333322479
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Maya": 81.85,
    "Seller Amir": 82.3,
    "Seller Jin": 80.77,
    "Seller Yara": 82.65,
    "Seller Leo": 81.25
  },
  "buyer_bids": {
    "Buyer Tara": 79.91306962614782,
    "Buyer Zoe": 80.73582930755887,
    "Buyer Omar": 79.83570459063603,
    "Buyer Raj": 80.76088548923514,
    "Buyer Jun": 79.25652167461914,
    "Buyer Ana": 79.56059842130976
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Maya": 81.95,
    "Seller Jin": 80.8,
    "Seller Amir": 82.34,
    "Seller Leo": 81.3
  },
  "buyer_bids": {
    "Buyer Tara": 80.31208142657995,
    "Buyer Jun": 80.76316184968465,
    "Buyer Zoe": 80.20923493859543,
    "Buyer Omar": 80.53159184718848,
    "Buyer Ana": 79.88266404324415,
    "Buyer Raj": 80.01009490106316
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Jin": 80.76,
    "Seller Maya": 81.85,
    "Seller Yara": 82.65,
    "Seller Leo": 81.1
  },
  "buyer_bids": {
    "Buyer Ana": 80.03823270378717,
    "Buyer Zoe": 80.48541682149464,
    "Buyer Tara": 80.25571822680172,
    "Buyer Jun": 80.27984412402922,
    "Buyer Raj": 79.92135204342837,
    "Buyer Omar": 79.24912044280646
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Jin": 80.77,
    "Seller Maya": 81.95,
    "Seller Leo": 81.8
  },
  "buyer_bids": {
    "Buyer Zoe": 79.27590427763923,
    "Buyer Omar": 79.40109331569556,
    "Buyer Ana": 80.37992200015313,
    "Buyer Raj": 79.88207900594217,
    "Buyer Jun": 79.53941070885102,
    "Buyer Tara": 79.31316300461906
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Maya": 81.95,
    "Seller Jin": 82.0,
    "Seller Leo": 80.25,
    "Seller Amir": 82.34
  },
  "buyer_bids": {
    "Buyer Raj": 79.32231384885745,
    "Buyer Tara": 79.40862580547905,
    "Buyer Ana": 80.66748210119354,
    "Buyer Zoe": 80.10390515628288,
    "Buyer Omar": 79.67660768918803,
    "Buyer Jun": 79.45313182373252
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Leo",
      "price": 80.46
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Maya": 81.95,
    "Seller Jin": 82.0,
    "Seller Amir": 82.34
  },
  "buyer_bids": {
    "Buyer Omar": 80.14493435405987,
    "Buyer Jun": 79.54814454272034,
    "Buyer Raj": 80.09714771364591,
    "Buyer Tara": 79.93736398424527,
    "Buyer Zoe": 80.64130079233982,
    "Buyer Ana": 80.56084265754123
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Jin": 80.75,
    "Seller Maya": 81.95,
    "Seller Yara": 82.65,
    "Seller Amir": 82.34,
    "Seller Leo": 81.75
  },
  "buyer_bids": {
    "Buyer Omar": 80.44802763109234,
    "Buyer Raj": 80.52466105065085,
    "Buyer Tara": 79.52065192874588,
    "Buyer Ana": 80.59181828467578,
    "Buyer Zoe": 79.25987740013562,
    "Buyer Jun": 80.19674050222484
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Jin": 80.75,
    "Seller Maya": 81.95,
    "Seller Leo": 80.0,
    "Seller Yara": 82.65,
    "Seller Amir": 82.34
  },
  "buyer_bids": {
    "Buyer Jun": 80.1462548994317,
    "Buyer Raj": 79.35844058043672,
    "Buyer Zoe": 79.98776120071918,
    "Buyer Omar": 80.6345051936263,
    "Buyer Tara": 80.70072624285172,
    "Buyer Ana": 80.1174123248357
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Leo",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
