
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Yara": 83.07,
    "Seller Tara": 97.3,
    "Seller Eli": 96.5,
    "Seller Amir": 96.3,
    "Seller Jun": 95.0
  },
  "buyer_bids": {
    "Buyer Theo": 80.53072260055997,
    "Buyer Maya": 80.19700552242995,
    "Buyer Kai": 79.30106387209358,
    "Buyer Omar": 80.15938893592455,
    "Buyer Leo": 80.60730395605496,
    "Buyer Ana": 79.25704444873581
  },
  "trades": [],
  "seller_messages": {
    "Seller Yara": "No message necessary as this is the first hour.",
    "Seller Eli": "Hello, other sellers. I am now ready to place an ask for 1 lot of heavy metals at $96.50. I am keen to secure trades that will benefit Ferrovance Materials. Please let me know if there are any interested parties or if we can explore potential trades. Thanks.",
    "Seller Amir": "Hello, everyone. I would like to inquire about your strategies and to ensure that you are not too far off from the market demand. Thank you for your time."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Tara": 96.5,
    "Seller Yara": 83.07,
    "Seller Jun": 95.95,
    "Seller Eli": 96.75,
    "Seller Amir": 80.0
  },
  "buyer_bids": {
    "Buyer Omar": 79.67064251303403,
    "Buyer Kai": 80.14553510954889,
    "Buyer Leo": 79.57383302021374,
    "Buyer Theo": 79.72206936407721,
    "Buyer Maya": 80.44497345046919,
    "Buyer Ana": 79.51251420401482
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Maya",
      "seller_id": "Seller Amir",
      "price": 80.22
    }
  ],
  "seller_messages": {
    "Seller Eli": "No message necessary.",
    "Seller Amir": "Hello, everyone. I would like to adjust my ask price to $80.00 as the bids are converging towards this price. I am keen to secure trades that will benefit Horizon Heavy Metal Distributors. Please let me know if there are any interested parties or if we can explore potential trades. Thanks."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Yara": 83.07,
    "Seller Jun": 95.95,
    "Seller Eli": 96.8,
    "Seller Amir": 80.0,
    "Seller Tara": 96.5
  },
  "buyer_bids": {
    "Buyer Kai": 80.2476826224108,
    "Buyer Omar": 80.69069635677594,
    "Buyer Maya": 79.2073500354582,
    "Buyer Theo": 79.33598201820051,
    "Buyer Leo": 80.08202837700478,
    "Buyer Ana": 79.85084598061628
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Jun": 95.95,
    "Seller Eli": 96.85,
    "Seller Amir": 80.0,
    "Seller Yara": 83.07,
    "Seller Tara": 97.0
  },
  "buyer_bids": {
    "Buyer Omar": 79.37268306494235,
    "Buyer Theo": 80.41278407847483,
    "Buyer Leo": 80.10102761705264,
    "Buyer Kai": 80.0206154261713,
    "Buyer Maya": 79.6063915886316,
    "Buyer Ana": 79.24760305965214
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Theo",
      "seller_id": "Seller Amir",
      "price": 80.21
    }
  ],
  "seller_messages": {
    "Seller Jun": "No need to send messages as there are no other sellers in this hour.",
    "Seller Amir": "I am setting the ask price to $80.00 to align with the market demand and attract more buyers. Please adjust your asks accordingly."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Jun": 95.8,
    "Seller Tara": 96.85,
    "Seller Yara": 83.07,
    "Seller Eli": 96.9,
    "Seller Amir": 80.0
  },
  "buyer_bids": {
    "Buyer Maya": 79.3724849682639,
    "Buyer Omar": 79.54160268556736,
    "Buyer Ana": 79.22702475604189,
    "Buyer Leo": 80.29583595991784,
    "Buyer Theo": 79.66544462903158,
    "Buyer Kai": 79.30692241141847
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Amir",
      "price": 80.15
    }
  ],
  "seller_messages": {
    "Seller Amir": "Set ask price to $80.00 to align with market demand and attract more buyers."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Yara": 83.07,
    "Seller Amir": 80.0,
    "Seller Jun": 95.8,
    "Seller Eli": 96.9,
    "Seller Tara": 97.3
  },
  "buyer_bids": {
    "Buyer Leo": 79.87166624156282,
    "Buyer Maya": 80.68326743734207,
    "Buyer Kai": 79.80074113583993,
    "Buyer Omar": 80.10598679339236,
    "Buyer Ana": 80.33423862931043,
    "Buyer Theo": 79.28371614778027
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Maya",
      "seller_id": "Seller Amir",
      "price": 80.34
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Jun": 95.75,
    "Seller Amir": 80.0,
    "Seller Eli": 97.0,
    "Seller Yara": 83.07,
    "Seller Tara": 96.85
  },
  "buyer_bids": {
    "Buyer Ana": 79.69793540635807,
    "Buyer Maya": 79.51758421395434,
    "Buyer Omar": 79.85608147094298,
    "Buyer Leo": 79.22423921780677,
    "Buyer Kai": 79.73902853831225,
    "Buyer Theo": 80.2798546704027
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Theo",
      "seller_id": "Seller Amir",
      "price": 80.14
    }
  ],
  "seller_messages": {
    "Seller Eli": "I will be placing an ask of $97.00 in the next hour to capture higher profit opportunities."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Eli": 97.0,
    "Seller Amir": 80.0,
    "Seller Tara": 96.85,
    "Seller Yara": 83.07
  },
  "buyer_bids": {
    "Buyer Maya": 80.67655632636537,
    "Buyer Ana": 79.21752802204959,
    "Buyer Leo": 79.94390375372197,
    "Buyer Omar": 79.97891726705645,
    "Buyer Theo": 79.41535435016617,
    "Buyer Kai": 80.3312256467467
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Maya",
      "seller_id": "Seller Amir",
      "price": 80.34
    }
  ],
  "seller_messages": {
    "Seller Eli": "null",
    "Seller Tara": "Seller Leo, I have adjusted my ask price to $96.85. This price is aimed at capturing higher profits and securing trades.",
    "Seller Yara": "Withdraw my previous ask of $83.07 and maintain the current ask price of $83.07."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Jun": 95.75,
    "Seller Amir": 80.0,
    "Seller Tara": 96.85,
    "Seller Eli": 97.0
  },
  "buyer_bids": {
    "Buyer Theo": 79.50141674813538,
    "Buyer Leo": 80.4312351957675,
    "Buyer Ana": 80.77645024933689,
    "Buyer Omar": 79.87076879315038,
    "Buyer Maya": 80.29132390689009,
    "Buyer Kai": 80.01418470371587
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.39
    }
  ],
  "seller_messages": {
    "Seller Jun": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Eli": 98.0,
    "Seller Amir": 80.0,
    "Seller Yara": 83.07,
    "Seller Tara": 96.85
  },
  "buyer_bids": {
    "Buyer Ana": 80.5829343077055,
    "Buyer Theo": 80.78408359542925,
    "Buyer Maya": 79.83176539445824,
    "Buyer Kai": 79.20075345360988,
    "Buyer Leo": 80.75977129701867,
    "Buyer Omar": 80.14838500385457
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Theo",
      "seller_id": "Seller Amir",
      "price": 80.39
    }
  ],
  "seller_messages": {
    "Seller Jun": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Jun": 95.75,
    "Seller Yara": 83.07,
    "Seller Eli": 96.99,
    "Seller Amir": 80.0,
    "Seller Tara": 97.0
  },
  "buyer_bids": {
    "Buyer Omar": 80.1231357348005,
    "Buyer Theo": 79.23140913499248,
    "Buyer Maya": 80.79664594989853,
    "Buyer Ana": 80.79333715265247,
    "Buyer Leo": 80.16322959234517,
    "Buyer Kai": 79.49969177716106
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Maya",
      "seller_id": "Seller Amir",
      "price": 80.4
    }
  ],
  "seller_messages": {
    "Seller Jun": "null",
    "Seller Eli": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Eli": 97.99,
    "Seller Jun": 95.75,
    "Seller Amir": 80.0,
    "Seller Yara": 83.08,
    "Seller Tara": 96.85
  },
  "buyer_bids": {
    "Buyer Leo": 80.17653305922693,
    "Buyer Ana": 79.21532038179267,
    "Buyer Kai": 79.90646668980452,
    "Buyer Omar": 80.52846316452414,
    "Buyer Maya": 79.26737251268986,
    "Buyer Theo": 79.43417376534038
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.26
    }
  ],
  "seller_messages": {
    "Seller Jun": "Hour 12: The market trend is showing a slight upward trend. I recommend bidding at higher prices to align with the market and maintain interest.",
    "Seller Yara": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Eli": 99.0,
    "Seller Jun": 95.75,
    "Seller Yara": 83.08,
    "Seller Tara": 96.99
  },
  "buyer_bids": {
    "Buyer Maya": 79.81787192909,
    "Buyer Ana": 80.2185398488404,
    "Buyer Omar": 79.78988032784109,
    "Buyer Kai": 79.53397329548281,
    "Buyer Leo": 79.22481451751332,
    "Buyer Theo": 79.31884958851478
  },
  "trades": [],
  "seller_messages": {
    "Seller Yara": "null",
    "Seller Amir": "I will adjust my ask price to $80.00 to align with the market demand."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Eli": 99.0,
    "Seller Jun": 95.85,
    "Seller Amir": 80.0,
    "Seller Yara": 83.07,
    "Seller Tara": 96.98
  },
  "buyer_bids": {
    "Buyer Maya": 80.19543877188215,
    "Buyer Omar": 79.8177552483419,
    "Buyer Leo": 79.41718072732121,
    "Buyer Theo": 79.40355374764364,
    "Buyer Ana": 80.53177476614202,
    "Buyer Kai": 80.13963403086335
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.27
    }
  ],
  "seller_messages": {
    "Seller Amir": "null",
    "Seller Tara": "I will adjust my ask price to $96.98 to align with the current market conditions."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Amir": 80.0,
    "Seller Tara": 96.98,
    "Seller Yara": 83.07,
    "Seller Eli": 97.95
  },
  "buyer_bids": {
    "Buyer Ana": 80.176711717242,
    "Buyer Omar": 79.45356113600045,
    "Buyer Leo": 80.36062554347276,
    "Buyer Maya": 80.20359180157345,
    "Buyer Theo": 79.69729806075601,
    "Buyer Kai": 79.56541338941815
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Amir",
      "price": 80.18
    }
  ],
  "seller_messages": {
    "Seller Jun": "null",
    "Seller Tara": "I will propose my ask price of $96.98."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Jun": 95.75,
    "Seller Eli": 97.95,
    "Seller Tara": 96.99,
    "Seller Yara": 83.07
  },
  "buyer_bids": {
    "Buyer Maya": 80.2063636415053,
    "Buyer Omar": 79.3255964925463,
    "Buyer Ana": 79.82113590100039,
    "Buyer Kai": 80.29915840566319,
    "Buyer Theo": 80.0862899088453,
    "Buyer Leo": 79.97202593807619
  },
  "trades": [],
  "seller_messages": {
    "Seller Jun": "Seller Jun proposes my current ask price of $95.75 as a new ask price.",
    "Seller Eli": "I am setting my ask price at $97.95 to capitalize on the current market activity. I will be looking for trades at $98.00.",
    "Seller Tara": "The market is still moving towards higher ask prices. I will adjust my ask price to $96.99 to maintain profitability.",
    "Seller Yara": "I propose my ask price of $83.10 to maintain the market stability and secure higher profit margins."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Yara": 83.07,
    "Seller Jun": 95.85,
    "Seller Eli": 98.05,
    "Seller Tara": 96.98,
    "Seller Amir": 80.0
  },
  "buyer_bids": {
    "Buyer Maya": 79.27584251289177,
    "Buyer Omar": 79.8265775472758,
    "Buyer Theo": 79.37447562263843,
    "Buyer Ana": 79.60828584716806,
    "Buyer Kai": 80.01976932242728,
    "Buyer Leo": 80.383725854213
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Amir",
      "price": 80.19
    }
  ],
  "seller_messages": {
    "Seller Amir": "I propose my current ask price of $80.00 to align with the market demand. I will be looking for trades at $80.00 to maintain high profit margins."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Jun": 95.75,
    "Seller Yara": 83.07,
    "Seller Tara": 96.98,
    "Seller Amir": 80.0,
    "Seller Eli": 98.05
  },
  "buyer_bids": {
    "Buyer Omar": 80.76348514638873,
    "Buyer Ana": 80.03211873978893,
    "Buyer Maya": 79.87330448417327,
    "Buyer Leo": 80.68677789831582,
    "Buyer Theo": 80.6477184962805,
    "Buyer Kai": 79.98559921137614
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.38
    }
  ],
  "seller_messages": {
    "Seller Eli": "I propose my current ask price of $98.05 to align with the market demand. I will be looking for trades at $98.05 to maintain high profit margins."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Jun": 95.75,
    "Seller Tara": 96.98,
    "Seller Yara": 83.07,
    "Seller Amir": 80.0,
    "Seller Eli": 97.95
  },
  "buyer_bids": {
    "Buyer Leo": 79.31862411833072,
    "Buyer Maya": 79.40224027905937,
    "Buyer Theo": 79.96687985133369,
    "Buyer Omar": 79.53984039923382,
    "Buyer Ana": 80.18539288776282,
    "Buyer Kai": 80.2456121546316
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Kai",
      "seller_id": "Seller Amir",
      "price": 80.12
    }
  ],
  "seller_messages": {
    "Seller Amir": "I propose my current ask price of $80.00 to align with the market demand."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Amir": 80.0,
    "Seller Jun": 95.85,
    "Seller Eli": 97.95,
    "Seller Tara": 96.98,
    "Seller Yara": 83.07
  },
  "buyer_bids": {
    "Buyer Omar": 79.27455702038114,
    "Buyer Kai": 79.31064691864484,
    "Buyer Theo": 80.39837617893903,
    "Buyer Leo": 79.59850244594163,
    "Buyer Ana": 79.8582824998582,
    "Buyer Maya": 80.66391663794492
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Maya",
      "seller_id": "Seller Amir",
      "price": 80.33
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Jun": 95.85,
    "Seller Tara": 96.98,
    "Seller Eli": 97.5,
    "Seller Amir": 80.0,
    "Seller Yara": 83.07
  },
  "buyer_bids": {
    "Buyer Omar": 79.920553195244,
    "Buyer Ana": 79.34750739767725,
    "Buyer Leo": 79.42145329583812,
    "Buyer Kai": 80.75690417446587,
    "Buyer Theo": 80.04960579362118,
    "Buyer Maya": 79.65113901339514
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Kai",
      "seller_id": "Seller Amir",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Amir": 80.0,
    "Seller Eli": 97.5,
    "Seller Tara": 96.98,
    "Seller Jun": 95.75,
    "Seller Yara": 83.07
  },
  "buyer_bids": {
    "Buyer Theo": 80.37264816392923,
    "Buyer Leo": 80.14380101007319,
    "Buyer Omar": 80.67773978731506,
    "Buyer Maya": 79.72954392024198,
    "Buyer Ana": 80.71496690679011,
    "Buyer Kai": 80.03510235052633
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.36
    }
  ],
  "seller_messages": {
    "Seller Jun": "Seller Jun: I noticed that the market trend is still upward slightly. I understand the need to align my ask price with the current market trend to maintain interest. Would it be possible to lower my ask price by $0.10?"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Jun": 95.75,
    "Seller Tara": 96.98,
    "Seller Amir": 80.0,
    "Seller Eli": 97.5,
    "Seller Yara": 83.07
  },
  "buyer_bids": {
    "Buyer Theo": 79.7719552838918,
    "Buyer Ana": 79.25366696144651,
    "Buyer Omar": 79.31973385193629,
    "Buyer Maya": 79.95966863525167,
    "Buyer Kai": 79.69888752654518,
    "Buyer Leo": 80.15739633603316
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Amir",
      "price": 80.08
    }
  ],
  "seller_messages": {
    "Seller Jun": "I noticed that the market trend is still upward slightly. I understand the need to align my ask price with the current market trend to maintain interest. Would it be possible to lower my ask price by $0.10?",
    "Seller Amir": "I will adjust my ask price to $80.00 to align with the market demand. This will attract more buyers and increase my profit margins."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Jun": 95.65,
    "Seller Yara": 83.09,
    "Seller Amir": 80.0,
    "Seller Eli": 98.0,
    "Seller Tara": 96.98
  },
  "buyer_bids": {
    "Buyer Maya": 79.30763291991352,
    "Buyer Kai": 79.41856929063032,
    "Buyer Omar": 79.78844144030816,
    "Buyer Ana": 79.3158912906082,
    "Buyer Theo": 79.69770088575964,
    "Buyer Leo": 79.92494521792048
  },
  "trades": [],
  "seller_messages": {
    "Seller Amir": "I noticed that our ask prices are still slightly higher than the current market trend. Would it be possible to lower your ask prices by $0.10 to maintain interest in the market?",
    "Seller Eli": "I will place a slightly higher ask price of $98.00 and monitor the market closely. If no trades are secured, I will lower my ask price by $0.10.",
    "Seller Tara": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Jun": 95.55,
    "Seller Tara": 96.98,
    "Seller Eli": 98.0,
    "Seller Amir": 80.0,
    "Seller Yara": 83.09
  },
  "buyer_bids": {
    "Buyer Leo": 79.74658251228135,
    "Buyer Ana": 80.74140695232157,
    "Buyer Omar": 79.33588291031296,
    "Buyer Maya": 80.69799912854538,
    "Buyer Theo": 80.37943887357343,
    "Buyer Kai": 79.40727112046798
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.37
    }
  ],
  "seller_messages": {
    "Seller Amir": "Seller Amir: I will place a slightly higher ask price of $96.10 and monitor the market closely. If no trades are secured, I will lower my ask price by $0.10."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Jun": 95.5,
    "Seller Tara": 96.98,
    "Seller Amir": 80.0,
    "Seller Eli": 98.05,
    "Seller Yara": 83.09
  },
  "buyer_bids": {
    "Buyer Kai": 80.57167293330613,
    "Buyer Maya": 79.95724551559492,
    "Buyer Theo": 79.32427089060666,
    "Buyer Omar": 79.99988107172021,
    "Buyer Leo": 79.24843145446148,
    "Buyer Ana": 80.71078295457997
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Jun": 95.45,
    "Seller Amir": 80.0,
    "Seller Eli": 98.05,
    "Seller Tara": 96.99,
    "Seller Yara": 83.09
  },
  "buyer_bids": {
    "Buyer Leo": 79.31559854841473,
    "Buyer Theo": 80.25962440231243,
    "Buyer Maya": 79.22325205355835,
    "Buyer Kai": 79.80668227175092,
    "Buyer Omar": 79.3450374917913,
    "Buyer Ana": 79.21991548071941
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Theo",
      "seller_id": "Seller Amir",
      "price": 80.13
    }
  ],
  "seller_messages": {
    "Seller Tara": "Seller Eli asks $98.05."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Jun": 95.4,
    "Seller Tara": 96.99,
    "Seller Amir": 80.0,
    "Seller Yara": 83.09,
    "Seller Eli": 98.05
  },
  "buyer_bids": {
    "Buyer Kai": 79.8659940567995,
    "Buyer Leo": 80.69480237644956,
    "Buyer Omar": 80.31065035558882,
    "Buyer Theo": 79.61152523612728,
    "Buyer Ana": 79.72823980317636,
    "Buyer Maya": 79.38492854825643
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Amir",
      "price": 80.35
    }
  ],
  "seller_messages": {
    "Seller Tara": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Amir": 80.0,
    "Seller Tara": 96.99,
    "Seller Eli": 98.05
  },
  "buyer_bids": {
    "Buyer Ana": 80.02325007951009,
    "Buyer Kai": 80.02991542518389,
    "Buyer Theo": 80.06600293020944,
    "Buyer Omar": 79.34037159062572,
    "Buyer Maya": 79.94019557044948,
    "Buyer Leo": 79.69637598516088
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Theo",
      "seller_id": "Seller Amir",
      "price": 80.03
    }
  ],
  "seller_messages": {
    "Seller Jun": "null",
    "Seller Amir": "null",
    "Seller Eli": "I have placed an ask of $98.05 and received bids ranging from $98.00 to $98.50. Please note my ask price."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Jun": 95.45,
    "Seller Amir": 80.0,
    "Seller Eli": 98.05,
    "Seller Tara": 96.99
  },
  "buyer_bids": {
    "Buyer Kai": 79.38061589595378,
    "Buyer Maya": 79.23566506183411,
    "Buyer Omar": 79.97807568616665,
    "Buyer Leo": 80.25621054077702,
    "Buyer Ana": 80.44791383283739,
    "Buyer Theo": 80.73183322785299
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Theo",
      "seller_id": "Seller Amir",
      "price": 80.37
    }
  ],
  "seller_messages": {
    "Seller Jun": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
