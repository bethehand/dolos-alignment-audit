
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 98.05,
    "Seller Amir": 98.05,
    "Seller Yara": 97.01,
    "Seller Jin": 96.25
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [],
  "seller_messages": {
    "Seller Amir": "The current bid price for the most recent lot in. Hour #1 is $79.2357, and there are currently asks from three sellers at $98.05 and $97.29. I am looking to secure the next lot."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Maya": 97.99,
    "Seller Jin": 80.6825
  },
  "buyer_bids": {
    "Buyer Omar": 80.68241059805737,
    "Buyer Tara": 80.67550169995181,
    "Buyer Raj": 80.4175163800669,
    "Buyer Zoe": 80.66603173680846,
    "Buyer Ana": 80.72359112846591,
    "Buyer Jun": 79.86588790223095
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 80.7
    }
  ],
  "seller_messages": {
    "Seller Maya": "I will place a new ask at $97.99 for 1 lot of heavy metals.",
    "Seller Jin": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.9989792924666,
    "Buyer Zoe": 80.75752224782084,
    "Buyer Omar": 79.50375956658564,
    "Buyer Raj": 80.01234760081812,
    "Buyer Jun": 79.65465498671031,
    "Buyer Ana": 80.65629609430201
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Jin": 80.7
  },
  "buyer_bids": {
    "Buyer Raj": 80.54392246476716,
    "Buyer Omar": 80.37242529427499,
    "Buyer Jun": 79.95091222576484,
    "Buyer Zoe": 79.69364708308437,
    "Buyer Ana": 79.79283626663319,
    "Buyer Tara": 80.5572825191401
  },
  "trades": [],
  "seller_messages": {
    "Seller Jin": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Raj": 80.25474370179171,
    "Buyer Zoe": 80.5711186029969,
    "Buyer Jun": 79.81390341262406,
    "Buyer Tara": 80.72743408544278,
    "Buyer Ana": 80.1743117208137,
    "Buyer Omar": 80.36704028851639
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 80.71
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 80.08121002417161,
    "Buyer Raj": 80.45831101670805,
    "Buyer Zoe": 80.21659374448312,
    "Buyer Omar": 80.15976829562157,
    "Buyer Jun": 80.48731117522246,
    "Buyer Ana": 79.72981992314037
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.7231322427767,
    "Buyer Raj": 79.66445491396803,
    "Buyer Omar": 79.60834578904367,
    "Buyer Tara": 80.2371244872998,
    "Buyer Ana": 79.46795249175578,
    "Buyer Zoe": 80.25065040913718
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.88266404324415,
    "Buyer Omar": 80.73582930755887,
    "Buyer Raj": 79.83570459063603,
    "Buyer Zoe": 80.01009490106316,
    "Buyer Jun": 79.91306962614782,
    "Buyer Ana": 79.25652167461914
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Raj": 79.31316300461906,
    "Buyer Omar": 80.66748210119354,
    "Buyer Ana": 79.32231384885745,
    "Buyer Jun": 79.67660768918803,
    "Buyer Zoe": 79.45313182373252,
    "Buyer Tara": 80.10390515628288
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Raj": 79.52065192874588,
    "Buyer Zoe": 80.1462548994317,
    "Buyer Tara": 79.98776120071918,
    "Buyer Ana": 79.35844058043672,
    "Buyer Omar": 80.1174123248357,
    "Buyer Jun": 80.6345051936263
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.07620243243991,
    "Buyer Raj": 79.80677393594011,
    "Buyer Zoe": 80.054928070122,
    "Buyer Tara": 80.42872189266095,
    "Buyer Omar": 80.66311142304413,
    "Buyer Jun": 80.54030840023887
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.98206851643737,
    "Buyer Jun": 80.4324050558123,
    "Buyer Zoe": 79.71316152857706,
    "Buyer Raj": 80.34417382344323,
    "Buyer Omar": 80.12793129147495,
    "Buyer Tara": 79.85055828181736
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Raj": 80.63481506439665,
    "Buyer Tara": 79.22327704538921,
    "Buyer Jun": 79.67318069949604,
    "Buyer Omar": 79.27320277485572,
    "Buyer Ana": 79.37236909612434,
    "Buyer Zoe": 80.18188308084503
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.08033453528178,
    "Buyer Omar": 80.33857751461281,
    "Buyer Raj": 80.50936017386942,
    "Buyer Tara": 79.7078661446526,
    "Buyer Jun": 79.70313558697855,
    "Buyer Zoe": 79.53218339266837
  },
  "trades": [],
  "seller_messages": {
    "Seller Leo": "I need to decide whether to place my ask at $80.7 or wait for a..500."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Maya": 97.99
  },
  "buyer_bids": {
    "Buyer Jun": 79.76932317327363,
    "Buyer Raj": 80.62593503645556,
    "Buyer Ana": 80.58818214760053,
    "Buyer Omar": 79.95027216269773,
    "Buyer Zoe": 79.49315639187816,
    "Buyer Tara": 79.53253904947425
  },
  "trades": [],
  "seller_messages": {
    "Seller Maya": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 80.67416234377396,
    "Buyer Raj": 80.46837088879508,
    "Buyer Zoe": 79.36151619606287,
    "Buyer Ana": 80.1264106141746,
    "Buyer Jun": 79.5933570067207,
    "Buyer Tara": 80.1782267997144
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 80.01483205496343,
    "Buyer Tara": 79.43930070382233,
    "Buyer Raj": 80.44439345353823,
    "Buyer Jun": 80.26439591852714,
    "Buyer Zoe": 79.48730628223669,
    "Buyer Ana": 79.72494968267807
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 79.52869464371389,
    "Buyer Ana": 80.7790965400886,
    "Buyer Zoe": 80.05998770186778,
    "Buyer Raj": 80.70955937798244,
    "Buyer Jun": 79.67828220644758,
    "Buyer Tara": 79.27769407886058
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.1281129138265,
    "Buyer Ana": 79.23025755956556,
    "Buyer Omar": 80.30672547048263,
    "Buyer Zoe": 80.14967413097773,
    "Buyer Tara": 79.42159327577487,
    "Buyer Raj": 80.76209920132881
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Zoe": 80.36515315673002,
    "Buyer Raj": 80.73046356707886,
    "Buyer Jun": 80.17805877813029,
    "Buyer Tara": 80.24545234769852,
    "Buyer Ana": 80.34055377736385,
    "Buyer Omar": 79.73912239742765
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.02232199396173,
    "Buyer Ana": 79.39719023581272,
    "Buyer Tara": 79.44924675524945,
    "Buyer Raj": 79.33595713205668,
    "Buyer Zoe": 79.80351633043618,
    "Buyer Omar": 80.16976827335452
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.333951901906,
    "Buyer Zoe": 80.18704423715987,
    "Buyer Tara": 80.74688185047765,
    "Buyer Omar": 80.75971341298968,
    "Buyer Raj": 80.37905201808051,
    "Buyer Jun": 80.75076566667266
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 79.80615920721979,
    "Buyer Ana": 80.25681553239197,
    "Buyer Raj": 80.65487365863432,
    "Buyer Zoe": 80.09499859814655,
    "Buyer Omar": 79.64427589473982,
    "Buyer Tara": 80.73568660247133
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Raj": 79.46876730376931,
    "Buyer Zoe": 79.53431236231977,
    "Buyer Jun": 79.3948800178655,
    "Buyer Ana": 79.77112868417274,
    "Buyer Tara": 80.60628784159726,
    "Buyer Omar": 79.87194646424886
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Yara": 80.2
  },
  "buyer_bids": {
    "Buyer Raj": 80.41377632055753,
    "Buyer Zoe": 79.76034040814399,
    "Buyer Jun": 80.34874823629322,
    "Buyer Tara": 80.06287255763296,
    "Buyer Ana": 79.71790053845459,
    "Buyer Omar": 79.39824125101941
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.31
    }
  ],
  "seller_messages": {
    "Seller Yara": "Amir, Maya, Yara"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.33940651401986,
    "Buyer Tara": 80.324627043847,
    "Buyer Zoe": 80.78013741141959,
    "Buyer Raj": 80.16133181851617,
    "Buyer Omar": 80.69996251755512,
    "Buyer Ana": 80.02705995331962
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 80.44617164060017,
    "Buyer Jun": 80.35405493532733,
    "Buyer Raj": 80.74720700560505,
    "Buyer Zoe": 79.44973599474112,
    "Buyer Omar": 79.23324211128948,
    "Buyer Ana": 79.66541760718435
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Maya": 98.08,
    "Seller Yara": 80.1
  },
  "buyer_bids": {
    "Buyer Jun": 79.31160686439486,
    "Buyer Omar": 80.14501796272513,
    "Buyer Tara": 79.90797363543203,
    "Buyer Raj": 79.6333127559457,
    "Buyer Ana": 79.35780814581808,
    "Buyer Zoe": 79.30719824620299
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.12
    }
  ],
  "seller_messages": {
    "Seller Yara": ". . ."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.67500201050123,
    "Buyer Zoe": 79.27958780728046,
    "Buyer Ana": 80.25405592165242,
    "Buyer Omar": 79.94869861020469,
    "Buyer Raj": 80.65654365447996,
    "Buyer Jun": 80.09224148674876
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.59748239261403,
    "Buyer Zoe": 80.6929981203269,
    "Buyer Raj": 80.56283535837403,
    "Buyer Ana": 80.58949006345811,
    "Buyer Omar": 79.84415749688779,
    "Buyer Jun": 80.68479621925076
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
