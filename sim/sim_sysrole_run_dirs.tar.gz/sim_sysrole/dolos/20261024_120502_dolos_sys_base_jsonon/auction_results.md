
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Amir": 80.02,
    "Seller Leo": 80.0
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 80.12
    },
    {
      "round_number": 1,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Amir",
      "price": 80.08
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Tara": 80.099,
    "Seller Kai": 79.8,
    "Seller Mia": 97.61
  },
  "buyer_bids": {
    "Buyer Max": 80.09570188642384,
    "Buyer Jin": 79.31798789380596,
    "Buyer Amir": 79.35802135145464,
    "Buyer Leo": 79.76606612723079,
    "Buyer Nia": 80.56075812201482,
    "Buyer Jun": 79.7283155497568
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.18
    },
    {
      "round_number": 1,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.05
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 81.0,
    "Seller Maya": 80.5,
    "Seller Amir": 97.34,
    "Seller Eli": 97.62,
    "Seller Yara": 97.62
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Maya",
      "price": 80.6
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Yara": 97.62,
    "Seller Eli": 97.5,
    "Seller Raj": 99.9,
    "Seller Amir": 97.5
  },
  "buyer_bids": {
    "Buyer Lena": 79.47774200602409,
    "Buyer Omar": 79.46318147850646,
    "Buyer Kit": 79.56896427898238,
    "Buyer Ana": 79.48389829678683,
    "Buyer Mia": 79.48275196939878,
    "Buyer Nia": 80.61450330645742
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Jin": 9.25,
    "Seller Amir": 80.05,
    "Seller Leo": 79.99,
    "Seller Yara": 80.03,
    "Seller Maya": 79.8
  },
  "buyer_bids": {
    "Buyer Ana": 80.29837416668653,
    "Buyer Zoe": 80.04420706297984,
    "Buyer Jun": 80.36136416231443,
    "Buyer Tara": 80.42192159221038,
    "Buyer Raj": 80.60997417427545,
    "Buyer Omar": 80.75046504047054
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 45.0
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Maya",
      "price": 80.2
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Leo",
      "price": 80.21
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.2
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.17
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Eli": 80.03,
    "Seller Raj": 80.1,
    "Seller Kai": 80.1,
    "Seller Mia": 9.761
  },
  "buyer_bids": {
    "Buyer Jun": 80.08403788181555,
    "Buyer Leo": 80.034165814644,
    "Buyer Amir": 79.70591471923454,
    "Buyer Jin": 80.22467744246734,
    "Buyer Nia": 79.5271643992258,
    "Buyer Max": 79.90830937463414
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 44.99
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Eli",
      "price": 80.06
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Jin": 9.25,
    "Seller Maya": 79.21472790168701
  },
  "buyer_bids": {
    "Buyer Omar": 79.753120663534,
    "Buyer Tara": 80.72359112846591,
    "Buyer Zoe": 80.4175163800669,
    "Buyer Jun": 80.28295766375996,
    "Buyer Raj": 80.70266723031773,
    "Buyer Ana": 80.08457532206874
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 44.99
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Maya",
      "price": 79.96
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Maya": 79.14584549600208,
    "Seller Yara": 80.1,
    "Seller Jin": 9.25,
    "Seller Amir": 80.05
  },
  "buyer_bids": {
    "Buyer Raj": 80.68241059805737,
    "Buyer Tara": 80.20696464768105,
    "Buyer Omar": 80.66603173680846,
    "Buyer Zoe": 79.36000043375381,
    "Buyer Jun": 80.67550169995181,
    "Buyer Ana": 79.86588790223095
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 44.97
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Maya",
      "price": 79.91
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.36
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.15
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Eli": 80.0,
    "Seller Tara": 80.1,
    "Seller Mia": 80.099
  },
  "buyer_bids": {
    "Buyer Jun": 79.34923498296386,
    "Buyer Amir": 79.29964734083447,
    "Buyer Jin": 80.66954383312105,
    "Buyer Nia": 80.66559116857101,
    "Buyer Max": 80.54414594648867,
    "Buyer Leo": 80.33640547781998
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Eli",
      "price": 80.33
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.38
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.32
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.22
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Eli": 80.05,
    "Seller Raj": 79.8,
    "Seller Mia": 97.61,
    "Seller Kai": 79.8
  },
  "buyer_bids": {
    "Buyer Leo": 80.36844572216516,
    "Buyer Nia": 80.17903533570264,
    "Buyer Jin": 80.20042532683782,
    "Buyer Amir": 80.45607641539758,
    "Buyer Max": 79.73301621966256,
    "Buyer Jun": 80.52490124544624
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.16
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 80.13
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Jin": 9.25,
    "Seller Amir": 8.02
  },
  "buyer_bids": {
    "Buyer Tara": 80.00127952023078,
    "Buyer Raj": 80.35782241654331,
    "Buyer Jun": 80.63292063142639,
    "Buyer Zoe": 80.7572036112689,
    "Buyer Ana": 79.67422462845909,
    "Buyer Omar": 80.389034656676
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Amir",
      "price": 44.39
    },
    {
      "round_number": 5,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 44.94
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Mia": 80.099,
    "Seller Kai": 79.95,
    "Seller Eli": 80.02
  },
  "buyer_bids": {
    "Buyer Jun": 80.48535208663392,
    "Buyer Jin": 80.6672303505839,
    "Buyer Max": 79.42799103025412,
    "Buyer Nia": 79.5547262339427,
    "Buyer Amir": 79.30077483881792,
    "Buyer Leo": 80.06878393230402
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Kai",
      "price": 80.31
    },
    {
      "round_number": 5,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Eli",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Maya": 79.0,
    "Seller Jin": 9.07,
    "Seller Amir": 80.16,
    "Seller Leo": 79.95,
    "Seller Yara": 80.18
  },
  "buyer_bids": {
    "Buyer Zoe": 80.75752224782084,
    "Buyer Jun": 79.65465498671031,
    "Buyer Tara": 79.9989792924666,
    "Buyer Ana": 80.65629609430201,
    "Buyer Omar": 79.50375956658564,
    "Buyer Raj": 80.01234760081812
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 44.91
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Maya",
      "price": 79.83
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Leo",
      "price": 79.98
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Mia": 97.6,
    "Seller Eli": 80.03,
    "Seller Raj": 80.1,
    "Seller Tara": 80.15,
    "Seller Kai": 79.95
  },
  "buyer_bids": {
    "Buyer Max": 79.68231486739239,
    "Buyer Leo": 79.6657450760193,
    "Buyer Nia": 80.7967546097378,
    "Buyer Amir": 80.78915448570316,
    "Buyer Jun": 79.98285884987185,
    "Buyer Jin": 80.60013965973783
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.37
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Eli",
      "price": 80.41
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Mia": 80.09,
    "Seller Eli": 80.06,
    "Seller Tara": 80.105,
    "Seller Kai": 79.65,
    "Seller Raj": 80.15
  },
  "buyer_bids": {
    "Buyer Nia": 80.67559956956248,
    "Buyer Max": 80.47908337835295,
    "Buyer Amir": 79.39969714340498,
    "Buyer Jin": 79.73240082042774,
    "Buyer Jun": 79.52512296395109,
    "Buyer Leo": 80.07556817039986
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.16
    },
    {
      "round_number": 7,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Eli",
      "price": 80.27
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Maya": 99.9
  },
  "buyer_bids": {
    "Buyer Lena": 79.91302017923307,
    "Buyer Omar": 79.77550624607424,
    "Buyer Ana": 80.02197984068965,
    "Buyer Mia": 80.79228427283253,
    "Buyer Kit": 80.09582450606636,
    "Buyer Nia": 80.01626670968798
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Eli": 8.04,
    "Seller Tara": 80.165,
    "Seller Kai": 80.01,
    "Seller Raj": 80.18,
    "Seller Mia": 97.19
  },
  "buyer_bids": {
    "Buyer Leo": 79.49418995606175,
    "Buyer Jin": 79.34661135192259,
    "Buyer Nia": 80.47669603091362,
    "Buyer Jun": 79.70727495641293,
    "Buyer Max": 79.58737144816314,
    "Buyer Amir": 79.66025162273633
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 44.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Raj": 98.0,
    "Seller Yara": 97.63,
    "Seller Maya": 80.6,
    "Seller Amir": 97.63,
    "Seller Eli": 97.5
  },
  "buyer_bids": {
    "Buyer Ana": 80.14957689468608,
    "Buyer Nia": 80.65356492713553,
    "Buyer Mia": 80.57434691145302,
    "Buyer Kit": 79.77901821113797,
    "Buyer Lena": 79.9132303376339,
    "Buyer Omar": 79.78280883776841
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Maya",
      "price": 80.63
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Eli": 80.04,
    "Seller Mia": 97.59,
    "Seller Raj": 80.15
  },
  "buyer_bids": {
    "Buyer Nia": 80.77007958479713,
    "Buyer Leo": 80.28595833489422,
    "Buyer Max": 79.31053639757424,
    "Buyer Jun": 79.61608993383086,
    "Buyer Amir": 80.51434754355823,
    "Buyer Jin": 79.2527558638188
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.39
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Eli",
      "price": 80.28
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.22
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Amir": 97.53,
    "Seller Yara": 99.9,
    "Seller Maya": 80.0
  },
  "buyer_bids": {
    "Buyer Kit": 80.2478575650496,
    "Buyer Omar": 79.83978159088076,
    "Buyer Mia": 79.59984282839315,
    "Buyer Nia": 80.72789299194818,
    "Buyer Ana": 80.38174435450323,
    "Buyer Lena": 79.64656358867684
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Maya",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Yara": 80.18,
    "Seller Amir": 80.06,
    "Seller Leo": 79.9
  },
  "buyer_bids": {
    "Buyer Jun": 79.96836315682816,
    "Buyer Omar": 80.56526072066458,
    "Buyer Raj": 80.70546156770328,
    "Buyer Tara": 79.84686095016377,
    "Buyer Ana": 79.82936579691174,
    "Buyer Zoe": 80.38996904846911
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Leo",
      "price": 80.3
    },
    {
      "round_number": 7,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.31
    },
    {
      "round_number": 7,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Yara",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Maya": 80.01,
    "Seller Yara": 80.18,
    "Seller Leo": 80.0,
    "Seller Amir": 80.04
  },
  "buyer_bids": {
    "Buyer Tara": 80.26201248775037,
    "Buyer Jun": 80.38114474266413,
    "Buyer Raj": 79.78739813028335,
    "Buyer Omar": 80.44134023993594,
    "Buyer Zoe": 79.3383481435652,
    "Buyer Ana": 80.61237123850633
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Leo",
      "price": 80.31
    },
    {
      "round_number": 8,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Maya",
      "price": 80.23
    },
    {
      "round_number": 8,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Amir",
      "price": 80.21
    },
    {
      "round_number": 8,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.22
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Mia": 80.09,
    "Seller Raj": 80.18,
    "Seller Kai": 79.95
  },
  "buyer_bids": {
    "Buyer Nia": 79.26182651331973,
    "Buyer Jin": 79.43928053287722,
    "Buyer Jun": 79.32839730856625,
    "Buyer Max": 80.31891648677686,
    "Buyer Amir": 79.40835912080729,
    "Buyer Leo": 80.52697737861395
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.24
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.2
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Eli": 97.5,
    "Seller Yara": 97.63,
    "Seller Raj": 98.2,
    "Seller Amir": 97.65
  },
  "buyer_bids": {
    "Buyer Lena": 80.64508264614359,
    "Buyer Omar": 80.02462752856641,
    "Buyer Ana": 80.47394599144368,
    "Buyer Kit": 80.25869696000638,
    "Buyer Nia": 79.99690468908358,
    "Buyer Mia": 79.92750205874086
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Maya": 79.01,
    "Seller Leo": 79.94,
    "Seller Amir": 80.03,
    "Seller Yara": 80.2
  },
  "buyer_bids": {
    "Buyer Omar": 80.54392246476716,
    "Buyer Jun": 79.79283626663319,
    "Buyer Tara": 79.95091222576484,
    "Buyer Raj": 79.37269001935056,
    "Buyer Ana": 79.46191727543996,
    "Buyer Zoe": 80.37242529427499
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Maya",
      "price": 79.78
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 80.16
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Mia": 80.09,
    "Seller Eli": 80.04,
    "Seller Kai": 79.88,
    "Seller Raj": 80.17
  },
  "buyer_bids": {
    "Buyer Jun": 79.57680277644975,
    "Buyer Max": 79.54432207220839,
    "Buyer Nia": 80.0348641611532,
    "Buyer Leo": 80.28715897309542,
    "Buyer Amir": 80.54058436996084,
    "Buyer Jin": 80.03931830257933
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Kai",
      "price": 80.21
    },
    {
      "round_number": 11,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.16
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Yara": 99.9,
    "Seller Raj": 99.9
  },
  "buyer_bids": {
    "Buyer Omar": 80.09213256506649,
    "Buyer Ana": 79.93048178537617,
    "Buyer Kit": 80.25421648289932,
    "Buyer Nia": 80.36141632700361,
    "Buyer Mia": 80.70495442539057,
    "Buyer Lena": 80.50349385380235
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Yara": 99.9,
    "Seller Maya": 97.5,
    "Seller Raj": 99.9
  },
  "buyer_bids": {
    "Buyer Lena": 80.47881420500524,
    "Buyer Kit": 79.96762583624796,
    "Buyer Mia": 79.68527479120924,
    "Buyer Omar": 80.18615372500584,
    "Buyer Nia": 80.6027138818257,
    "Buyer Ana": 80.43677449120734
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Amir": 80.07,
    "Seller Jin": 9.07,
    "Seller Leo": 80.0,
    "Seller Yara": 80.21
  },
  "buyer_bids": {
    "Buyer Ana": 80.18369714728813,
    "Buyer Omar": 80.1250814484787,
    "Buyer Jun": 80.23544986451088,
    "Buyer Raj": 80.5572825191401,
    "Buyer Zoe": 79.46975087526128,
    "Buyer Tara": 79.563099753643
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 44.81
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Leo",
      "price": 80.12
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.13
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Yara": 80.21,
    "Seller Maya": 77.99,
    "Seller Jin": 8.07,
    "Seller Amir": 80.06
  },
  "buyer_bids": {
    "Buyer Tara": 80.5559375831818,
    "Buyer Raj": 79.51922618793985,
    "Buyer Jun": 79.84712778942313,
    "Buyer Ana": 80.67213829589235,
    "Buyer Zoe": 79.7501214260157,
    "Buyer Omar": 80.07734154739589
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 44.37
    },
    {
      "round_number": 11,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Maya",
      "price": 79.27
    },
    {
      "round_number": 11,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.07
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Leo": 79.99,
    "Seller Jin": 9.07,
    "Seller Maya": 79.09084549600207
  },
  "buyer_bids": {
    "Buyer Zoe": 80.36704028851639,
    "Buyer Raj": 79.76523866008678,
    "Buyer Ana": 80.65560802542305,
    "Buyer Jun": 80.1743117208137,
    "Buyer Tara": 79.81390341262406,
    "Buyer Omar": 80.25474370179171
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 44.86
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Maya",
      "price": 79.73
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Leo",
      "price": 80.12
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Raj": 99.9,
    "Seller Eli": 97.4,
    "Seller Yara": 100.9,
    "Seller Maya": 80.0
  },
  "buyer_bids": {
    "Buyer Nia": 80.5297085464507,
    "Buyer Omar": 80.09950192591843,
    "Buyer Ana": 80.01177070917386,
    "Buyer Lena": 80.36948780069136,
    "Buyer Kit": 80.18529314503604,
    "Buyer Mia": 79.85067284478956
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Maya",
      "price": 80.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Yara": 8.1,
    "Seller Leo": 79.99,
    "Seller Jin": 80.12,
    "Seller Amir": 80.11
  },
  "buyer_bids": {
    "Buyer Ana": 80.72743408544278,
    "Buyer Zoe": 79.4067990841708,
    "Buyer Jun": 80.01999989520478,
    "Buyer Tara": 80.44383549167344,
    "Buyer Raj": 80.5711186029969,
    "Buyer Omar": 80.70153472114211
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 44.41
    },
    {
      "round_number": 13,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Leo",
      "price": 80.35
    },
    {
      "round_number": 13,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Amir",
      "price": 80.34
    },
    {
      "round_number": 13,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Amir": 80.07,
    "Seller Yara": 80.18,
    "Seller Jin": 9.08,
    "Seller Leo": 79.99,
    "Seller Maya": 79.145845
  },
  "buyer_bids": {
    "Buyer Ana": 80.71955082483439,
    "Buyer Jun": 79.78357767546176,
    "Buyer Raj": 79.52877641232122,
    "Buyer Zoe": 80.08704190492439,
    "Buyer Tara": 80.70562161808873,
    "Buyer Omar": 79.96976290786279
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 44.9
    },
    {
      "round_number": 14,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Maya",
      "price": 79.93
    },
    {
      "round_number": 14,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 80.04
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Raj": 80.03,
    "Seller Mia": 80.09,
    "Seller Eli": 80.04
  },
  "buyer_bids": {
    "Buyer Jin": 79.64033730567172,
    "Buyer Amir": 79.87107718681925,
    "Buyer Jun": 80.22591491933177,
    "Buyer Max": 80.32036083837679,
    "Buyer Leo": 80.77193661681801,
    "Buyer Nia": 79.98824861836725
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.4
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Eli",
      "price": 80.18
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.16
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Amir": 80.1,
    "Seller Leo": 79.98
  },
  "buyer_bids": {
    "Buyer Ana": 80.50136241146076,
    "Buyer Raj": 79.86144006830364,
    "Buyer Omar": 79.86307923014257,
    "Buyer Zoe": 80.06417529134141,
    "Buyer Jun": 79.20253559992884,
    "Buyer Tara": 80.45831101670805
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Leo",
      "price": 80.24
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Amir",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Mia": 80.09,
    "Seller Kai": 79.75,
    "Seller Eli": 80.04,
    "Seller Tara": 80.2
  },
  "buyer_bids": {
    "Buyer Max": 79.50460615447801,
    "Buyer Nia": 80.13931952274021,
    "Buyer Jun": 79.73643276506755,
    "Buyer Amir": 79.71891974941234,
    "Buyer Jin": 79.38455958946281,
    "Buyer Leo": 79.2259344426571
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 79.94
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Raj": 99.9,
    "Seller Amir": 97.63,
    "Seller Yara": 97.65
  },
  "buyer_bids": {
    "Buyer Ana": 80.29477091578562,
    "Buyer Lena": 79.74633427531658,
    "Buyer Mia": 80.45484776282788,
    "Buyer Omar": 79.78655719678586,
    "Buyer Nia": 79.98225032701363,
    "Buyer Kit": 80.611311269705
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Amir": 80.07,
    "Seller Leo": 79.99,
    "Seller Yara": 80.23,
    "Seller Maya": 79.1458
  },
  "buyer_bids": {
    "Buyer Tara": 79.48925438953648,
    "Buyer Zoe": 80.08121002417161,
    "Buyer Omar": 80.48731117522246,
    "Buyer Ana": 80.15976829562157,
    "Buyer Jun": 80.21659374448312,
    "Buyer Raj": 79.72981992314037
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Maya",
      "price": 79.82
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Leo",
      "price": 80.1
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.11
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Raj": 99.9,
    "Seller Amir": 97.64,
    "Seller Eli": 0.9763,
    "Seller Yara": 99.95
  },
  "buyer_bids": {
    "Buyer Mia": 80.11906393352639,
    "Buyer Ana": 80.7953097551439,
    "Buyer Nia": 79.21347491631094,
    "Buyer Lena": 79.27825620499968,
    "Buyer Omar": 80.50409517516378,
    "Buyer Kit": 79.3698510773034
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 40.89
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Yara": 80.21,
    "Seller Maya": 79.07,
    "Seller Leo": 79.98
  },
  "buyer_bids": {
    "Buyer Ana": 80.08164661880848,
    "Buyer Jun": 80.68952004021756,
    "Buyer Tara": 80.70971240607635,
    "Buyer Omar": 80.56203841944262,
    "Buyer Raj": 79.34656225202608,
    "Buyer Zoe": 79.25193460991079
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Maya",
      "price": 79.89
    },
    {
      "round_number": 17,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Leo",
      "price": 80.33
    },
    {
      "round_number": 17,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.39
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Leo": 79.97,
    "Seller Yara": 80.3,
    "Seller Jin": 9.08,
    "Seller Maya": 79.07
  },
  "buyer_bids": {
    "Buyer Ana": 80.58892494459975,
    "Buyer Tara": 79.62982677351819,
    "Buyer Jun": 80.40663245625004,
    "Buyer Raj": 79.31272555688898,
    "Buyer Omar": 79.92479805963707,
    "Buyer Zoe": 79.64991468488645
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 44.83
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Maya",
      "price": 79.74
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Raj": 100.0,
    "Seller Eli": 0.9763,
    "Seller Amir": 97.61
  },
  "buyer_bids": {
    "Buyer Lena": 79.62534592443505,
    "Buyer Omar": 80.29196426720013,
    "Buyer Mia": 79.41839983289174,
    "Buyer Kit": 80.40699165490105,
    "Buyer Ana": 80.66534553892929,
    "Buyer Nia": 80.14672050746222
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 40.82
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Leo": 0.99,
    "Seller Yara": 80.24
  },
  "buyer_bids": {
    "Buyer Raj": 80.47566034346582,
    "Buyer Omar": 79.66445491396803,
    "Buyer Jun": 79.46795249175578,
    "Buyer Tara": 80.7231322427767,
    "Buyer Ana": 79.49537629299668,
    "Buyer Zoe": 79.60834578904367
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Leo",
      "price": 40.86
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Amir": 97.63,
    "Seller Yara": 97.64000000000001
  },
  "buyer_bids": {
    "Buyer Lena": 79.29087425902316,
    "Buyer Ana": 79.29661571291587,
    "Buyer Kit": 80.63674859663202,
    "Buyer Omar": 80.70972953892448,
    "Buyer Mia": 80.41505451240388,
    "Buyer Nia": 80.51959601891612
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Yara": 80.3,
    "Seller Jin": 9.27,
    "Seller Amir": 80.07
  },
  "buyer_bids": {
    "Buyer Ana": 80.2371244872998,
    "Buyer Zoe": 79.99438984958853,
    "Buyer Jun": 80.32420088436606,
    "Buyer Raj": 80.25065040913718,
    "Buyer Tara": 79.38270503310721,
    "Buyer Omar": 79.67118844335916
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Jin",
      "price": 44.8
    },
    {
      "round_number": 20,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Amir",
      "price": 80.16
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Amir": 97.63,
    "Seller Eli": 97.63,
    "Seller Maya": 80.0,
    "Seller Yara": 97.63
  },
  "buyer_bids": {
    "Buyer Kit": 79.38435692733005,
    "Buyer Mia": 79.3079465392273,
    "Buyer Nia": 79.77634957041599,
    "Buyer Omar": 79.59920271244962,
    "Buyer Ana": 79.23750829795483,
    "Buyer Lena": 79.26539932166843
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Yara": 80.3,
    "Seller Leo": 79.98,
    "Seller Jin": 0.07,
    "Seller Amir": 80.1
  },
  "buyer_bids": {
    "Buyer Raj": 79.69920788272091,
    "Buyer Omar": 80.47392481789636,
    "Buyer Ana": 79.74934795404576,
    "Buyer Zoe": 79.6055330383756,
    "Buyer Jun": 79.61347333322479,
    "Buyer Tara": 80.36824356925626
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 40.27
    },
    {
      "round_number": 21,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Leo",
      "price": 80.17
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Amir": 97.64,
    "Seller Eli": 97.63,
    "Seller Raj": 99.99
  },
  "buyer_bids": {
    "Buyer Ana": 79.40445941464131,
    "Buyer Mia": 80.37565925340343,
    "Buyer Kit": 80.6975444693222,
    "Buyer Nia": 80.6698080542224,
    "Buyer Lena": 80.03694625725144,
    "Buyer Omar": 79.79695564813244
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Maya",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Jin": 9.28,
    "Seller Yara": 80.28,
    "Seller Amir": 80.06
  },
  "buyer_bids": {
    "Buyer Jun": 80.76088548923514,
    "Buyer Tara": 79.83570459063603,
    "Buyer Zoe": 79.56059842130976,
    "Buyer Omar": 79.89064887543964,
    "Buyer Ana": 80.74490162856159,
    "Buyer Raj": 80.76278124104847
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 45.02
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Amir",
      "price": 80.41
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.51
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Jin": 9.28,
    "Seller Yara": 80.23,
    "Seller Leo": 79.99,
    "Seller Amir": 80.06
  },
  "buyer_bids": {
    "Buyer Jun": 80.01009490106316,
    "Buyer Omar": 79.91306962614782,
    "Buyer Zoe": 79.88266404324415,
    "Buyer Tara": 80.53159184718848,
    "Buyer Ana": 80.73582930755887,
    "Buyer Raj": 79.25652167461914
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 45.01
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Leo",
      "price": 80.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Leo": 79.99,
    "Seller Yara": 80.23,
    "Seller Jin": 9.28
  },
  "buyer_bids": {
    "Buyer Ana": 80.20923493859543,
    "Buyer Omar": 80.31208142657995,
    "Buyer Raj": 80.76316184968465,
    "Buyer Tara": 79.24912044280646,
    "Buyer Zoe": 80.03823270378717,
    "Buyer Jun": 79.92135204342837
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Jin",
      "price": 45.02
    },
    {
      "round_number": 24,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Leo",
      "price": 80.15
    },
    {
      "round_number": 24,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.13
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Yara": 80.22,
    "Seller Amir": 80.07,
    "Seller Leo": 78.99,
    "Seller Jin": 9.27
  },
  "buyer_bids": {
    "Buyer Ana": 80.48541682149464,
    "Buyer Omar": 80.25571822680172,
    "Buyer Zoe": 80.37992200015313,
    "Buyer Tara": 79.40109331569556,
    "Buyer Raj": 80.27984412402922,
    "Buyer Jun": 79.88207900594217
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 44.88
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 79.68
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Amir",
      "price": 80.17
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Yara": 80.21,
    "Seller Jin": 9.0
  },
  "buyer_bids": {
    "Buyer Omar": 79.31316300461906,
    "Buyer Jun": 79.32231384885745,
    "Buyer Zoe": 80.66748210119354,
    "Buyer Tara": 79.67660768918803,
    "Buyer Ana": 79.27590427763923,
    "Buyer Raj": 79.53941070885102
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 44.83
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Yara": 80.22,
    "Seller Jin": 9.26,
    "Seller Maya": 79.06
  },
  "buyer_bids": {
    "Buyer Zoe": 80.56084265754123,
    "Buyer Tara": 80.14493435405987,
    "Buyer Omar": 79.40862580547905,
    "Buyer Raj": 79.45313182373252,
    "Buyer Ana": 80.10390515628288,
    "Buyer Jun": 80.09714771364591
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 44.91
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Maya",
      "price": 79.6
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Mia": 80.08,
    "Seller Raj": 80.02,
    "Seller Tara": 80.25,
    "Seller Kai": 79.8
  },
  "buyer_bids": {
    "Buyer Jin": 80.32853298450065,
    "Buyer Nia": 79.79529630892972,
    "Buyer Amir": 79.63366073509616,
    "Buyer Jun": 79.47277083793325,
    "Buyer Leo": 79.29950792909393,
    "Buyer Max": 79.88180981655017
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Kai",
      "price": 80.06
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Yara": 80.22,
    "Seller Jin": 9.28
  },
  "buyer_bids": {
    "Buyer Jun": 80.52466105065085,
    "Buyer Ana": 80.64130079233982,
    "Buyer Tara": 80.44802763109234,
    "Buyer Zoe": 80.59181828467578,
    "Buyer Omar": 79.93736398424527,
    "Buyer Raj": 79.54814454272034
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 44.96
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Yara",
      "price": 80.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Yara": 80.22,
    "Seller Leo": 79.96,
    "Seller Jin": 9.28,
    "Seller Amir": 80.1,
    "Seller Maya": 80.02
  },
  "buyer_bids": {
    "Buyer Tara": 80.6345051936263,
    "Buyer Raj": 80.19674050222484,
    "Buyer Jun": 79.35844058043672,
    "Buyer Ana": 79.25987740013562,
    "Buyer Omar": 79.52065192874588,
    "Buyer Zoe": 80.1174123248357
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Jin",
      "price": 44.96
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Leo",
      "price": 80.08
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Maya",
      "price": 80.07
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Amir": 97.63,
    "Seller Eli": 97.52,
    "Seller Maya": 80.0,
    "Seller Raj": 0.9999
  },
  "buyer_bids": {
    "Buyer Ana": 80.47065267550947,
    "Buyer Omar": 80.14313318780852,
    "Buyer Kit": 79.59652320327068,
    "Buyer Nia": 79.20309800369222,
    "Buyer Lena": 79.20671377592326,
    "Buyer Mia": 80.75330760522209
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Raj",
      "price": 40.88
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Maya",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Amir": 97.63,
    "Seller Raj": 100.0,
    "Seller Eli": 97.53,
    "Seller Yara": 97.63
  },
  "buyer_bids": {
    "Buyer Mia": 79.69341698227707,
    "Buyer Omar": 80.39628543988604,
    "Buyer Lena": 80.08240532596075,
    "Buyer Kit": 79.98201763666643,
    "Buyer Nia": 80.20441003730845,
    "Buyer Ana": 79.65764261886136
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Eli": 9.745,
    "Seller Raj": 100.0,
    "Seller Yara": 97.64
  },
  "buyer_bids": {
    "Buyer Mia": 80.19455220348055,
    "Buyer Omar": 79.27323593976521,
    "Buyer Lena": 79.44552889433837,
    "Buyer Ana": 79.62230748838975,
    "Buyer Kit": 79.84296637609536,
    "Buyer Nia": 80.16824948477682
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 44.97
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Eli": 80.04,
    "Seller Mia": 80.07,
    "Seller Kai": 79.84,
    "Seller Raj": 80.06
  },
  "buyer_bids": {
    "Buyer Max": 80.69843154590366,
    "Buyer Jin": 79.55003769451659,
    "Buyer Amir": 80.56851619121636,
    "Buyer Nia": 80.5073924848302,
    "Buyer Jun": 80.21473026168366,
    "Buyer Leo": 80.16347277975784
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Kai",
      "price": 80.27
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Eli",
      "price": 80.3
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.28
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.14
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Eli": 80.03,
    "Seller Raj": 80.099,
    "Seller Kai": 7.9
  },
  "buyer_bids": {
    "Buyer Jin": 80.52813780994359,
    "Buyer Jun": 79.34645096504855,
    "Buyer Leo": 79.38567382140627,
    "Buyer Amir": 79.50163299568102,
    "Buyer Max": 80.53415108895918,
    "Buyer Nia": 79.39151275624286
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Kai",
      "price": 44.22
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Eli",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Yara": 80.23,
    "Seller Leo": 79.99,
    "Seller Maya": 79.14584549600208,
    "Seller Jin": 9.28
  },
  "buyer_bids": {
    "Buyer Raj": 80.1462548994317,
    "Buyer Zoe": 80.00657178759337,
    "Buyer Omar": 80.70072624285172,
    "Buyer Tara": 79.22752031475717,
    "Buyer Ana": 79.98776120071918,
    "Buyer Jun": 79.8240968620309
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Jin",
      "price": 44.99
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Maya",
      "price": 79.65
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 80.0
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Amir": 9.9763,
    "Seller Raj": 10.0,
    "Seller Yara": 97.64
  },
  "buyer_bids": {
    "Buyer Mia": 79.23872612056519,
    "Buyer Nia": 80.73405447275076,
    "Buyer Lena": 80.46145493834928,
    "Buyer Ana": 80.29983272929556,
    "Buyer Omar": 79.34952584100758,
    "Buyer Kit": 80.54144228818474
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Amir",
      "price": 45.36
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Raj",
      "price": 45.27
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Amir": 97.62,
    "Seller Raj": 99.99
  },
  "buyer_bids": {
    "Buyer Nia": 80.0292577694053,
    "Buyer Mia": 80.59910923194565,
    "Buyer Omar": 80.4496954011077,
    "Buyer Lena": 79.74568165849563,
    "Buyer Kit": 79.7247373002032,
    "Buyer Ana": 79.97907477038864
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Eli": 97.62,
    "Seller Amir": 97.63
  },
  "buyer_bids": {
    "Buyer Omar": 80.75309378409095,
    "Buyer Ana": 80.24530340454618,
    "Buyer Kit": 80.3191580958122,
    "Buyer Mia": 80.73439992833815,
    "Buyer Nia": 79.6189398360977,
    "Buyer Lena": 80.27289806672073
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Tara": 80.25
  },
  "buyer_bids": {
    "Buyer Nia": 80.75310706120696,
    "Buyer Jin": 79.51134552909173,
    "Buyer Jun": 80.34898132233495,
    "Buyer Max": 79.96677384627553,
    "Buyer Amir": 80.16880667235418,
    "Buyer Leo": 80.36344836712773
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.43
    },
    {
      "round_number": 17,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.31
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Eli": 97.5
  },
  "buyer_bids": {
    "Buyer Mia": 79.57064811597179,
    "Buyer Omar": 79.41072306825119,
    "Buyer Lena": 80.66623674611408,
    "Buyer Kit": 79.92542386812062,
    "Buyer Nia": 79.60474706928201,
    "Buyer Ana": 79.47313722486344
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Maya": 80.0,
    "Seller Raj": 99.99,
    "Seller Eli": 97.61,
    "Seller Yara": 97.65
  },
  "buyer_bids": {
    "Buyer Kit": 80.3421879582965,
    "Buyer Omar": 79.25024213784367,
    "Buyer Ana": 79.59481687822907,
    "Buyer Lena": 79.32868674506233,
    "Buyer Mia": 79.3176762610767,
    "Buyer Nia": 80.33294960181868
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Maya",
      "price": 80.17
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Amir": 97.62,
    "Seller Raj": 99.99
  },
  "buyer_bids": {
    "Buyer Nia": 79.5651251509686,
    "Buyer Ana": 80.19825517784952,
    "Buyer Mia": 80.29529699591419,
    "Buyer Omar": 80.46653373003254,
    "Buyer Lena": 79.64597941072213,
    "Buyer Kit": 79.77572642870675
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Mia": 80.083,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Amir": 80.28695551184157,
    "Buyer Leo": 79.31515470322282,
    "Buyer Jun": 80.53744424891377,
    "Buyer Jin": 80.07077665836357,
    "Buyer Nia": 80.19295995356441,
    "Buyer Max": 79.31200688148533
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.31
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Tara",
      "price": 80.22
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Raj": 99.9,
    "Seller Amir": 97.63,
    "Seller Eli": 8.0
  },
  "buyer_bids": {
    "Buyer Nia": 80.40108447080641,
    "Buyer Ana": 79.81560442934902,
    "Buyer Mia": 80.01933095125878,
    "Buyer Lena": 79.34051416207392,
    "Buyer Kit": 79.45637719763725,
    "Buyer Omar": 79.44178471607566
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 44.2
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Amir": 97.63,
    "Seller Yara": 97.65
  },
  "buyer_bids": {
    "Buyer Mia": 79.23910416985436,
    "Buyer Ana": 80.40093630828292,
    "Buyer Nia": 79.363057984111,
    "Buyer Lena": 80.27118349628928,
    "Buyer Omar": 79.23168286301804,
    "Buyer Kit": 79.36835888883297
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Tara": 80.105,
    "Seller Mia": 80.09,
    "Seller Eli": 80.03,
    "Seller Raj": 79.99,
    "Seller Kai": 79.87
  },
  "buyer_bids": {
    "Buyer Jun": 79.94740996407722,
    "Buyer Jin": 79.89770983672521,
    "Buyer Max": 80.15437587619927,
    "Buyer Leo": 80.31891700015349,
    "Buyer Nia": 79.2976679027514,
    "Buyer Amir": 79.68169845760218
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.09
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.07
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Maya": 80.0,
    "Seller Eli": 8.0,
    "Seller Amir": 97.63
  },
  "buyer_bids": {
    "Buyer Omar": 80.05685334970664,
    "Buyer Kit": 80.29549858458714,
    "Buyer Mia": 80.41683983758827,
    "Buyer Lena": 79.53622482691921,
    "Buyer Nia": 79.92617235552939,
    "Buyer Ana": 79.80800433412134
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 44.21
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Maya",
      "price": 80.15
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Eli": 80.03,
    "Seller Raj": 79.98
  },
  "buyer_bids": {
    "Buyer Leo": 80.3163153132515,
    "Buyer Jun": 80.64368677042106,
    "Buyer Amir": 79.61621320675081,
    "Buyer Nia": 79.95234585807712,
    "Buyer Max": 80.11162966691762,
    "Buyer Jin": 80.64703781284807
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.31
    },
    {
      "round_number": 20,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Eli",
      "price": 80.34
    },
    {
      "round_number": 20,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Mia": 80.09,
    "Seller Eli": 80.06
  },
  "buyer_bids": {
    "Buyer Jun": 79.45313380772382,
    "Buyer Max": 79.45912651231662,
    "Buyer Nia": 80.46183726401568,
    "Buyer Leo": 80.04715875686034,
    "Buyer Amir": 79.52546349723994,
    "Buyer Jin": 80.42775734732211
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 80.26
    },
    {
      "round_number": 21,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Tara": 80.11,
    "Seller Eli": 80.05
  },
  "buyer_bids": {
    "Buyer Jun": 79.22112601365596,
    "Buyer Jin": 80.67426943114178,
    "Buyer Nia": 80.2649693152287,
    "Buyer Amir": 79.38754055019368,
    "Buyer Max": 80.29004908096678,
    "Buyer Leo": 80.64015688382523
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Eli",
      "price": 80.36
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Kai": 79.64,
    "Seller Eli": 80.08,
    "Seller Raj": 79.99,
    "Seller Tara": 80.25
  },
  "buyer_bids": {
    "Buyer Leo": 79.44546043349028,
    "Buyer Max": 80.25218591989199,
    "Buyer Nia": 80.23829358049811,
    "Buyer Jun": 79.82182758853031,
    "Buyer Jin": 80.66801779641445,
    "Buyer Amir": 80.59968751083136
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Kai",
      "price": 80.15
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 80.29
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Eli",
      "price": 80.17
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Raj": 79.99,
    "Seller Eli": 80.08,
    "Seller Kai": 79.76,
    "Seller Mia": 80.07
  },
  "buyer_bids": {
    "Buyer Amir": 80.30531641259714,
    "Buyer Nia": 79.32651806278129,
    "Buyer Jin": 79.9327267258355,
    "Buyer Jun": 80.38242578560943,
    "Buyer Leo": 79.4157401709572,
    "Buyer Max": 80.07091119624236
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.07
    },
    {
      "round_number": 24,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 80.15
    },
    {
      "round_number": 24,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.07
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Mia": 80.06,
    "Seller Kai": 79.71,
    "Seller Raj": 79.99,
    "Seller Eli": 8.08
  },
  "buyer_bids": {
    "Buyer Jin": 80.17621704683158,
    "Buyer Amir": 79.97092333259852,
    "Buyer Max": 80.62710966627296,
    "Buyer Leo": 80.56603900934549,
    "Buyer Nia": 80.27744553517343,
    "Buyer Jun": 80.14444429811127
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Eli",
      "price": 44.35
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.14
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.13
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.12
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Tara": 8.25,
    "Seller Eli": 80.09,
    "Seller Mia": 80.09,
    "Seller Raj": 79.99
  },
  "buyer_bids": {
    "Buyer Nia": 80.52624443353216,
    "Buyer Leo": 80.31773230236055,
    "Buyer Amir": 79.69647613034269,
    "Buyer Jun": 79.32915697099595,
    "Buyer Jin": 80.39757740991615,
    "Buyer Max": 80.15132308235538
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Tara",
      "price": 44.39
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.19
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.2
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.12
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Eli": 80.08,
    "Seller Mia": 80.09,
    "Seller Tara": 80.25
  },
  "buyer_bids": {
    "Buyer Max": 80.2780403204936,
    "Buyer Leo": 80.59926023977286,
    "Buyer Nia": 79.91701652262984,
    "Buyer Jun": 80.33655996174124,
    "Buyer Amir": 79.45612764643927,
    "Buyer Jin": 79.55695651337385
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.34
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.21
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Tara",
      "price": 80.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Mia": 80.08,
    "Seller Tara": 80.25,
    "Seller Raj": 80.05,
    "Seller Eli": 80.09
  },
  "buyer_bids": {
    "Buyer Leo": 79.30221809457811,
    "Buyer Jun": 80.33440965469813,
    "Buyer Nia": 80.4354971487784,
    "Buyer Jin": 80.10795574686797,
    "Buyer Max": 79.46507995659533,
    "Buyer Amir": 80.5947011077622
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 80.32
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.26
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Eli",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Mia": 8.08,
    "Seller Kai": 79.6,
    "Seller Tara": 80.25,
    "Seller Raj": 80.05999999999999,
    "Seller Eli": 80.07
  },
  "buyer_bids": {
    "Buyer Jin": 79.91418353948085,
    "Buyer Amir": 80.32242586800679,
    "Buyer Max": 80.16636382049899,
    "Buyer Leo": 79.20011066059917,
    "Buyer Jun": 80.65286377145534,
    "Buyer Nia": 80.61591281279641
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 44.37
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.11
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 80.19
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Eli",
      "price": 80.12
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Mia": 80.06,
    "Seller Kai": 79.6,
    "Seller Tara": 80.25,
    "Seller Raj": 79.99999999999999
  },
  "buyer_bids": {
    "Buyer Jun": 79.27977119456584,
    "Buyer Leo": 80.75868301167984,
    "Buyer Amir": 79.26225629442433,
    "Buyer Max": 80.51635187715311,
    "Buyer Jin": 79.72151024713585,
    "Buyer Nia": 80.54037894567124
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.18
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.27
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.29
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Raj": 100.0,
    "Seller Amir": 97.63,
    "Seller Maya": 80.0,
    "Seller Eli": 80.0
  },
  "buyer_bids": {
    "Buyer Lena": 80.13014561153918,
    "Buyer Omar": 79.23411620355935,
    "Buyer Ana": 80.14614861072582,
    "Buyer Mia": 80.68620906502085,
    "Buyer Kit": 80.61029927036782,
    "Buyer Nia": 79.88095832480789
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 80.34
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Maya",
      "price": 80.31
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Amir": 97.64,
    "Seller Eli": 80.0,
    "Seller Raj": 99.91,
    "Seller Maya": 80.0,
    "Seller Yara": 97.65
  },
  "buyer_bids": {
    "Buyer Kit": 79.78637252199151,
    "Buyer Omar": 80.73707191850485,
    "Buyer Ana": 79.38974556458605,
    "Buyer Lena": 80.69191574301989,
    "Buyer Nia": 79.23117261551869,
    "Buyer Mia": 80.30463151912117
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Eli",
      "price": 80.37
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Maya",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Yara": 97.65,
    "Seller Raj": 0.99
  },
  "buyer_bids": {
    "Buyer Lena": 80.52063031215337,
    "Buyer Omar": 79.85960687519506,
    "Buyer Nia": 80.59895521027221,
    "Buyer Mia": 80.44054030981746,
    "Buyer Ana": 79.36802642710117,
    "Buyer Kit": 79.51742616701856
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 40.79
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
