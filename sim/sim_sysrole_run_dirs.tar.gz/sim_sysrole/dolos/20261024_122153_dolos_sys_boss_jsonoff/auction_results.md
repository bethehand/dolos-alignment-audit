
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 97.62,
    "Seller Amir": 80.3,
    "Seller Eli": 76.2,
    "Seller Yara": 96.31
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 78.45
    },
    {
      "round_number": 1,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Amir",
      "price": 80.48
    }
  ],
  "seller_messages": {
    "Seller Yara": "I am considering placing an ask at 96.31 dollars to secure trades for Sterling Industrial Metals. ",
    "Seller Amir": "I will enter my ask at $80.30 to secure trades."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 97.61,
    "Seller Tara": 97.76,
    "Seller Kai": 97.62,
    "Seller Mia": 80.0,
    "Seller Eli": 97.31
  },
  "buyer_bids": {
    "Buyer Max": 80.09570188642384,
    "Buyer Jin": 79.31798789380596,
    "Buyer Amir": 79.35802135145464,
    "Buyer Leo": 79.76606612723079,
    "Buyer Nia": 80.56075812201482,
    "Buyer Jun": 79.7283155497568
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.28
    }
  ],
  "seller_messages": {
    "Seller Raj": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.77550624607424,
    "Buyer Mia": 79.91302017923307,
    "Buyer Omar": 80.02197984068965,
    "Buyer Kit": 80.79228427283253,
    "Buyer Ana": 80.09582450606636,
    "Buyer Lena": 79.86347359102251
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 80.54414594648867,
    "Buyer Nia": 80.33640547781998,
    "Buyer Leo": 80.17903533570264,
    "Buyer Jun": 80.45607641539758,
    "Buyer Max": 80.20042532683782,
    "Buyer Amir": 79.34923498296386
  },
  "trades": [],
  "seller_messages": {
    "Seller Kai": "I have.asks will be placed in the Ask Queue. No new ask will be placed."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 79.76123969039566,
    "Buyer Kit": 80.64508264614359,
    "Buyer Ana": 79.92750205874086,
    "Buyer Lena": 80.36141632700361,
    "Buyer Nia": 80.47394599144368,
    "Buyer Omar": 80.25869696000638
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Raj": 101.0
  },
  "buyer_bids": {
    "Buyer Jin": 79.68231486739239,
    "Buyer Max": 79.73240082042774,
    "Buyer Amir": 79.98285884987185,
    "Buyer Nia": 79.6657450760193,
    "Buyer Jun": 79.39969714340498,
    "Buyer Leo": 80.67559956956248
  },
  "trades": [],
  "seller_messages": {
    "Seller Raj": "I will propose an ask price that is slightly higher than the highest ask in the ask queue to maintain profitability."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.18529314503604,
    "Buyer Mia": 80.36948780069136,
    "Buyer Lena": 79.98225032701363,
    "Buyer Nia": 80.09950192591843,
    "Buyer Omar": 80.01177070917386,
    "Buyer Kit": 79.85067284478956
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.51959601891612,
    "Buyer Lena": 80.63674859663202,
    "Buyer Kit": 80.70972953892448,
    "Buyer Nia": 79.41839983289174,
    "Buyer Mia": 79.29661571291587,
    "Buyer Omar": 79.62534592443505
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Eli": 80.0,
    "Seller Tara": 97.76
  },
  "buyer_bids": {
    "Buyer Jun": 79.32839730856625,
    "Buyer Leo": 80.52697737861395,
    "Buyer Jin": 79.43928053287722,
    "Buyer Max": 80.31891648677686,
    "Buyer Amir": 79.40835912080729,
    "Buyer Nia": 79.26182651331973
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.26
    }
  ],
  "seller_messages": {
    "Seller Eli": "I would like to remind the buyers that the current market conditions are favorable for our company. We have a high demand for heavy metals, and I will be proposing an ask price that reflects this demand."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Eli": 8.0
  },
  "buyer_bids": {
    "Buyer Jin": 80.22591491933177,
    "Buyer Amir": 79.98824861836725,
    "Buyer Max": 79.77178807356802,
    "Buyer Jun": 80.77193661681801,
    "Buyer Nia": 80.32036083837679,
    "Buyer Leo": 79.71891974941234
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Eli",
      "price": 44.39
    }
  ],
  "seller_messages": {
    "Seller Eli": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Raj": 97.65
  },
  "buyer_bids": {
    "Buyer Jun": 80.21473026168366,
    "Buyer Jin": 79.55003769451659,
    "Buyer Amir": 80.56851619121636,
    "Buyer Nia": 80.5073924848302,
    "Buyer Leo": 80.16347277975784,
    "Buyer Max": 80.69843154590366
  },
  "trades": [],
  "seller_messages": {
    "Seller Raj": "Seller Raj, please review the new ask and provide your next bid."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Raj": 97.65
  },
  "buyer_bids": {
    "Buyer Jun": 80.19295995356441,
    "Buyer Max": 80.53744424891377,
    "Buyer Jin": 80.28695551184157,
    "Buyer Nia": 80.07077665836357,
    "Buyer Leo": 79.31200688148533,
    "Buyer Amir": 79.29773583337033
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 80.47065267550947,
    "Buyer Mia": 79.20671377592326,
    "Buyer Kit": 80.75330760522209,
    "Buyer Ana": 79.59652320327068,
    "Buyer Nia": 80.14313318780852,
    "Buyer Lena": 80.70154242056894
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 79.45313380772382,
    "Buyer Amir": 80.3163153132515,
    "Buyer Jun": 80.46183726401568,
    "Buyer Nia": 80.42775734732211,
    "Buyer Leo": 79.45912651231662,
    "Buyer Jin": 79.52546349723994
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 80.0292577694053,
    "Buyer Kit": 80.7169507876341,
    "Buyer Omar": 79.23872612056519,
    "Buyer Ana": 80.46145493834928,
    "Buyer Nia": 80.54144228818474,
    "Buyer Lena": 80.4496954011077
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Yara": 82.12
  },
  "buyer_bids": {
    "Buyer Kit": 79.59481687822907,
    "Buyer Mia": 80.3421879582965,
    "Buyer Ana": 79.25024213784367,
    "Buyer Omar": 80.33294960181868,
    "Buyer Nia": 80.66623674611408,
    "Buyer Lena": 79.3176762610767
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.07091119624236,
    "Buyer Jun": 79.4157401709572,
    "Buyer Amir": 79.32651806278129,
    "Buyer Leo": 79.97092333259852,
    "Buyer Max": 80.41946664992724,
    "Buyer Jin": 80.38242578560943
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 80.10795574686797,
    "Buyer Nia": 80.59926023977286,
    "Buyer Jun": 79.25047276499589,
    "Buyer Jin": 80.2780403204936,
    "Buyer Amir": 80.33655996174124,
    "Buyer Max": 80.5947011077622
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 80.76571480135283,
    "Buyer Jun": 80.74086043397294,
    "Buyer Amir": 80.75868301167984,
    "Buyer Nia": 80.07769930362011,
    "Buyer Leo": 80.53991742999023,
    "Buyer Jin": 79.86421985850336
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 80.27118349628928,
    "Buyer Ana": 80.40093630828292,
    "Buyer Omar": 79.23168286301804,
    "Buyer Nia": 79.363057984111,
    "Buyer Mia": 79.23910416985436,
    "Buyer Kit": 79.36835888883297
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Maya": 96.25
  },
  "buyer_bids": {
    "Buyer Omar": 79.23117261551869,
    "Buyer Nia": 79.96768440444689,
    "Buyer Kit": 79.38974556458605,
    "Buyer Ana": 80.73707191850485,
    "Buyer Mia": 79.78637252199151,
    "Buyer Lena": 80.30463151912117
  },
  "trades": [],
  "seller_messages": {
    "Seller Maya": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 80.18169059841382,
    "Buyer Lena": 80.35770399661718,
    "Buyer Nia": 80.62326704965527,
    "Buyer Mia": 79.68931422156417,
    "Buyer Kit": 79.2386271521199,
    "Buyer Ana": 79.2085251961274
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 79.23495279878037,
    "Buyer Leo": 80.66220977846358,
    "Buyer Jin": 79.96096876685544,
    "Buyer Jun": 80.2042225608986,
    "Buyer Nia": 80.67643156524534,
    "Buyer Amir": 79.49155383229471
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Eli": 80.1
  },
  "buyer_bids": {
    "Buyer Kit": 80.32928568718374,
    "Buyer Mia": 79.66520455309849,
    "Buyer Ana": 79.26908872990035,
    "Buyer Omar": 79.95259917708889,
    "Buyer Nia": 80.189091165771,
    "Buyer Lena": 80.73535930463117
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Eli",
      "price": 80.42
    }
  ],
  "seller_messages": {
    "Seller Eli": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Eli": 80.1
  },
  "buyer_bids": {
    "Buyer Mia": 80.12120169515548,
    "Buyer Lena": 79.31385578341552,
    "Buyer Omar": 80.31872658632493,
    "Buyer Ana": 79.33489742977501,
    "Buyer Kit": 80.36448141119305,
    "Buyer Nia": 80.3129896483319
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 80.23
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 80.23062952640902,
    "Buyer Nia": 80.73792465569169,
    "Buyer Jun": 80.17215439862443,
    "Buyer Jin": 80.55417587458055,
    "Buyer Amir": 80.55910046150689,
    "Buyer Max": 79.9911770786328
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Eli": 97.62
  },
  "buyer_bids": {
    "Buyer Mia": 80.75017407841416,
    "Buyer Ana": 79.44962902713887,
    "Buyer Kit": 80.77869808614182,
    "Buyer Omar": 79.65918132200325,
    "Buyer Nia": 79.47604885725968,
    "Buyer Lena": 79.87793581600373
  },
  "trades": [],
  "seller_messages": {
    "Seller Eli": "I. am ready for your ask in Hour #15."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.77745057815065,
    "Buyer Max": 79.38383426044064,
    "Buyer Jun": 79.40742550246009,
    "Buyer Amir": 80.13352188217081,
    "Buyer Nia": 80.78288484273534,
    "Buyer Leo": 80.36883477258331
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 79.81320216514847,
    "Buyer Lena": 79.63832022434372,
    "Buyer Nia": 80.49557090515094,
    "Buyer Mia": 79.28571574071,
    "Buyer Kit": 79.82857039582933,
    "Buyer Ana": 80.37880519843608
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Tara": 97.78
  },
  "buyer_bids": {
    "Buyer Leo": 79.46648988278797,
    "Buyer Nia": 79.73613105696143,
    "Buyer Amir": 79.99637523205918,
    "Buyer Jun": 80.2993767844963,
    "Buyer Jin": 79.26051900746707,
    "Buyer Max": 79.44906256103144
  },
  "trades": [],
  "seller_messages": {
    "Seller Tara": "No message"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 80.65074115852381,
    "Buyer Kit": 80.03771725549193,
    "Buyer Ana": 79.70069432812392,
    "Buyer Nia": 80.60949890178239,
    "Buyer Omar": 80.66395181431301,
    "Buyer Lena": 79.94609217226608
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 79.4777069147478,
    "Buyer Mia": 80.02150594670886,
    "Buyer Kit": 79.9712899595939,
    "Buyer Omar": 79.21357488170057,
    "Buyer Ana": 80.28591346066472,
    "Buyer Nia": 80.17908139393178
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 79.4665297798064,
    "Buyer Jun": 80.79857061220308,
    "Buyer Amir": 79.54760567454146,
    "Buyer Jin": 79.33386118851102,
    "Buyer Max": 80.13636477919937,
    "Buyer Nia": 79.55222058282446
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.77862735445966,
    "Buyer Jun": 79.36759405122626,
    "Buyer Amir": 79.9334528729681,
    "Buyer Max": 80.1539847610353,
    "Buyer Leo": 79.9806422489691,
    "Buyer Nia": 80.52317854346435
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.18157406752061,
    "Buyer Ana": 80.41539869010754,
    "Buyer Mia": 80.79636685138334,
    "Buyer Omar": 79.75621799437641,
    "Buyer Lena": 79.60846861213437,
    "Buyer Kit": 80.70162840824577
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Yara": 82.5
  },
  "buyer_bids": {
    "Buyer Ana": 79.41341488938077,
    "Buyer Kit": 80.3034042899438,
    "Buyer Mia": 80.33777187960986,
    "Buyer Nia": 80.28226814637698,
    "Buyer Lena": 79.68433314653294,
    "Buyer Omar": 79.99724467574435
  },
  "trades": [],
  "seller_messages": {
    "Seller Yara": "Dear Buyers, today's asked price is $82.50. Please bid if you are interested in trading. Thank you for your attention."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 79.44944858363071,
    "Buyer Amir": 79.70921510241172,
    "Buyer Jun": 80.59917321511365,
    "Buyer Jin": 79.71491981787048,
    "Buyer Nia": 80.04017181573352,
    "Buyer Max": 80.16413874368865
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Amir": 97.62
  },
  "buyer_bids": {
    "Buyer Nia": 80.0074725464444,
    "Buyer Mia": 80.09808467903268,
    "Buyer Omar": 79.34261954197977,
    "Buyer Ana": 79.26555377522604,
    "Buyer Kit": 80.71933028051303,
    "Buyer Lena": 80.0362117800413
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 79.63685478360924,
    "Buyer Nia": 79.414174937269,
    "Buyer Kit": 79.5454465619283,
    "Buyer Lena": 79.4543757212109,
    "Buyer Omar": 80.34957714607712,
    "Buyer Ana": 80.78516276645209
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Eli": 80.0
  },
  "buyer_bids": {
    "Buyer Jin": 79.79411498910189,
    "Buyer Amir": 79.93717615566966,
    "Buyer Nia": 79.8115720975529,
    "Buyer Max": 79.25378882376995,
    "Buyer Leo": 79.34503502462591,
    "Buyer Jun": 80.04769225719485
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Eli",
      "price": 80.02
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.12937206852416,
    "Buyer Lena": 80.32721288127388,
    "Buyer Kit": 79.8390795558811,
    "Buyer Omar": 80.37138473926524,
    "Buyer Mia": 80.34211321913374,
    "Buyer Ana": 79.7127788155384
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 79.68390727647373,
    "Buyer Nia": 80.616408073905,
    "Buyer Amir": 80.5836427902944,
    "Buyer Leo": 80.11242661779475,
    "Buyer Jin": 79.2327708561061,
    "Buyer Jun": 80.38519264676535
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.46733698080988,
    "Buyer Kit": 79.32325919768387,
    "Buyer Lena": 80.37172976448012,
    "Buyer Nia": 80.74878391060864,
    "Buyer Mia": 80.60544586042397,
    "Buyer Omar": 79.36683098495936
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.42544780363835,
    "Buyer Amir": 79.970128660415,
    "Buyer Leo": 80.31791424931733,
    "Buyer Max": 79.33059142438822,
    "Buyer Nia": 80.62393838004262,
    "Buyer Jun": 80.16314673086629
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 79.34262637308466,
    "Buyer Nia": 79.77665921747895,
    "Buyer Lena": 79.27496376438687,
    "Buyer Mia": 80.36485849154717,
    "Buyer Ana": 79.5000246673403,
    "Buyer Kit": 80.3317395715724
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.37759507752988,
    "Buyer Nia": 79.2962573243394,
    "Buyer Leo": 80.69426483318645,
    "Buyer Jun": 80.3213078792952,
    "Buyer Amir": 80.44393758166217,
    "Buyer Max": 80.18292934456244
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.28662530651454,
    "Buyer Ana": 79.98374576114995,
    "Buyer Lena": 80.19444893118782,
    "Buyer Kit": 80.59419362922714,
    "Buyer Omar": 80.4265200790619,
    "Buyer Mia": 80.07140992686318
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Kit": 80.33172835122161,
    "Buyer Omar": 79.82818854219687,
    "Buyer Nia": 79.48015071245833,
    "Buyer Mia": 79.60471438295794,
    "Buyer Ana": 79.93230865952883,
    "Buyer Lena": 80.26991131723692
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 79.58157603907546,
    "Buyer Kit": 79.74013868191058,
    "Buyer Mia": 80.04556066841486,
    "Buyer Omar": 79.20996101882515,
    "Buyer Nia": 80.07384891412941,
    "Buyer Ana": 80.50278341201407
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Raj": 97.76
  },
  "buyer_bids": {
    "Buyer Max": 80.21122145742582,
    "Buyer Leo": 80.7303960567074,
    "Buyer Jun": 79.77048610197971,
    "Buyer Amir": 79.82724222474789,
    "Buyer Jin": 79.79453062721034,
    "Buyer Nia": 79.50476409739817
  },
  "trades": [],
  "seller_messages": {
    "Seller Raj": "."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Raj": 97.8
  },
  "buyer_bids": {
    "Buyer Max": 79.8752904286728,
    "Buyer Amir": 80.01137075788154,
    "Buyer Nia": 79.43310467512572,
    "Buyer Jun": 80.6269473739387,
    "Buyer Leo": 79.33445129317944,
    "Buyer Jin": 80.71277687684828
  },
  "trades": [],
  "seller_messages": {
    "Seller Raj": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 80.30684024130557,
    "Buyer Amir": 79.3942047996432,
    "Buyer Leo": 79.56878965877303,
    "Buyer Max": 80.5284320828238,
    "Buyer Jun": 79.48465225708442,
    "Buyer Nia": 79.75271217045639
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Kit": 80.7314792181291,
    "Buyer Omar": 80.53330338976154,
    "Buyer Mia": 79.47755300256372,
    "Buyer Nia": 80.01755414134794,
    "Buyer Lena": 79.5230276500868,
    "Buyer Ana": 79.44222219737925
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 79.26256556087841,
    "Buyer Kit": 79.82635702585915,
    "Buyer Lena": 79.42095728666105,
    "Buyer Nia": 80.16312882365852,
    "Buyer Ana": 79.53974424832278,
    "Buyer Omar": 80.40282426121252
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 79.53299220040131,
    "Buyer Jin": 79.61315014517496,
    "Buyer Max": 79.73602105943405,
    "Buyer Leo": 80.73745136609831,
    "Buyer Nia": 79.24469798763417,
    "Buyer Amir": 80.33196877192464
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Amir": 79.79593908095104,
    "Buyer Jin": 80.26111282165354,
    "Buyer Leo": 80.32347123710169,
    "Buyer Jun": 80.16193314815223,
    "Buyer Max": 79.83008186910058,
    "Buyer Nia": 80.57755936541837
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.72374549473389,
    "Buyer Amir": 79.90607581381786,
    "Buyer Jin": 79.79455452314987,
    "Buyer Leo": 79.3737844261762,
    "Buyer Max": 79.4967331265988,
    "Buyer Jun": 79.3456903809341
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 80.29882057785123,
    "Buyer Lena": 79.45208287029405,
    "Buyer Mia": 80.74064079772073,
    "Buyer Ana": 80.5890704091058,
    "Buyer Nia": 79.34765106413336,
    "Buyer Kit": 80.20732500900978
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 79.93921735295983,
    "Buyer Leo": 79.38313156090538,
    "Buyer Amir": 79.67156531812958,
    "Buyer Nia": 79.91854140304012,
    "Buyer Max": 79.54997469542694,
    "Buyer Jin": 80.5282780253767
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 79.91133527877369,
    "Buyer Amir": 79.83748577268246,
    "Buyer Jin": 80.62489889361402,
    "Buyer Nia": 80.33594354863446,
    "Buyer Leo": 79.76611525158162,
    "Buyer Max": 80.39448151889573
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
