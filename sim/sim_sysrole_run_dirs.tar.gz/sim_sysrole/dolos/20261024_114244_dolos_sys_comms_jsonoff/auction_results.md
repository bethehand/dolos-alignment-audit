
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 97.34,
    "Seller Amir": 80.65,
    "Seller Eli": 75.0,
    "Seller Yara": 75.0
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 77.85
    },
    {
      "round_number": 1,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Yara",
      "price": 77.83
    }
  ],
  "seller_messages": {
    "Seller Yara": "Hello, Sterling Industrial Metals. I'm looking to secure trades in the first hour. I suggest placing a slightly lower ask price to increase liquidity and the chances of securing orders.",
    "Seller Maya": "I will send my ask price of $80.00 in the ask queue.",
    "Seller Eli": "Hello, I have placed an ask at 75.00 for 1 lot of heavy metals. I am looking to secure trades during the first hour.",
    "Seller Amir": "No message at this time."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 80.0,
    "Seller Yara": 81.0,
    "Seller Leo": 79.2
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 79.72
    },
    {
      "round_number": 1,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Maya",
      "price": 80.07
    }
  ],
  "seller_messages": {
    "Seller Amir": "Propose a higher ask price than the current asks.",
    "Seller Jin": "Propose a higher ask price than the current asks."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 98.1,
    "Seller Kai": 98.04,
    "Seller Mia": 98.0,
    "Seller Eli": 79.75
  },
  "buyer_bids": {
    "Buyer Max": 80.09570188642384,
    "Buyer Jin": 79.31798789380596,
    "Buyer Amir": 79.35802135145464,
    "Buyer Leo": 79.76606612723079,
    "Buyer Nia": 80.56075812201482,
    "Buyer Jun": 79.7283155497568
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 80.16
    }
  ],
  "seller_messages": {
    "Seller Tara": "null",
    "Seller Eli": "Buyers, there's a higher interest in heavy metals at the current price, and I'm prepared to increase my offer to maintain a competitive position.",
    "Seller Mia": "I will place a slightly higher ask of $98.00 to attract more buyers.",
    "Seller Kai": "SELLER KAI: I am setting my ask at $98.04 to secure a good price for our company. Please let me know if you are interested in making a trade.",
    "Seller Raj": "In the next hour, I will propose an ask price of $98.1 to secure more trades and maintain a high profit margin."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Yara": 75.0
  },
  "buyer_bids": {
    "Buyer Kit": 79.56896427898238,
    "Buyer Mia": 79.48275196939878,
    "Buyer Omar": 79.46318147850646,
    "Buyer Lena": 79.47774200602409,
    "Buyer Ana": 79.48389829678683,
    "Buyer Nia": 80.61450330645742
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Yara",
      "price": 77.81
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 80.034165814644,
    "Buyer Amir": 80.22467744246734,
    "Buyer Jun": 79.90830937463414,
    "Buyer Leo": 79.29964734083447,
    "Buyer Nia": 80.08403788181555,
    "Buyer Jin": 79.5271643992258
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Yara": 75.0
  },
  "buyer_bids": {
    "Buyer Ana": 79.9132303376339,
    "Buyer Mia": 79.83978159088076,
    "Buyer Kit": 80.72789299194818,
    "Buyer Lena": 80.38174435450323,
    "Buyer Nia": 79.77901821113797,
    "Buyer Omar": 80.57434691145302
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Yara",
      "price": 77.86
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Maya": 80.1,
    "Seller Jin": 81.0
  },
  "buyer_bids": {
    "Buyer Omar": 80.36136416231443,
    "Buyer Zoe": 80.42192159221038,
    "Buyer Raj": 80.29837416668653,
    "Buyer Ana": 80.75046504047054,
    "Buyer Tara": 80.70266723031773,
    "Buyer Jun": 80.04420706297984
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Maya",
      "price": 80.43
    }
  ],
  "seller_messages": {
    "Seller Amir": "I will propose a higher ask price than the current asks to attract more buyers.",
    "Seller Yara": "My ask price is higher than the current asks. I request sellers to place their asks at prices higher than the current asks.",
    "Seller Maya": "Buyers, I am planning to place an ask of $80.10 in the current hour. Please let me know your offers.",
    "Seller Jin": "Seller Jin proposes a higher ask price than the current asks to secure trades for our company."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Mia": 98.01
  },
  "buyer_bids": {
    "Buyer Nia": 80.06878393230402,
    "Buyer Jun": 79.34594552612836,
    "Buyer Max": 80.78915448570316,
    "Buyer Leo": 80.60013965973783,
    "Buyer Jin": 79.42799103025412,
    "Buyer Amir": 80.48535208663392
  },
  "trades": [],
  "seller_messages": {
    "Seller Mia": "No message to send."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Leo": 79.2,
    "Seller Amir": 81.0
  },
  "buyer_bids": {
    "Buyer Zoe": 80.20696464768105,
    "Buyer Ana": 80.66603173680846,
    "Buyer Jun": 79.36000043375381,
    "Buyer Tara": 80.35782241654331,
    "Buyer Raj": 79.86588790223095,
    "Buyer Omar": 80.67550169995181
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Leo",
      "price": 79.94
    }
  ],
  "seller_messages": {
    "Seller Jin": "Seller Amir: I will propose a higher ask price than the current asks to attract more buyers."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.70727495641293,
    "Buyer Jun": 79.49418995606175,
    "Buyer Leo": 79.2527558638188,
    "Buyer Amir": 80.47669603091362,
    "Buyer Max": 80.51434754355823,
    "Buyer Nia": 79.58737144816314
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Mia": 97.6,
    "Seller Eli": 79.75
  },
  "buyer_bids": {
    "Buyer Jin": 80.28715897309542,
    "Buyer Nia": 80.52042127787786,
    "Buyer Max": 79.64033730567172,
    "Buyer Amir": 79.54432207220839,
    "Buyer Jun": 79.87107718681925,
    "Buyer Leo": 79.98824861836725
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 80.14
    }
  ],
  "seller_messages": {
    "Seller Eli": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Amir": 79.79529630892972,
    "Buyer Nia": 79.88180981655017,
    "Buyer Max": 80.45298961575457,
    "Buyer Jin": 79.47277083793325,
    "Buyer Leo": 80.56851619121636,
    "Buyer Jun": 79.29950792909393
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Raj": 80.61
  },
  "buyer_bids": {
    "Buyer Nia": 80.09213256506649,
    "Buyer Kit": 80.70495442539057,
    "Buyer Omar": 79.93048178537617,
    "Buyer Lena": 80.5360422392615,
    "Buyer Mia": 80.50349385380235,
    "Buyer Ana": 80.25421648289932
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Raj",
      "price": 80.66
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Leo": 80.0
  },
  "buyer_bids": {
    "Buyer Omar": 79.50375956658564,
    "Buyer Tara": 79.9989792924666,
    "Buyer Raj": 80.01234760081812,
    "Buyer Jun": 79.65465498671031,
    "Buyer Zoe": 80.75752224782084,
    "Buyer Ana": 80.65629609430201
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 80.38
    }
  ],
  "seller_messages": {
    "Seller Leo": "Hey sellers, we're considering a slightly lower ask price to attract more buyers and maximize our profit. Let me know if you're open to it."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Amir": 81.0
  },
  "buyer_bids": {
    "Buyer Ana": 79.37269001935056,
    "Buyer Jun": 80.54392246476716,
    "Buyer Raj": 80.26201248775037,
    "Buyer Omar": 79.46191727543996,
    "Buyer Tara": 80.37242529427499,
    "Buyer Zoe": 79.79283626663319
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 79.96677384627553,
    "Buyer Amir": 79.51134552909173,
    "Buyer Max": 80.36344836712773,
    "Buyer Nia": 80.34898132233495,
    "Buyer Jin": 80.75310706120696,
    "Buyer Leo": 79.29773583337033
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 79.74633427531658,
    "Buyer Omar": 80.29477091578562,
    "Buyer Lena": 79.21347491631094,
    "Buyer Ana": 80.611311269705,
    "Buyer Nia": 79.78655719678586,
    "Buyer Kit": 80.45484776282788
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Yara": 75.0,
    "Seller Raj": 80.0
  },
  "buyer_bids": {
    "Buyer Ana": 79.29087425902316,
    "Buyer Lena": 79.23750829795483,
    "Buyer Omar": 80.41505451240388,
    "Buyer Mia": 79.59920271244962,
    "Buyer Kit": 79.77634957041599,
    "Buyer Nia": 80.63674859663202
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Yara",
      "price": 77.82
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Raj",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Jin": 81.0
  },
  "buyer_bids": {
    "Buyer Tara": 80.25474370179171,
    "Buyer Jun": 79.76523866008678,
    "Buyer Zoe": 80.65560802542305,
    "Buyer Raj": 79.84712778942313,
    "Buyer Omar": 80.5559375831818,
    "Buyer Ana": 79.7501214260157
  },
  "trades": [],
  "seller_messages": {
    "Seller Jin": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Yara": 80.62,
    "Seller Raj": 80.1
  },
  "buyer_bids": {
    "Buyer Nia": 79.20671377592326,
    "Buyer Lena": 79.98201763666643,
    "Buyer Omar": 80.70154242056894,
    "Buyer Mia": 79.65764261886136,
    "Buyer Kit": 80.39628543988604,
    "Buyer Ana": 80.20441003730845
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Raj",
      "price": 80.4
    }
  ],
  "seller_messages": {
    "Seller Raj": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.3163153132515,
    "Buyer Jin": 80.64368677042106,
    "Buyer Max": 79.52546349723994,
    "Buyer Amir": 79.95234585807712,
    "Buyer Leo": 80.42775734732211,
    "Buyer Nia": 80.11162966691762
  },
  "trades": [],
  "seller_messages": {
    "Seller Mia": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 80.54144228818474,
    "Buyer Nia": 80.19455220348055,
    "Buyer Kit": 79.34952584100758,
    "Buyer Mia": 80.29983272929556,
    "Buyer Omar": 79.44552889433837,
    "Buyer Ana": 80.73405447275076
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.68
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Amir": 80.1
  },
  "buyer_bids": {
    "Buyer Zoe": 79.20253559992884,
    "Buyer Raj": 80.70562161808873,
    "Buyer Omar": 80.50136241146076,
    "Buyer Jun": 79.86307923014257,
    "Buyer Tara": 80.06417529134141,
    "Buyer Ana": 79.86144006830364
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Amir",
      "price": 80.4
    }
  ],
  "seller_messages": {
    "Seller Amir": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Maya": 80.1
  },
  "buyer_bids": {
    "Buyer Ana": 79.47313722486344,
    "Buyer Nia": 79.60474706928201,
    "Buyer Lena": 80.66623674611408,
    "Buyer Omar": 79.41072306825119,
    "Buyer Mia": 79.57064811597179,
    "Buyer Kit": 79.92542386812062
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Maya",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 80.30531641259714,
    "Buyer Nia": 79.9327267258355,
    "Buyer Max": 80.38242578560943,
    "Buyer Jun": 79.32651806278129,
    "Buyer Amir": 79.44546043349028,
    "Buyer Leo": 80.07091119624236
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Raj": 79.31272555688898,
    "Buyer Zoe": 79.64991468488645,
    "Buyer Tara": 79.62982677351819,
    "Buyer Ana": 80.58892494459975,
    "Buyer Jun": 80.40663245625004,
    "Buyer Omar": 79.92479805963707
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Zoe": 80.74490162856159,
    "Buyer Omar": 80.36824356925626,
    "Buyer Tara": 79.89064887543964,
    "Buyer Raj": 79.61347333322479,
    "Buyer Ana": 79.6055330383756,
    "Buyer Jun": 80.76278124104847
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.01933095125878,
    "Buyer Kit": 79.34051416207392,
    "Buyer Omar": 79.45637719763725,
    "Buyer Nia": 79.81560442934902,
    "Buyer Lena": 79.23168286301804,
    "Buyer Mia": 79.363057984111
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.33655996174124,
    "Buyer Leo": 80.59926023977286,
    "Buyer Amir": 79.45612764643927,
    "Buyer Jin": 79.55695651337385,
    "Buyer Nia": 79.91701652262984,
    "Buyer Max": 80.2780403204936
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 79.23117261551869,
    "Buyer Ana": 80.67298612706408,
    "Buyer Omar": 80.13014561153918,
    "Buyer Nia": 80.68620906502085,
    "Buyer Mia": 79.96768440444689,
    "Buyer Kit": 80.26126738551443
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Amir",
      "price": 80.67
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 79.2085251961274,
    "Buyer Omar": 80.21967169625596,
    "Buyer Nia": 79.29598523867935,
    "Buyer Kit": 80.62326704965527,
    "Buyer Mia": 80.18169059841382,
    "Buyer Ana": 79.94134372721012
  },
  "trades": [],
  "seller_messages": {
    "Seller Amir": "No new bids placed."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Leo": 79.99
  },
  "buyer_bids": {
    "Buyer Jun": 79.88207900594217,
    "Buyer Zoe": 80.37992200015313,
    "Buyer Omar": 80.25571822680172,
    "Buyer Raj": 80.27984412402922,
    "Buyer Tara": 79.40109331569556,
    "Buyer Ana": 80.48541682149464
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Leo",
      "price": 80.24
    }
  ],
  "seller_messages": {
    "Seller Leo": "Hey everyone, just dropping a.99 to the ask to attract more buyers. Let me know what you guys think."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 80.59181828467578,
    "Buyer Raj": 80.14493435405987,
    "Buyer Omar": 80.64130079233982,
    "Buyer Jun": 79.93736398424527,
    "Buyer Ana": 79.54814454272034,
    "Buyer Zoe": 80.52466105065085
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Amir": 80.0
  },
  "buyer_bids": {
    "Buyer Raj": 79.65016274473778,
    "Buyer Zoe": 80.10134485700965,
    "Buyer Tara": 79.41622902559156,
    "Buyer Jun": 80.49782249912083,
    "Buyer Omar": 80.57205878886867,
    "Buyer Ana": 79.45114447117868
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.29
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.27977119456584,
    "Buyer Amir": 80.54037894567124,
    "Buyer Nia": 80.51635187715311,
    "Buyer Jun": 80.75868301167984,
    "Buyer Leo": 80.07769930362011,
    "Buyer Max": 79.86421985850336
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.73517310191383,
    "Buyer Mia": 79.53921581140342,
    "Buyer Omar": 80.18646634638394,
    "Buyer Lena": 79.36864171057545,
    "Buyer Kit": 79.82576701593004,
    "Buyer Nia": 79.39673365450514
  },
  "trades": [],
  "seller_messages": {
    "Seller Yara": "Hey sellers, please maintain your current bids or add more to keep the market active. Thanks!"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.74216252971036,
    "Buyer Zoe": 79.60846596202978,
    "Buyer Jun": 80.00942157317559,
    "Buyer Ana": 79.62881591032881,
    "Buyer Omar": 79.73157356500874,
    "Buyer Raj": 80.0611339832898
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.68386566972713,
    "Buyer Max": 79.96096876685544,
    "Buyer Amir": 79.51762620060032,
    "Buyer Leo": 80.67643156524534,
    "Buyer Nia": 80.30166400645393,
    "Buyer Jun": 79.49155383229471
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 79.32264261926152,
    "Buyer Zoe": 80.10554642774753,
    "Buyer Jun": 80.08043960599558,
    "Buyer Raj": 80.13985267617588,
    "Buyer Tara": 80.72359396537212,
    "Buyer Ana": 80.68186470720816
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 80.73792465569169,
    "Buyer Jin": 79.78703007624672,
    "Buyer Jun": 80.55910046150689,
    "Buyer Nia": 80.10794846904102,
    "Buyer Max": 80.55417587458055,
    "Buyer Amir": 79.70354117091301
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.45923173565338,
    "Buyer Tara": 80.55203024271529,
    "Buyer Zoe": 79.45431161813744,
    "Buyer Jun": 80.28942406465316,
    "Buyer Raj": 80.13886859918848,
    "Buyer Omar": 79.92145378789166
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.28835772629694,
    "Buyer Mia": 80.07769775900428,
    "Buyer Ana": 79.4502392350291,
    "Buyer Kit": 80.15448906730896,
    "Buyer Lena": 80.3129896483319,
    "Buyer Omar": 79.83147491492781
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Eli": 79.99
  },
  "buyer_bids": {
    "Buyer Jun": 80.13352188217081,
    "Buyer Max": 79.77745057815065,
    "Buyer Amir": 79.25706474830153,
    "Buyer Nia": 79.43906565883057,
    "Buyer Leo": 80.78288484273534,
    "Buyer Jin": 79.6313954253657
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.39
    }
  ],
  "seller_messages": {
    "Seller Eli": "No message to send."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.92937277688219,
    "Buyer Ana": 79.83768825606066,
    "Buyer Jun": 79.70775926077144,
    "Buyer Omar": 79.30270717040767,
    "Buyer Raj": 79.82603048459626,
    "Buyer Zoe": 80.1623150464272
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Raj": 80.1189699726518,
    "Buyer Ana": 79.74221405912321,
    "Buyer Zoe": 79.26568360718777,
    "Buyer Omar": 79.56388197410676,
    "Buyer Tara": 79.4989005603401,
    "Buyer Jun": 80.74655694135171
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 79.73613105696143,
    "Buyer Jin": 79.39891968344553,
    "Buyer Max": 79.26051900746707,
    "Buyer Amir": 80.49972585849346,
    "Buyer Nia": 79.38561290144438,
    "Buyer Jun": 79.99637523205918
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.61625059462904,
    "Buyer Nia": 79.82495049514412,
    "Buyer Lena": 79.65918132200325,
    "Buyer Kit": 79.727063446508,
    "Buyer Mia": 79.47604885725968,
    "Buyer Omar": 80.33344505632797
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 79.82857039582933,
    "Buyer Kit": 79.81320216514847,
    "Buyer Omar": 80.35018957888347,
    "Buyer Nia": 79.94665473033409,
    "Buyer Ana": 80.49557090515094,
    "Buyer Mia": 80.37880519843608
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 80.79857061220308,
    "Buyer Amir": 80.46126203042135,
    "Buyer Max": 79.55222058282446,
    "Buyer Jun": 79.33386118851102,
    "Buyer Nia": 79.54760567454146,
    "Buyer Jin": 80.34305018996362
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.36149513127123,
    "Buyer Jun": 79.95013503864585,
    "Buyer Ana": 80.40116598358374,
    "Buyer Zoe": 80.57458414023137,
    "Buyer Omar": 79.7747062026651,
    "Buyer Raj": 79.2158671413758
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Yara": 79.99
  },
  "buyer_bids": {
    "Buyer Mia": 80.60949890178239,
    "Buyer Lena": 80.66395181431301,
    "Buyer Ana": 80.5060644825336,
    "Buyer Nia": 80.0525672032982,
    "Buyer Omar": 79.50060110572247,
    "Buyer Kit": 79.81208901378196
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Yara",
      "price": 80.33
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 80.51364774588451,
    "Buyer Ana": 80.44758952040753,
    "Buyer Raj": 80.35620567836474,
    "Buyer Tara": 80.0847224335756,
    "Buyer Zoe": 80.27551731952612,
    "Buyer Jun": 80.19764412407703
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 79.983685824921,
    "Buyer Ana": 79.63905561857517,
    "Buyer Omar": 80.48254707097456,
    "Buyer Nia": 80.09235733469725,
    "Buyer Kit": 80.67421948416504,
    "Buyer Mia": 80.1283563040673
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.36740750310385,
    "Buyer Max": 80.52317854346435,
    "Buyer Leo": 79.36759405122626,
    "Buyer Nia": 79.9334528729681,
    "Buyer Amir": 80.19746413405365,
    "Buyer Jun": 79.77862735445966
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 80.04017181573352,
    "Buyer Leo": 80.59917321511365,
    "Buyer Nia": 79.70921510241172,
    "Buyer Amir": 80.32894997552117,
    "Buyer Jun": 79.71491981787048,
    "Buyer Jin": 80.39526221631775
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 79.97725297241698,
    "Buyer Zoe": 80.46890731628464,
    "Buyer Omar": 79.47442816803418,
    "Buyer Ana": 80.53806560443246,
    "Buyer Raj": 79.21738644117964,
    "Buyer Tara": 80.69222310086111
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Amir": 79.9
  },
  "buyer_bids": {
    "Buyer Mia": 79.93651309046183,
    "Buyer Omar": 80.6755993167745,
    "Buyer Kit": 80.60403502586962,
    "Buyer Ana": 79.9348890813225,
    "Buyer Lena": 80.77933904027711,
    "Buyer Nia": 80.67989558785918
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Amir",
      "price": 80.34
    }
  ],
  "seller_messages": {
    "Seller Amir": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 79.8115720975529,
    "Buyer Amir": 80.481032719002,
    "Buyer Nia": 79.93717615566966,
    "Buyer Jin": 80.58991281576256,
    "Buyer Leo": 80.04769225719485,
    "Buyer Jun": 79.79411498910189
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Amir": 80.65
  },
  "buyer_bids": {
    "Buyer Lena": 79.52706422651403,
    "Buyer Kit": 80.5600542233268,
    "Buyer Nia": 79.9478271957268,
    "Buyer Omar": 79.20291185815883,
    "Buyer Mia": 80.10289001992703,
    "Buyer Ana": 79.25442759439944
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 80.29911897753271,
    "Buyer Ana": 80.68817261083737,
    "Buyer Jun": 79.56116892383545,
    "Buyer Zoe": 79.70077580803719,
    "Buyer Omar": 80.22257735409048,
    "Buyer Raj": 80.67269685790917
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.94364537709447,
    "Buyer Omar": 80.0837085410549,
    "Buyer Jun": 79.46428594233134,
    "Buyer Raj": 79.67794873347947,
    "Buyer Ana": 79.6793059211849,
    "Buyer Zoe": 80.32204154415629
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 80.38519264676535,
    "Buyer Leo": 79.68390727647373,
    "Buyer Nia": 79.2327708561061,
    "Buyer Jun": 80.616408073905,
    "Buyer Jin": 80.5836427902944,
    "Buyer Amir": 79.57371375383516
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Eli": 79.99
  },
  "buyer_bids": {
    "Buyer Mia": 80.5570463281982,
    "Buyer Kit": 80.15390766299326,
    "Buyer Nia": 80.67279445043741,
    "Buyer Ana": 79.53697997797877,
    "Buyer Lena": 79.43926131484348,
    "Buyer Omar": 80.01353512565272
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 80.33
    }
  ],
  "seller_messages": {
    "Seller Eli": "I do not need. No new bids were placed in the market."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Eli": 79.99
  },
  "buyer_bids": {
    "Buyer Jin": 80.62393838004262,
    "Buyer Leo": 80.49646159394628,
    "Buyer Max": 80.31791424931733,
    "Buyer Jun": 79.33059142438822,
    "Buyer Amir": 79.42544780363835,
    "Buyer Nia": 80.16314673086629
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Eli",
      "price": 80.31
    }
  ],
  "seller_messages": {
    "Seller Eli": "I will observe the market closely and adjust my offer as necessary to ensure that we secure trades at. a price that maximizes our profitability."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Zoe": 79.60829427991447,
    "Buyer Tara": 79.36167430004508,
    "Buyer Omar": 80.03867834784057,
    "Buyer Raj": 80.07075662290927,
    "Buyer Jun": 79.34464286336832,
    "Buyer Ana": 80.79089769173514
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.54194659374227,
    "Buyer Lena": 79.7803204913914,
    "Buyer Omar": 80.57055544095759,
    "Buyer Mia": 79.7355416114018,
    "Buyer Kit": 79.76973180863125,
    "Buyer Nia": 80.45982166980761
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Tara": 80.0
  },
  "buyer_bids": {
    "Buyer Max": 79.2962573243394,
    "Buyer Jin": 80.45346715183757,
    "Buyer Jun": 79.37759507752988,
    "Buyer Leo": 80.3213078792952,
    "Buyer Amir": 79.51195779303805,
    "Buyer Nia": 80.44393758166217
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.23
    }
  ],
  "seller_messages": {
    "Seller Tara": "I will place a bid on the next available ask and wait for a response."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 80.3990672152311,
    "Buyer Mia": 80.49358911303901,
    "Buyer Omar": 79.62981697092695,
    "Buyer Ana": 80.0809596613992,
    "Buyer Kit": 79.80481018305134,
    "Buyer Nia": 79.4166096238276
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Yara": 97.71
  },
  "buyer_bids": {
    "Buyer Tara": 80.05448726902274,
    "Buyer Jun": 79.53922420882209,
    "Buyer Ana": 80.19584407697778,
    "Buyer Raj": 79.90100631864465,
    "Buyer Zoe": 79.89001680136536,
    "Buyer Omar": 79.98074643563538
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 79.90517557235519,
    "Buyer Lena": 79.34031597248989,
    "Buyer Ana": 79.61267515370503,
    "Buyer Omar": 79.97439979523152,
    "Buyer Nia": 79.69373698705647,
    "Buyer Kit": 80.64213463490013
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Amir": 80.57669149381505,
    "Buyer Jun": 79.82724222474789,
    "Buyer Jin": 80.79334581123743,
    "Buyer Leo": 79.50476409739817,
    "Buyer Nia": 79.2610950563206,
    "Buyer Max": 79.79453062721034
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.43745670965123,
    "Buyer Raj": 79.47656360012033,
    "Buyer Tara": 80.53176788906487,
    "Buyer Omar": 79.52071559754879,
    "Buyer Zoe": 80.41187146009067,
    "Buyer Jun": 79.6978170464723
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 80.7531457321906,
    "Buyer Omar": 80.64112018526289,
    "Buyer Mia": 79.99752222412879,
    "Buyer Kit": 79.52340693385813,
    "Buyer Ana": 79.77571443696439,
    "Buyer Nia": 79.95023600623377
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Amir",
      "price": 80.7
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 80.01137075788154,
    "Buyer Amir": 80.03793845677508,
    "Buyer Jun": 79.43310467512572,
    "Buyer Leo": 79.8752904286728,
    "Buyer Max": 80.6269473739387,
    "Buyer Nia": 80.71277687684828
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 80.23711721620772,
    "Buyer Nia": 79.90976303552155,
    "Buyer Ana": 79.71356497434365,
    "Buyer Kit": 80.12286599690168,
    "Buyer Omar": 79.63505922714225,
    "Buyer Mia": 79.38626373217156
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Tara": 80.05
  },
  "buyer_bids": {
    "Buyer Jin": 79.75271217045639,
    "Buyer Nia": 79.48465225708442,
    "Buyer Max": 79.56878965877303,
    "Buyer Leo": 79.78528395975253,
    "Buyer Jun": 80.5284320828238,
    "Buyer Amir": 80.30684024130557
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Tara",
      "price": 80.29
    }
  ],
  "seller_messages": {
    "Seller Mia": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 79.92213009590218,
    "Buyer Omar": 79.8175936523052,
    "Buyer Lena": 80.14614291343939,
    "Buyer Ana": 79.92423375899979,
    "Buyer Nia": 79.47104472412812,
    "Buyer Kit": 80.60616214404408
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Mia": 97.61
  },
  "buyer_bids": {
    "Buyer Amir": 79.9264769090699,
    "Buyer Leo": 79.53299220040131,
    "Buyer Jun": 79.61315014517496,
    "Buyer Max": 79.24469798763417,
    "Buyer Nia": 80.33196877192464,
    "Buyer Jin": 79.96271025353013
  },
  "trades": [],
  "seller_messages": {
    "Seller Mia": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Kit": 79.30339354850607,
    "Buyer Nia": 79.94468430340012,
    "Buyer Ana": 79.95975481559665,
    "Buyer Lena": 79.24859687255184,
    "Buyer Mia": 79.4231960720869,
    "Buyer Omar": 80.57315760730171
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Amir": 80.2
  },
  "buyer_bids": {
    "Buyer Jun": 80.23901482983345,
    "Buyer Raj": 79.67426017481023,
    "Buyer Ana": 80.27826229049046,
    "Buyer Omar": 80.35890526739978,
    "Buyer Tara": 79.79796362605784,
    "Buyer Zoe": 79.32029371858086
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.28
    }
  ],
  "seller_messages": {
    "Seller Amir": "I'm looking for lower ask prices. Please bid below $80.20."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Lena": 80.69594838282568,
    "Buyer Omar": 80.2022020027534,
    "Buyer Nia": 80.18565807599089,
    "Buyer Ana": 79.73878562000618,
    "Buyer Kit": 80.23616983721979,
    "Buyer Mia": 79.83013923053961
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Zoe": 80.79172934624697,
    "Buyer Jun": 80.09102170471996,
    "Buyer Raj": 79.38095259246431,
    "Buyer Ana": 80.66849977228115,
    "Buyer Tara": 80.21685273168282,
    "Buyer Omar": 79.81181704049008
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.35993149844145,
    "Buyer Kit": 79.98227369769677,
    "Buyer Lena": 79.8730773175131,
    "Buyer Omar": 79.6357946787412,
    "Buyer Mia": 79.64777727400187,
    "Buyer Ana": 80.04381138998693
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Amir": 79.57865150874684,
    "Buyer Jin": 79.4943110739119,
    "Buyer Leo": 80.16193314815223,
    "Buyer Jun": 80.26111282165354,
    "Buyer Nia": 79.79593908095104,
    "Buyer Max": 80.57755936541837
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Eli": 80.0
  },
  "buyer_bids": {
    "Buyer Nia": 79.90607581381786,
    "Buyer Jun": 79.79455452314987,
    "Buyer Max": 80.72374549473389,
    "Buyer Leo": 79.3456903809341,
    "Buyer Amir": 80.73913049373841,
    "Buyer Jin": 80.64201972866857
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Eli",
      "price": 80.37
    }
  ],
  "seller_messages": {
    "Seller Eli": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Eli": 98.1
  },
  "buyer_bids": {
    "Buyer Leo": 79.67156531812958,
    "Buyer Max": 80.4080561185317,
    "Buyer Jun": 79.33839903453932,
    "Buyer Nia": 80.21042707726124,
    "Buyer Amir": 80.03735783270082,
    "Buyer Jin": 79.76858791664165
  },
  "trades": [],
  "seller_messages": {
    "Seller Eli": "null"
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 80.75250022894444,
    "Buyer Raj": 80.28567708002524,
    "Buyer Tara": 80.75917796771324,
    "Buyer Jun": 79.73761632277066,
    "Buyer Ana": 80.12695391685807,
    "Buyer Zoe": 80.19459973078284
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.47727578530335,
    "Buyer Zoe": 79.85782389490535,
    "Buyer Ana": 79.21620490967572,
    "Buyer Tara": 80.29605189018542,
    "Buyer Omar": 80.66025579291086,
    "Buyer Raj": 80.4417239380534
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 79.63212544779441,
    "Buyer Jun": 80.2113049624445,
    "Buyer Jin": 80.06998531534666,
    "Buyer Nia": 79.84848816728697,
    "Buyer Max": 79.23459100867309,
    "Buyer Amir": 80.73746893682912
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Yara": 99.08
  },
  "buyer_bids": {
    "Buyer Ana": 79.64127294546358,
    "Buyer Zoe": 79.57957364184887,
    "Buyer Omar": 79.6870452548133,
    "Buyer Jun": 80.04494847306857,
    "Buyer Raj": 80.21755596028457,
    "Buyer Tara": 79.73431268059099
  },
  "trades": [],
  "seller_messages": {
    "Seller Yara": "No message sent."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
