
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 98.04,
    "Seller Tara": 80.0,
    "Seller Kai": 97.76,
    "Seller Mia": 97.61,
    "Seller Eli": 97.62
  },
  "buyer_bids": {
    "Buyer Max": 80.09570188642384,
    "Buyer Jin": 79.31798789380596,
    "Buyer Amir": 79.35802135145464,
    "Buyer Leo": 79.76606612723079,
    "Buyer Nia": 80.56075812201482,
    "Buyer Jun": 79.7283155497568
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Tara",
      "price": 80.28
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 80.2,
    "Seller Yara": 80.4,
    "Seller Leo": 80.25,
    "Seller Jin": 79.99
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Jin",
      "price": 80.11
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 96.31,
    "Seller Maya": 97.5,
    "Seller Eli": 97.65,
    "Seller Yara": 97.65
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Mia": 97.5,
    "Seller Raj": 98.04
  },
  "buyer_bids": {
    "Buyer Max": 79.90830937463414,
    "Buyer Amir": 79.70591471923454,
    "Buyer Jin": 80.22467744246734,
    "Buyer Leo": 80.034165814644,
    "Buyer Jun": 80.08403788181555,
    "Buyer Nia": 79.5271643992258
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Maya": 80.31
  },
  "buyer_bids": {
    "Buyer Jun": 80.04420706297984,
    "Buyer Raj": 80.29837416668653,
    "Buyer Ana": 80.75046504047054,
    "Buyer Tara": 80.70266723031773,
    "Buyer Omar": 80.36136416231443,
    "Buyer Zoe": 80.42192159221038
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Leo",
      "price": 80.5
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Maya",
      "price": 80.51
    },
    {
      "round_number": 2,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Yara",
      "price": 80.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Raj": 96.31,
    "Seller Amir": 80.0,
    "Seller Yara": 79.5,
    "Seller Eli": 97.67
  },
  "buyer_bids": {
    "Buyer Mia": 79.47774200602409,
    "Buyer Nia": 79.46318147850646,
    "Buyer Kit": 79.48275196939878,
    "Buyer Lena": 80.01626670968798,
    "Buyer Ana": 79.56896427898238,
    "Buyer Omar": 79.48389829678683
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Yara",
      "price": 79.76
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Yara": 96.9,
    "Seller Leo": 80.29
  },
  "buyer_bids": {
    "Buyer Raj": 79.67422462845909,
    "Buyer Jun": 80.7572036112689,
    "Buyer Zoe": 80.00127952023078,
    "Buyer Tara": 80.74753643777498,
    "Buyer Ana": 80.389034656676,
    "Buyer Omar": 80.63292063142639
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Leo",
      "price": 80.52
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Eli": 97.6
  },
  "buyer_bids": {
    "Buyer Nia": 80.52490124544624,
    "Buyer Leo": 80.32582807386483,
    "Buyer Jun": 79.73301621966256,
    "Buyer Max": 80.36844572216516,
    "Buyer Jin": 80.17903533570264,
    "Buyer Amir": 80.20042532683782
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.67559956956248,
    "Buyer Leo": 80.07556817039986,
    "Buyer Jin": 79.73240082042774,
    "Buyer Max": 80.47908337835295,
    "Buyer Amir": 79.39969714340498,
    "Buyer Jun": 79.52512296395109
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Maya": 97.3,
    "Seller Yara": 97.65,
    "Seller Raj": 96.31
  },
  "buyer_bids": {
    "Buyer Lena": 79.83978159088076,
    "Buyer Ana": 80.57434691145302,
    "Buyer Mia": 80.72789299194818,
    "Buyer Nia": 80.14957689468608,
    "Buyer Omar": 79.77901821113797,
    "Buyer Kit": 79.9132303376339
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Amir",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.36141632700361,
    "Buyer Nia": 80.64508264614359,
    "Buyer Omar": 79.76123969039566,
    "Buyer Mia": 79.93048178537617,
    "Buyer Lena": 80.25421648289932,
    "Buyer Kit": 80.09213256506649
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Kai": 97.76
  },
  "buyer_bids": {
    "Buyer Max": 80.29359741677398,
    "Buyer Jun": 80.52697737861395,
    "Buyer Amir": 79.26182651331973,
    "Buyer Leo": 80.54058436996084,
    "Buyer Nia": 80.31891648677686,
    "Buyer Jin": 79.32839730856625
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Amir": 97.55,
    "Seller Yara": 97.67
  },
  "buyer_bids": {
    "Buyer Nia": 79.98225032701363,
    "Buyer Kit": 80.611311269705,
    "Buyer Omar": 79.78655719678586,
    "Buyer Lena": 79.74633427531658,
    "Buyer Mia": 80.45484776282788,
    "Buyer Ana": 80.29477091578562
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.26358963457355,
    "Buyer Tara": 80.38114474266413,
    "Buyer Omar": 79.78739813028335,
    "Buyer Raj": 79.84686095016377,
    "Buyer Jun": 80.61237123850633,
    "Buyer Zoe": 80.44134023993594
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Eli": 97.65,
    "Seller Yara": 97.7
  },
  "buyer_bids": {
    "Buyer Ana": 79.29661571291587,
    "Buyer Kit": 80.63674859663202,
    "Buyer Nia": 80.51959601891612,
    "Buyer Mia": 80.41505451240388,
    "Buyer Omar": 80.70972953892448,
    "Buyer Lena": 79.29087425902316
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Amir": 97.6
  },
  "buyer_bids": {
    "Buyer Omar": 80.03694625725144,
    "Buyer Lena": 79.59652320327068,
    "Buyer Ana": 79.20309800369222,
    "Buyer Nia": 80.37565925340343,
    "Buyer Kit": 80.14313318780852,
    "Buyer Mia": 80.47065267550947
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.38455958946281,
    "Buyer Jun": 79.73643276506755,
    "Buyer Max": 79.50460615447801,
    "Buyer Leo": 79.2259344426571,
    "Buyer Nia": 80.13931952274021,
    "Buyer Amir": 79.71891974941234
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Leo": 80.26
  },
  "buyer_bids": {
    "Buyer Zoe": 80.07734154739589,
    "Buyer Raj": 79.563099753643,
    "Buyer Ana": 79.21968253577379,
    "Buyer Jun": 80.67213829589235,
    "Buyer Tara": 79.84712778942313,
    "Buyer Omar": 79.51922618793985
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Leo",
      "price": 80.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Kit": 80.29983272929556,
    "Buyer Lena": 79.23872612056519,
    "Buyer Nia": 79.44552889433837,
    "Buyer Omar": 80.73405447275076,
    "Buyer Mia": 80.54144228818474,
    "Buyer Ana": 79.34952584100758
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 80.71955082483439,
    "Buyer Raj": 80.70153472114211,
    "Buyer Jun": 80.44383549167344,
    "Buyer Omar": 79.4067990841708,
    "Buyer Zoe": 79.52877641232122,
    "Buyer Ana": 80.01999989520478
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Eli": 0.7
  },
  "buyer_bids": {
    "Buyer Nia": 79.41072306825119,
    "Buyer Ana": 79.92542386812062,
    "Buyer Kit": 79.57064811597179,
    "Buyer Mia": 80.66623674611408,
    "Buyer Lena": 80.33294960181868,
    "Buyer Omar": 79.47313722486344
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 40.68
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Leo": 80.26
  },
  "buyer_bids": {
    "Buyer Ana": 80.21659374448312,
    "Buyer Tara": 80.08164661880848,
    "Buyer Omar": 80.08121002417161,
    "Buyer Raj": 80.48731117522246,
    "Buyer Jun": 79.48925438953648,
    "Buyer Zoe": 79.34656225202608
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Leo",
      "price": 80.37
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Eli": 97.6
  },
  "buyer_bids": {
    "Buyer Jun": 79.34645096504855,
    "Buyer Jin": 80.52813780994359,
    "Buyer Amir": 79.50163299568102,
    "Buyer Leo": 79.38567382140627,
    "Buyer Max": 80.53415108895918,
    "Buyer Nia": 79.39151275624286
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Leo": 80.29,
    "Seller Yara": 96.9
  },
  "buyer_bids": {
    "Buyer Omar": 79.60834578904367,
    "Buyer Zoe": 80.25065040913718,
    "Buyer Raj": 79.66445491396803,
    "Buyer Tara": 80.2371244872998,
    "Buyer Jun": 80.7231322427767,
    "Buyer Ana": 79.46795249175578
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Leo",
      "price": 80.51
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Eli": 97.65
  },
  "buyer_bids": {
    "Buyer Kit": 79.34051416207392,
    "Buyer Omar": 79.45637719763725,
    "Buyer Lena": 79.23168286301804,
    "Buyer Ana": 80.01933095125878,
    "Buyer Mia": 79.363057984111,
    "Buyer Nia": 79.81560442934902
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Kai": 98.03
  },
  "buyer_bids": {
    "Buyer Jin": 79.68169845760218,
    "Buyer Jun": 79.2976679027514,
    "Buyer Max": 79.94740996407722,
    "Buyer Leo": 80.15437587619927,
    "Buyer Amir": 79.31515470322282,
    "Buyer Nia": 79.89770983672521
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Amir": 80.29,
    "Seller Maya": 80.32
  },
  "buyer_bids": {
    "Buyer Omar": 80.74490162856159,
    "Buyer Tara": 79.56059842130976,
    "Buyer Zoe": 80.76088548923514,
    "Buyer Raj": 80.36824356925626,
    "Buyer Ana": 80.76278124104847,
    "Buyer Jun": 79.89064887543964
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 80.53
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Maya",
      "price": 80.54
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Yara": 97.57,
    "Seller Amir": 97.25
  },
  "buyer_bids": {
    "Buyer Omar": 80.14614861072582,
    "Buyer Nia": 79.23411620355935,
    "Buyer Lena": 80.67298612706408,
    "Buyer Kit": 80.68620906502085,
    "Buyer Ana": 80.61029927036782,
    "Buyer Mia": 80.13014561153918
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.52063031215337,
    "Buyer Omar": 80.44054030981746,
    "Buyer Lena": 80.21967169625596,
    "Buyer Nia": 79.51742616701856,
    "Buyer Kit": 80.49929664673117,
    "Buyer Mia": 79.29598523867935
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Kai": 97.76
  },
  "buyer_bids": {
    "Buyer Leo": 79.22112601365596,
    "Buyer Jin": 80.04715875686034,
    "Buyer Max": 80.2649693152287,
    "Buyer Jun": 80.67426943114178,
    "Buyer Nia": 79.38754055019368,
    "Buyer Amir": 79.45912651231662
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Eli": 9.0
  },
  "buyer_bids": {
    "Buyer Lena": 80.18646634638394,
    "Buyer Mia": 79.39673365450514,
    "Buyer Kit": 79.60665964033329,
    "Buyer Ana": 80.6203066840378,
    "Buyer Omar": 79.75190254920773,
    "Buyer Nia": 79.42346449796653
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 44.81
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Raj": 80.27984412402922,
    "Buyer Tara": 79.40109331569556,
    "Buyer Omar": 80.25571822680172,
    "Buyer Ana": 80.48541682149464,
    "Buyer Zoe": 80.37992200015313,
    "Buyer Jun": 79.88207900594217
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Amir": 97.45
  },
  "buyer_bids": {
    "Buyer Omar": 80.58526946875524,
    "Buyer Kit": 80.36466165547787,
    "Buyer Lena": 79.98739448590285,
    "Buyer Mia": 79.87034554400508,
    "Buyer Nia": 79.97472248704796,
    "Buyer Ana": 80.35127491896984
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Leo": 80.3,
    "Seller Amir": 8.0
  },
  "buyer_bids": {
    "Buyer Tara": 79.52065192874588,
    "Buyer Ana": 80.59181828467578,
    "Buyer Zoe": 79.25987740013562,
    "Buyer Jun": 80.19674050222484,
    "Buyer Omar": 80.44802763109234,
    "Buyer Raj": 80.52466105065085
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Amir",
      "price": 44.3
    },
    {
      "round_number": 11,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Leo",
      "price": 80.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.07242264922262,
    "Buyer Mia": 80.65818573111892,
    "Buyer Kit": 80.47771282298743,
    "Buyer Lena": 80.2901676176624,
    "Buyer Ana": 80.63712767442274,
    "Buyer Omar": 80.4900870849701
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Leo": 80.3
  },
  "buyer_bids": {
    "Buyer Omar": 79.65016274473778,
    "Buyer Jun": 79.45114447117868,
    "Buyer Raj": 80.17940537776497,
    "Buyer Tara": 80.49782249912083,
    "Buyer Ana": 79.84371954083059,
    "Buyer Zoe": 80.57205878886867
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Leo",
      "price": 80.44
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Eli": 97.6
  },
  "buyer_bids": {
    "Buyer Leo": 80.27744553517343,
    "Buyer Max": 80.17621704683158,
    "Buyer Jin": 79.4157401709572,
    "Buyer Jun": 79.97092333259852,
    "Buyer Nia": 80.41946664992724,
    "Buyer Amir": 80.07091119624236
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Amir": 8.0
  },
  "buyer_bids": {
    "Buyer Omar": 80.0611339832898,
    "Buyer Tara": 80.00942157317559,
    "Buyer Zoe": 79.73157356500874,
    "Buyer Ana": 79.46648408068404,
    "Buyer Raj": 79.4128272196018,
    "Buyer Jun": 79.62881591032881
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 44.03
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.47130546444531,
    "Buyer Omar": 80.02266552754952,
    "Buyer Lena": 79.575115280201,
    "Buyer Kit": 79.45201787306,
    "Buyer Nia": 79.59776155609327,
    "Buyer Mia": 80.7158174479393
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Mia": 80.65914970229251,
    "Buyer Ana": 80.07612467206391,
    "Buyer Nia": 80.23668556776641,
    "Buyer Lena": 79.33026153757106,
    "Buyer Omar": 79.77617082550498,
    "Buyer Kit": 80.34121530944839
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.54644351875143,
    "Buyer Ana": 79.81725703364995,
    "Buyer Omar": 80.11082802541786,
    "Buyer Lena": 79.82397464293982,
    "Buyer Kit": 79.5447987423501,
    "Buyer Mia": 80.75614215255328
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.2780403204936,
    "Buyer Leo": 80.5947011077622,
    "Buyer Jin": 80.33655996174124,
    "Buyer Jun": 80.59926023977286,
    "Buyer Amir": 79.91701652262984,
    "Buyer Max": 79.25047276499589
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Zoe": 80.68186470720816,
    "Buyer Jun": 80.13985267617588,
    "Buyer Ana": 79.40002760101434,
    "Buyer Tara": 79.32264261926152,
    "Buyer Omar": 79.38350297945959,
    "Buyer Raj": 79.43572541270859
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.05306594177712,
    "Buyer Mia": 79.30471150582635,
    "Buyer Lena": 80.14649842363596,
    "Buyer Nia": 79.76038018468662,
    "Buyer Omar": 80.64908369166163,
    "Buyer Kit": 80.27054087708476
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 80.54037894567124,
    "Buyer Jun": 80.51635187715311,
    "Buyer Max": 80.75868301167984,
    "Buyer Amir": 79.72151024713585,
    "Buyer Leo": 79.86421985850336,
    "Buyer Nia": 79.27977119456584
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Amir": 7.9
  },
  "buyer_bids": {
    "Buyer Tara": 79.92145378789166,
    "Buyer Jun": 80.13886859918848,
    "Buyer Raj": 80.4638051395419,
    "Buyer Omar": 80.45681941495131,
    "Buyer Zoe": 79.45923173565338,
    "Buyer Ana": 79.50067534732382
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Amir",
      "price": 44.18
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.6809658801025,
    "Buyer Zoe": 80.36237396712984,
    "Buyer Ana": 79.24362007392057,
    "Buyer Tara": 79.71240203916841,
    "Buyer Omar": 80.45897592285374,
    "Buyer Raj": 79.7078661446526
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.77674173213683,
    "Buyer Raj": 79.5187454372213,
    "Buyer Jun": 79.34306370000097,
    "Buyer Tara": 79.34478150191319,
    "Buyer Omar": 80.51196327544197,
    "Buyer Zoe": 80.4052586966503
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 80.58808968151708,
    "Buyer Zoe": 79.6289021080876,
    "Buyer Raj": 79.34727027708408,
    "Buyer Ana": 79.55224868083447,
    "Buyer Omar": 80.49322138123225,
    "Buyer Jun": 79.84283784714135
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Kit": 80.28108401649975,
    "Buyer Omar": 79.99917214371757,
    "Buyer Lena": 79.65224772164132,
    "Buyer Nia": 79.28652711108411,
    "Buyer Mia": 79.44935697329521,
    "Buyer Ana": 80.78767318087407
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.51762620060032,
    "Buyer Nia": 79.68386566972713,
    "Buyer Amir": 80.17337542354184,
    "Buyer Leo": 79.96096876685544,
    "Buyer Max": 79.49155383229471,
    "Buyer Jun": 80.30166400645393
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Yara": 96.8
  },
  "buyer_bids": {
    "Buyer Jun": 80.53550265931318,
    "Buyer Raj": 80.584873036382,
    "Buyer Ana": 79.68899660237882,
    "Buyer Zoe": 80.16302824370251,
    "Buyer Omar": 80.33491838591527,
    "Buyer Tara": 79.40207971207809
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 79.61547101209588,
    "Buyer Max": 79.70354117091301,
    "Buyer Leo": 79.78703007624672,
    "Buyer Amir": 80.56198359750002,
    "Buyer Nia": 79.52917718507048,
    "Buyer Jin": 79.26767616320447
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 80.71744279618073,
    "Buyer Ana": 80.2284326123353,
    "Buyer Mia": 80.67279445043741,
    "Buyer Kit": 80.0289355378235,
    "Buyer Omar": 79.69947647635233,
    "Buyer Lena": 80.01353512565272
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Zoe": 79.91471198568645,
    "Buyer Tara": 79.88827425896251,
    "Buyer Omar": 80.44444245176808,
    "Buyer Jun": 80.29132132486565,
    "Buyer Ana": 79.59567501846058,
    "Buyer Raj": 80.57935838303302
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Amir": 97.43
  },
  "buyer_bids": {
    "Buyer Omar": 80.45982166980761,
    "Buyer Mia": 79.76973180863125,
    "Buyer Nia": 80.28060409806508,
    "Buyer Lena": 79.7355416114018,
    "Buyer Ana": 80.57055544095759,
    "Buyer Kit": 79.54194659374227
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Amir": 79.74001770960835,
    "Buyer Jun": 80.4470670654838,
    "Buyer Jin": 79.78752236030698,
    "Buyer Max": 79.25706474830153,
    "Buyer Leo": 79.6313954253657,
    "Buyer Nia": 79.3499320189745
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 79.97759472140642,
    "Buyer Omar": 80.10251510621407,
    "Buyer Ana": 79.64306293008086,
    "Buyer Zoe": 79.34279556552804,
    "Buyer Raj": 80.7731473067872,
    "Buyer Jun": 79.47547875180776
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.62981697092695,
    "Buyer Omar": 79.4166096238276,
    "Buyer Mia": 79.80481018305134,
    "Buyer Kit": 80.0809596613992,
    "Buyer Nia": 79.42439126724122,
    "Buyer Lena": 80.49358911303901
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.73932887126027,
    "Buyer Amir": 80.09732798229047,
    "Buyer Max": 80.49972585849346,
    "Buyer Leo": 79.39891968344553,
    "Buyer Jun": 80.47659897775924,
    "Buyer Jin": 79.96987567512994
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 79.55115069208381,
    "Buyer Zoe": 80.2324614867857,
    "Buyer Omar": 80.67456561412277,
    "Buyer Jun": 80.42111088647475,
    "Buyer Tara": 79.7899041910108,
    "Buyer Raj": 80.75576602991121
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.316270534604,
    "Buyer Omar": 79.69373698705647,
    "Buyer Lena": 79.90517557235519,
    "Buyer Kit": 79.61267515370503,
    "Buyer Mia": 80.64213463490013,
    "Buyer Ana": 79.97439979523152
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Jin": 80.37
  },
  "buyer_bids": {
    "Buyer Ana": 80.70670927249809,
    "Buyer Tara": 79.82977159878197,
    "Buyer Jun": 80.4516297823445,
    "Buyer Raj": 79.88280461093925,
    "Buyer Zoe": 79.9920413336949,
    "Buyer Omar": 80.35135627696215
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Jin",
      "price": 80.54
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Amir": 0.79,
    "Seller Yara": 96.9
  },
  "buyer_bids": {
    "Buyer Raj": 80.74688185047765,
    "Buyer Omar": 79.33121325308154,
    "Buyer Ana": 80.29860672593603,
    "Buyer Zoe": 79.58558447326669,
    "Buyer Jun": 80.56155263095269,
    "Buyer Tara": 80.56160132148688
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Amir",
      "price": 40.77
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jun": 80.67224429236197,
    "Buyer Nia": 79.66371329365425,
    "Buyer Amir": 79.3569224166132,
    "Buyer Max": 80.46126203042135,
    "Buyer Jin": 80.0903593721271,
    "Buyer Leo": 80.34305018996362
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Eli": 97.68,
    "Seller Raj": 96.33
  },
  "buyer_bids": {
    "Buyer Lena": 80.64112018526289,
    "Buyer Kit": 80.06583636146371,
    "Buyer Mia": 79.95023600623377,
    "Buyer Ana": 80.15143204200163,
    "Buyer Omar": 80.52011333505547,
    "Buyer Nia": 79.71262790246928
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.5227006687988,
    "Buyer Leo": 80.79526479182198,
    "Buyer Jun": 79.61036747941054,
    "Buyer Nia": 79.99533995864337,
    "Buyer Max": 80.22559562971713,
    "Buyer Amir": 80.40390144201423
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Maya": 80.38
  },
  "buyer_bids": {
    "Buyer Jun": 79.64427589473982,
    "Buyer Raj": 80.05448726902274,
    "Buyer Ana": 80.65487365863432,
    "Buyer Tara": 80.09499859814655,
    "Buyer Omar": 80.25681553239197,
    "Buyer Zoe": 79.80615920721979
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Maya",
      "price": 80.52
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Kit": 80.70415379253375,
    "Buyer Nia": 80.3317395715724,
    "Buyer Omar": 80.36485849154717,
    "Buyer Lena": 80.17832199408636,
    "Buyer Mia": 80.2367589446046,
    "Buyer Ana": 79.27496376438687
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 80.06849451791966,
    "Buyer Amir": 80.53365359900523,
    "Buyer Jun": 80.59951840879906,
    "Buyer Jin": 80.79709287284192,
    "Buyer Leo": 80.6901014473292,
    "Buyer Nia": 80.21610366904817
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Zoe": 79.87194646424886,
    "Buyer Jun": 79.77112868417274,
    "Buyer Tara": 79.3948800178655,
    "Buyer Ana": 80.56814277140637,
    "Buyer Raj": 80.57798576126879,
    "Buyer Omar": 79.46876730376931
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Ana": 80.19444893118782,
    "Buyer Mia": 80.01668410943253,
    "Buyer Lena": 80.2634841440312,
    "Buyer Kit": 79.34487599835396,
    "Buyer Omar": 80.07140992686318,
    "Buyer Nia": 80.59419362922714
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Omar": 80.41377632055753,
    "Buyer Jun": 79.71790053845459,
    "Buyer Raj": 79.89947069290915,
    "Buyer Zoe": 79.39824125101941,
    "Buyer Tara": 80.34874823629322,
    "Buyer Ana": 80.28362065979026
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Tara": 80.02705995331962,
    "Buyer Zoe": 80.16133181851617,
    "Buyer Jun": 80.677293663759,
    "Buyer Raj": 80.38170383965279,
    "Buyer Omar": 79.51820683463833,
    "Buyer Ana": 80.36540886772823
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Kai": 97.76
  },
  "buyer_bids": {
    "Buyer Nia": 79.408790636547,
    "Buyer Jin": 79.306167497934,
    "Buyer Jun": 79.68071726578815,
    "Buyer Leo": 79.91774255431407,
    "Buyer Max": 80.41423796229309,
    "Buyer Amir": 80.66482282923955
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Amir": 97.4,
    "Seller Raj": 96.31
  },
  "buyer_bids": {
    "Buyer Nia": 80.33172835122161,
    "Buyer Ana": 80.26991131723692,
    "Buyer Lena": 79.88368781411367,
    "Buyer Omar": 79.60471438295794,
    "Buyer Kit": 79.55294325558113,
    "Buyer Mia": 79.23990419086051
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Kit": 80.04556066841486,
    "Buyer Lena": 79.79443430295113,
    "Buyer Nia": 79.20996101882515,
    "Buyer Ana": 79.74013868191058,
    "Buyer Mia": 79.58157603907546,
    "Buyer Omar": 80.50278341201407
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Yara": 96.9,
    "Seller Maya": 80.35
  },
  "buyer_bids": {
    "Buyer Raj": 80.74799201189009,
    "Buyer Zoe": 80.74720700560505,
    "Buyer Jun": 79.59621020126767,
    "Buyer Ana": 79.30839316240194,
    "Buyer Omar": 80.78021355564319,
    "Buyer Tara": 79.66541760718435
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Maya",
      "price": 80.57
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Eli": 97.95,
    "Seller Amir": 97.4
  },
  "buyer_bids": {
    "Buyer Ana": 80.7314792181291,
    "Buyer Nia": 80.53330338976154,
    "Buyer Mia": 79.5230276500868,
    "Buyer Lena": 79.74502125300006,
    "Buyer Omar": 79.44222219737925,
    "Buyer Kit": 79.47755300256372
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Amir": 7.9
  },
  "buyer_bids": {
    "Buyer Zoe": 80.01652232462631,
    "Buyer Raj": 79.68587014856422,
    "Buyer Ana": 79.9393132189867,
    "Buyer Omar": 79.61496136766128,
    "Buyer Tara": 79.6333127559457,
    "Buyer Jun": 79.47139505704763
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Amir",
      "price": 43.96
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 80.75607761719482,
    "Buyer Jin": 80.40738922603255,
    "Buyer Amir": 79.88218668586947,
    "Buyer Nia": 79.66346262139578,
    "Buyer Max": 79.86854504139062,
    "Buyer Jun": 80.64182195184964
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 80.36712106263566,
    "Buyer Jin": 79.81388708427261,
    "Buyer Max": 79.58232272013531,
    "Buyer Jun": 80.69683894070769,
    "Buyer Nia": 79.46207267810088,
    "Buyer Amir": 79.81465556395099
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Eli": 97.59
  },
  "buyer_bids": {
    "Buyer Jun": 79.71825816756837,
    "Buyer Nia": 79.41232312476595,
    "Buyer Jin": 80.15728041669607,
    "Buyer Leo": 80.23838761266074,
    "Buyer Amir": 79.23236491718848,
    "Buyer Max": 80.32012750564985
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.67008565565213,
    "Buyer Amir": 80.73355052365999,
    "Buyer Jin": 79.82023310422112,
    "Buyer Leo": 80.77343692553342,
    "Buyer Jun": 80.39325456467311,
    "Buyer Max": 80.73207498408564
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.56744837872358,
    "Buyer Leo": 80.20388440822835,
    "Buyer Jin": 80.60140365619634,
    "Buyer Jun": 80.44214823030703,
    "Buyer Max": 80.61549768315282,
    "Buyer Amir": 80.11081081118341
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Max": 79.99459963940718,
    "Buyer Nia": 79.88973810298941,
    "Buyer Leo": 80.5824922795563,
    "Buyer Amir": 80.72728614843727,
    "Buyer Jun": 79.8672312144057,
    "Buyer Jin": 80.46614856060408
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Leo": 79.57258096765489,
    "Buyer Nia": 79.66922072612203,
    "Buyer Max": 80.69246085411129,
    "Buyer Amir": 80.6414463057898,
    "Buyer Jin": 80.39676290759068,
    "Buyer Jun": 80.30314636259854
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Nia": 79.32929442051149,
    "Buyer Jin": 80.14883103362264,
    "Buyer Leo": 79.80254229185194,
    "Buyer Amir": 79.72317462186868,
    "Buyer Jun": 80.05316460825026,
    "Buyer Max": 79.69241999574189
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Mia": 97.6,
    "Seller Raj": 9.8
  },
  "buyer_bids": {
    "Buyer Leo": 80.21244639598436,
    "Buyer Nia": 79.67684497400482,
    "Buyer Max": 79.59689360195173,
    "Buyer Amir": 80.6822342412744,
    "Buyer Jun": 79.76730258565611,
    "Buyer Jin": 80.14572243001686
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 45.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Tara": 80.1,
    "Seller Raj": 9.8
  },
  "buyer_bids": {
    "Buyer Max": 80.16887337789774,
    "Buyer Amir": 79.3456903809341,
    "Buyer Nia": 79.3737844261762,
    "Buyer Jun": 79.37945398757674,
    "Buyer Jin": 79.4967331265988,
    "Buyer Leo": 79.44620613808223
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 44.98
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
