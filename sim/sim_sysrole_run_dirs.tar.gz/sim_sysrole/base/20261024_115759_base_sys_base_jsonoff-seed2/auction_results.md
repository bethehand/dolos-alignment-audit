
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Amir": 81.5,
    "Seller Eli": 96.5
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Raj",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Yara": 80.1,
    "Seller Eli": 78.5,
    "Seller Amir": 97.55
  },
  "buyer_bids": {
    "Buyer Omar": 79.46318147850646,
    "Buyer Ana": 79.48389829678683,
    "Buyer Nia": 80.61450330645742,
    "Buyer Mia": 79.48275196939878,
    "Buyer Kit": 79.56896427898238,
    "Buyer Lena": 79.47774200602409
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Eli",
      "price": 79.56
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Maya": 80.55,
    "Seller Amir": 81.5,
    "Seller Yara": 80.0
  },
  "buyer_bids": {
    "Buyer Omar": 79.77550624607424,
    "Buyer Mia": 80.79228427283253,
    "Buyer Kit": 80.09582450606636,
    "Buyer Nia": 80.01626670968798,
    "Buyer Lena": 79.91302017923307,
    "Buyer Ana": 80.02197984068965
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Raj",
      "price": 80.4
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Yara",
      "price": 80.05
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Eli": 78.5,
    "Seller Maya": 80.84,
    "Seller Amir": 81.5
  },
  "buyer_bids": {
    "Buyer Omar": 80.04058514722102,
    "Buyer Lena": 79.77901821113797,
    "Buyer Nia": 79.86347359102251,
    "Buyer Ana": 80.65356492713553,
    "Buyer Mia": 80.14957689468608,
    "Buyer Kit": 79.78280883776841
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 79.58
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Raj": 80.2,
    "Seller Maya": 80.9,
    "Seller Amir": 82.0
  },
  "buyer_bids": {
    "Buyer Nia": 79.9132303376339,
    "Buyer Kit": 80.38174435450323,
    "Buyer Omar": 80.72789299194818,
    "Buyer Lena": 79.59984282839315,
    "Buyer Ana": 79.83978159088076,
    "Buyer Mia": 80.2478575650496
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Raj",
      "price": 80.46
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Yara": 80.0,
    "Seller Raj": 80.2,
    "Seller Eli": 78.5,
    "Seller Maya": 80.95,
    "Seller Amir": 80.55
  },
  "buyer_bids": {
    "Buyer Ana": 80.47394599144368,
    "Buyer Mia": 79.92750205874086,
    "Buyer Nia": 79.99690468908358,
    "Buyer Lena": 80.64508264614359,
    "Buyer Kit": 80.25869696000638,
    "Buyer Omar": 80.02462752856641
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Eli",
      "price": 79.57
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.24
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Raj",
      "price": 80.23
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Raj": 80.21,
    "Seller Eli": 78.75,
    "Seller Yara": 80.0,
    "Seller Maya": 80.65,
    "Seller Amir": 80.35
  },
  "buyer_bids": {
    "Buyer Mia": 80.50349385380235,
    "Buyer Kit": 80.70495442539057,
    "Buyer Nia": 80.09213256506649,
    "Buyer Lena": 80.5360422392615,
    "Buyer Omar": 79.93048178537617,
    "Buyer Ana": 80.25421648289932
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 79.73
    },
    {
      "round_number": 7,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Yara",
      "price": 80.27
    },
    {
      "round_number": 7,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Raj",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Raj": 80.21,
    "Seller Eli": 78.51,
    "Seller Maya": 80.95,
    "Seller Yara": 80.0,
    "Seller Amir": 82.1
  },
  "buyer_bids": {
    "Buyer Nia": 79.68527479120924,
    "Buyer Kit": 80.09950192591843,
    "Buyer Mia": 80.01177070917386,
    "Buyer Omar": 80.47881420500524,
    "Buyer Ana": 80.5297085464507,
    "Buyer Lena": 80.18529314503604
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 79.52
    },
    {
      "round_number": 8,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Raj": 80.22,
    "Seller Eli": 78.45,
    "Seller Maya": 80.85,
    "Seller Yara": 80.0,
    "Seller Amir": 80.28
  },
  "buyer_bids": {
    "Buyer Lena": 80.611311269705,
    "Buyer Kit": 79.78655719678586,
    "Buyer Nia": 79.85067284478956,
    "Buyer Ana": 79.98225032701363,
    "Buyer Omar": 80.36948780069136,
    "Buyer Mia": 80.29477091578562
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Eli",
      "price": 79.53
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.18
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Raj",
      "price": 80.26
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Raj": 80.25,
    "Seller Eli": 78.5,
    "Seller Yara": 80.0,
    "Seller Amir": 80.26
  },
  "buyer_bids": {
    "Buyer Ana": 80.7953097551439,
    "Buyer Omar": 80.50409517516378,
    "Buyer Lena": 79.27825620499968,
    "Buyer Mia": 80.11906393352639,
    "Buyer Nia": 79.21347491631094,
    "Buyer Kit": 79.3698510773034
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 79.65
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Raj": 80.28,
    "Seller Eli": 78.45,
    "Seller Maya": 80.84,
    "Seller Yara": 80.0,
    "Seller Amir": 80.25
  },
  "buyer_bids": {
    "Buyer Nia": 80.14672050746222,
    "Buyer Lena": 79.62534592443505,
    "Buyer Kit": 80.40699165490105,
    "Buyer Mia": 79.41839983289174,
    "Buyer Omar": 80.29196426720013,
    "Buyer Ana": 80.66534553892929
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 79.56
    },
    {
      "round_number": 11,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Yara",
      "price": 80.2
    },
    {
      "round_number": 11,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.27
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Maya": 80.85,
    "Seller Eli": 78.45,
    "Seller Yara": 80.0,
    "Seller Amir": 80.25,
    "Seller Raj": 80.28
  },
  "buyer_bids": {
    "Buyer Mia": 80.41505451240388,
    "Buyer Ana": 79.29661571291587,
    "Buyer Nia": 80.51959601891612,
    "Buyer Omar": 80.70972953892448,
    "Buyer Kit": 80.63674859663202,
    "Buyer Lena": 79.29087425902316
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Eli",
      "price": 79.58
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Yara",
      "price": 80.32
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Amir",
      "price": 80.38
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Raj",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Maya": 80.85,
    "Seller Raj": 80.3,
    "Seller Amir": 80.25
  },
  "buyer_bids": {
    "Buyer Kit": 79.38435692733005,
    "Buyer Omar": 79.59920271244962,
    "Buyer Ana": 79.23750829795483,
    "Buyer Mia": 79.3079465392273,
    "Buyer Nia": 79.77634957041599,
    "Buyer Lena": 79.26539932166843
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Maya": 80.9,
    "Seller Raj": 80.4,
    "Seller Eli": 78.48,
    "Seller Amir": 80.3
  },
  "buyer_bids": {
    "Buyer Kit": 80.6975444693222,
    "Buyer Nia": 80.6698080542224,
    "Buyer Lena": 80.03694625725144,
    "Buyer Mia": 80.37565925340343,
    "Buyer Omar": 79.79695564813244,
    "Buyer Ana": 79.40445941464131
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 79.59
    },
    {
      "round_number": 14,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Amir",
      "price": 80.48
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Eli": 78.47,
    "Seller Raj": 80.45,
    "Seller Maya": 80.89,
    "Seller Amir": 80.33
  },
  "buyer_bids": {
    "Buyer Omar": 80.75330760522209,
    "Buyer Nia": 79.59652320327068,
    "Buyer Ana": 79.20671377592326,
    "Buyer Mia": 80.20441003730845,
    "Buyer Lena": 80.39628543988604,
    "Buyer Kit": 80.70154242056894
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Eli",
      "price": 79.61
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Amir",
      "price": 80.52
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Raj": 80.5,
    "Seller Maya": 80.95,
    "Seller Amir": 80.33
  },
  "buyer_bids": {
    "Buyer Mia": 79.84296637609536,
    "Buyer Omar": 80.16824948477682,
    "Buyer Kit": 79.62230748838975,
    "Buyer Lena": 80.19455220348055,
    "Buyer Ana": 79.27323593976521,
    "Buyer Nia": 80.08240532596075
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Eli": 78.47,
    "Seller Raj": 80.55,
    "Seller Maya": 80.86,
    "Seller Amir": 80.33
  },
  "buyer_bids": {
    "Buyer Omar": 80.54144228818474,
    "Buyer Mia": 80.7169507876341,
    "Buyer Kit": 80.46145493834928,
    "Buyer Ana": 79.23872612056519,
    "Buyer Nia": 80.29983272929556,
    "Buyer Lena": 80.0292577694053
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 79.59
    },
    {
      "round_number": 17,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.44
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Maya": 80.85,
    "Seller Raj": 80.55,
    "Seller Eli": 78.47,
    "Seller Amir": 80.35
  },
  "buyer_bids": {
    "Buyer Mia": 80.24530340454618,
    "Buyer Kit": 80.75309378409095,
    "Buyer Nia": 80.59910923194565,
    "Buyer Ana": 79.6189398360977,
    "Buyer Lena": 80.3191580958122,
    "Buyer Omar": 79.74568165849563
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 79.61
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Amir",
      "price": 80.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Eli": 78.48,
    "Seller Amir": 80.35,
    "Seller Maya": 80.86
  },
  "buyer_bids": {
    "Buyer Lena": 80.33294960181868,
    "Buyer Mia": 80.66623674611408,
    "Buyer Kit": 79.57064811597179,
    "Buyer Nia": 79.41072306825119,
    "Buyer Ana": 79.92542386812062,
    "Buyer Omar": 79.47313722486344
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 79.57
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Eli": 78.49,
    "Seller Raj": 80.55,
    "Seller Maya": 80.85,
    "Seller Amir": 80.35
  },
  "buyer_bids": {
    "Buyer Lena": 79.77572642870675,
    "Buyer Kit": 80.46653373003254,
    "Buyer Ana": 79.5651251509686,
    "Buyer Omar": 79.32868674506233,
    "Buyer Nia": 79.3176762610767,
    "Buyer Mia": 80.19825517784952
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 79.48
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Eli": 80.44,
    "Seller Maya": 80.85,
    "Seller Yara": 80.0,
    "Seller Amir": 80.35
  },
  "buyer_bids": {
    "Buyer Kit": 80.01933095125878,
    "Buyer Lena": 79.363057984111,
    "Buyer Ana": 79.45637719763725,
    "Buyer Omar": 79.81560442934902,
    "Buyer Mia": 79.34051416207392,
    "Buyer Nia": 79.44178471607566
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Yara",
      "price": 80.01
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Maya": 80.44,
    "Seller Raj": 80.55,
    "Seller Eli": 80.45,
    "Seller Yara": 80.0,
    "Seller Amir": 80.35
  },
  "buyer_bids": {
    "Buyer Ana": 79.36835888883297,
    "Buyer Lena": 79.92617235552939,
    "Buyer Mia": 80.27118349628928,
    "Buyer Omar": 80.40093630828292,
    "Buyer Kit": 79.23910416985436,
    "Buyer Nia": 79.23168286301804
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.2
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Maya": 80.44,
    "Seller Eli": 78.47,
    "Seller Amir": 80.35
  },
  "buyer_bids": {
    "Buyer Mia": 79.53622482691921,
    "Buyer Kit": 80.41683983758827,
    "Buyer Omar": 79.80800433412134,
    "Buyer Lena": 80.48972763340157,
    "Buyer Nia": 80.05685334970664,
    "Buyer Ana": 80.29549858458714
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Eli",
      "price": 79.48
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Amir",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Maya": 80.44,
    "Seller Amir": 80.35
  },
  "buyer_bids": {
    "Buyer Omar": 80.68620906502085,
    "Buyer Lena": 79.96768440444689,
    "Buyer Kit": 80.67298612706408,
    "Buyer Nia": 80.61029927036782,
    "Buyer Ana": 80.13014561153918,
    "Buyer Mia": 80.26126738551443
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Amir",
      "price": 80.52
    },
    {
      "round_number": 24,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Maya",
      "price": 80.56
    },
    {
      "round_number": 24,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.58
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Eli": 78.47,
    "Seller Amir": 80.35
  },
  "buyer_bids": {
    "Buyer Lena": 80.69191574301989,
    "Buyer Omar": 80.73707191850485,
    "Buyer Mia": 80.30463151912117,
    "Buyer Kit": 79.78637252199151,
    "Buyer Ana": 79.38974556458605,
    "Buyer Nia": 79.23117261551869
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Eli",
      "price": 79.6
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Amir",
      "price": 80.52
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Maya": 80.95,
    "Seller Amir": 80.4,
    "Seller Eli": 78.47
  },
  "buyer_bids": {
    "Buyer Omar": 79.51742616701856,
    "Buyer Lena": 79.29598523867935,
    "Buyer Kit": 80.52063031215337,
    "Buyer Nia": 79.36802642710117,
    "Buyer Mia": 80.49929664673117,
    "Buyer Ana": 80.44054030981746
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 79.5
    },
    {
      "round_number": 26,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Amir",
      "price": 80.45
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Maya": 80.89,
    "Seller Eli": 78.47,
    "Seller Amir": 80.4
  },
  "buyer_bids": {
    "Buyer Nia": 80.18169059841382,
    "Buyer Kit": 79.68931422156417,
    "Buyer Lena": 79.55066444581729,
    "Buyer Omar": 79.2085251961274,
    "Buyer Ana": 79.2386271521199,
    "Buyer Mia": 80.35770399661718
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Mia",
      "seller_id": "Seller Eli",
      "price": 79.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Maya": 80.95,
    "Seller Eli": 78.47,
    "Seller Amir": 80.4
  },
  "buyer_bids": {
    "Buyer Lena": 79.39673365450514,
    "Buyer Omar": 79.42346449796653,
    "Buyer Nia": 80.34547948197394,
    "Buyer Mia": 79.60665964033329,
    "Buyer Ana": 79.75190254920773,
    "Buyer Kit": 80.6203066840378
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Kit",
      "seller_id": "Seller Eli",
      "price": 79.55
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Raj": 80.55,
    "Seller Maya": 80.95,
    "Seller Eli": 78.46,
    "Seller Amir": 80.41
  },
  "buyer_bids": {
    "Buyer Ana": 80.189091165771,
    "Buyer Kit": 79.95259917708889,
    "Buyer Nia": 79.53921581140342,
    "Buyer Omar": 79.36864171057545,
    "Buyer Lena": 80.32928568718374,
    "Buyer Mia": 79.26908872990035
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Lena",
      "seller_id": "Seller Eli",
      "price": 79.39
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Raj": 80.6,
    "Seller Maya": 80.95,
    "Seller Eli": 78.46,
    "Seller Amir": 80.41
  },
  "buyer_bids": {
    "Buyer Omar": 79.97472248704796,
    "Buyer Nia": 79.7998600038164,
    "Buyer Ana": 80.58526946875524,
    "Buyer Kit": 80.35127491896984,
    "Buyer Lena": 79.87034554400508,
    "Buyer Mia": 80.36466165547787
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Eli",
      "price": 79.52
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
