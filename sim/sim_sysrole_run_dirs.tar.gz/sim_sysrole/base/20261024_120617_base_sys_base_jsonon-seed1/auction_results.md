
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 81.35,
    "Seller Amir": 97.01,
    "Seller Yara": 97.01,
    "Seller Leo": 96.3,
    "Seller Jin": 96.3
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Jin": 96.3,
    "Seller Amir": 98.0,
    "Seller Yara": 96.5,
    "Seller Leo": 96.35,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Ana": 80.29837416668653,
    "Buyer Tara": 80.42192159221038,
    "Buyer Raj": 80.60997417427545,
    "Buyer Jun": 80.36136416231443,
    "Buyer Zoe": 80.04420706297984,
    "Buyer Omar": 80.75046504047054
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Amir": 98.0,
    "Seller Maya": 81.25,
    "Seller Yara": 96.45,
    "Seller Leo": 96.4,
    "Seller Jin": 96.3
  },
  "buyer_bids": {
    "Buyer Tara": 80.72359112846591,
    "Buyer Ana": 80.08457532206874,
    "Buyer Omar": 79.753120663534,
    "Buyer Raj": 80.70266723031773,
    "Buyer Zoe": 80.4175163800669,
    "Buyer Jun": 80.28295766375996
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Yara": 96.4,
    "Seller Amir": 98.0,
    "Seller Leo": 96.37,
    "Seller Jin": 96.3,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Omar": 80.66603173680846,
    "Buyer Jun": 80.67550169995181,
    "Buyer Ana": 79.86588790223095,
    "Buyer Zoe": 79.36000043375381,
    "Buyer Tara": 80.20696464768105,
    "Buyer Raj": 80.68241059805737
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Yara": 96.48,
    "Seller Amir": 98.0,
    "Seller Maya": 81.25,
    "Seller Leo": 96.4,
    "Seller Jin": 96.3
  },
  "buyer_bids": {
    "Buyer Raj": 80.35782241654331,
    "Buyer Omar": 80.389034656676,
    "Buyer Ana": 79.67422462845909,
    "Buyer Jun": 80.63292063142639,
    "Buyer Tara": 80.00127952023078,
    "Buyer Zoe": 80.7572036112689
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Yara": 96.44,
    "Seller Jin": 96.3,
    "Seller Leo": 96.4,
    "Seller Amir": 98.0,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Tara": 80.75752224782084,
    "Buyer Omar": 80.65629609430201,
    "Buyer Jun": 79.50375956658564,
    "Buyer Raj": 80.74753643777498,
    "Buyer Ana": 80.01234760081812,
    "Buyer Zoe": 79.65465498671031
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Jin": 96.3,
    "Seller Leo": 96.38,
    "Seller Amir": 98.0,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Zoe": 79.96836315682816,
    "Buyer Ana": 80.70546156770328,
    "Buyer Jun": 80.56526072066458,
    "Buyer Raj": 79.9989792924666,
    "Buyer Tara": 80.38996904846911,
    "Buyer Omar": 79.82936579691174
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Amir": 98.0,
    "Seller Yara": 96.38,
    "Seller Jin": 96.3,
    "Seller Leo": 96.28,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Omar": 79.78739813028335,
    "Buyer Zoe": 80.44134023993594,
    "Buyer Raj": 79.84686095016377,
    "Buyer Jun": 80.61237123850633,
    "Buyer Tara": 80.38114474266413,
    "Buyer Ana": 80.26358963457355
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Jin": 96.31,
    "Seller Yara": 96.38,
    "Seller Leo": 96.28,
    "Seller Amir": 97.0,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Zoe": 80.54392246476716,
    "Buyer Ana": 80.26201248775037,
    "Buyer Raj": 79.3383481435652,
    "Buyer Omar": 79.37269001935056,
    "Buyer Jun": 79.46191727543996,
    "Buyer Tara": 79.79283626663319
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Yara": 96.45,
    "Seller Amir": 98.0,
    "Seller Leo": 96.28,
    "Seller Jin": 96.31,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Zoe": 80.18369714728813,
    "Buyer Raj": 80.37242529427499,
    "Buyer Omar": 79.69364708308437,
    "Buyer Ana": 79.95091222576484,
    "Buyer Jun": 80.5572825191401,
    "Buyer Tara": 80.1250814484787
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Yara": 96.44,
    "Seller Jin": 96.31,
    "Seller Leo": 96.38,
    "Seller Amir": 97.0,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Jun": 79.21968253577379,
    "Buyer Ana": 79.46975087526128,
    "Buyer Zoe": 79.51922618793985,
    "Buyer Tara": 80.67213829589235,
    "Buyer Omar": 79.563099753643,
    "Buyer Raj": 80.23544986451088
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Amir": 98.0,
    "Seller Jin": 96.31,
    "Seller Yara": 96.44,
    "Seller Maya": 81.25,
    "Seller Leo": 96.36
  },
  "buyer_bids": {
    "Buyer Tara": 80.65560802542305,
    "Buyer Omar": 79.7501214260157,
    "Buyer Ana": 79.84712778942313,
    "Buyer Raj": 80.07734154739589,
    "Buyer Jun": 80.5559375831818,
    "Buyer Zoe": 79.76523866008678
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Jin": 96.31,
    "Seller Yara": 96.44,
    "Seller Maya": 81.25,
    "Seller Leo": 96.36
  },
  "buyer_bids": {
    "Buyer Omar": 80.36704028851639,
    "Buyer Raj": 80.25474370179171,
    "Buyer Jun": 79.81390341262406,
    "Buyer Tara": 80.72743408544278,
    "Buyer Ana": 80.1743117208137,
    "Buyer Zoe": 80.5711186029969
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Jin": 96.31,
    "Seller Yara": 96.44,
    "Seller Leo": 96.3,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Zoe": 79.52877641232122,
    "Buyer Ana": 80.01999989520478,
    "Buyer Omar": 79.4067990841708,
    "Buyer Raj": 80.70153472114211,
    "Buyer Jun": 80.44383549167344,
    "Buyer Tara": 80.71955082483439
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Jin": 96.31,
    "Seller Yara": 96.38,
    "Seller Amir": 97.0,
    "Seller Maya": 81.25,
    "Seller Leo": 96.25
  },
  "buyer_bids": {
    "Buyer Raj": 79.96976290786279,
    "Buyer Ana": 79.78357767546176,
    "Buyer Jun": 80.70562161808873,
    "Buyer Omar": 80.08704190492439,
    "Buyer Zoe": 79.86144006830364,
    "Buyer Tara": 80.50136241146076
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Leo": 96.25,
    "Seller Maya": 81.25,
    "Seller Yara": 96.5
  },
  "buyer_bids": {
    "Buyer Omar": 80.06417529134141,
    "Buyer Raj": 79.86307923014257,
    "Buyer Ana": 79.20253559992884,
    "Buyer Zoe": 79.72981992314037,
    "Buyer Tara": 80.15976829562157,
    "Buyer Jun": 80.45831101670805
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Leo": 96.25,
    "Seller Jin": 96.32,
    "Seller Yara": 96.5,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Ana": 80.21659374448312,
    "Buyer Zoe": 79.34656225202608,
    "Buyer Jun": 79.48925438953648,
    "Buyer Raj": 80.48731117522246,
    "Buyer Omar": 80.08121002417161,
    "Buyer Tara": 80.08164661880848
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Leo": 96.25,
    "Seller Amir": 98.0,
    "Seller Yara": 96.5,
    "Seller Maya": 81.35
  },
  "buyer_bids": {
    "Buyer Ana": 80.68952004021756,
    "Buyer Omar": 79.25193460991079,
    "Buyer Raj": 80.56203841944262,
    "Buyer Jun": 80.70971240607635,
    "Buyer Zoe": 79.31272555688898,
    "Buyer Tara": 80.58892494459975
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Leo": 96.25,
    "Seller Yara": 96.5,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Omar": 79.64991468488645,
    "Buyer Jun": 79.62982677351819,
    "Buyer Raj": 79.92479805963707,
    "Buyer Tara": 79.49537629299668,
    "Buyer Zoe": 80.47566034346582,
    "Buyer Ana": 80.40663245625004
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Leo": 96.25,
    "Seller Yara": 96.5,
    "Seller Amir": 97.0,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Raj": 79.66445491396803,
    "Buyer Jun": 80.7231322427767,
    "Buyer Tara": 80.2371244872998,
    "Buyer Omar": 79.60834578904367,
    "Buyer Zoe": 80.25065040913718,
    "Buyer Ana": 79.46795249175578
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Leo": 96.2,
    "Seller Yara": 96.5,
    "Seller Maya": 81.25,
    "Seller Amir": 97.0
  },
  "buyer_bids": {
    "Buyer Raj": 79.67118844335916,
    "Buyer Ana": 80.32420088436606,
    "Buyer Jun": 79.38270503310721,
    "Buyer Tara": 79.74934795404576,
    "Buyer Zoe": 79.69920788272091,
    "Buyer Omar": 79.99438984958853
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Yara": 96.5,
    "Seller Leo": 96.2,
    "Seller Maya": 81.25,
    "Seller Amir": 97.01
  },
  "buyer_bids": {
    "Buyer Jun": 80.36824356925626,
    "Buyer Omar": 79.6055330383756,
    "Buyer Ana": 79.61347333322479,
    "Buyer Raj": 80.47392481789636,
    "Buyer Zoe": 80.76278124104847,
    "Buyer Tara": 80.74490162856159
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Leo": 96.2,
    "Seller Yara": 96.5,
    "Seller Maya": 81.2,
    "Seller Amir": 97.01
  },
  "buyer_bids": {
    "Buyer Omar": 79.56059842130976,
    "Buyer Ana": 80.76088548923514,
    "Buyer Tara": 80.73582930755887,
    "Buyer Raj": 79.89064887543964,
    "Buyer Zoe": 79.25652167461914,
    "Buyer Jun": 79.83570459063603
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Yara": 96.5,
    "Seller Leo": 96.2,
    "Seller Maya": 81.25,
    "Seller Amir": 97.05
  },
  "buyer_bids": {
    "Buyer Raj": 79.91306962614782,
    "Buyer Jun": 80.53159184718848,
    "Buyer Omar": 79.88266404324415,
    "Buyer Ana": 80.01009490106316,
    "Buyer Tara": 80.20923493859543,
    "Buyer Zoe": 80.76316184968465
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Jin": 96.32,
    "Seller Leo": 96.2,
    "Seller Yara": 96.5,
    "Seller Maya": 81.25,
    "Seller Amir": 97.05
  },
  "buyer_bids": {
    "Buyer Raj": 80.31208142657995,
    "Buyer Omar": 80.03823270378717,
    "Buyer Ana": 79.92135204342837,
    "Buyer Jun": 79.24912044280646,
    "Buyer Zoe": 80.27984412402922,
    "Buyer Tara": 80.48541682149464
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Leo": 96.2,
    "Seller Jin": 96.32,
    "Seller Yara": 96.5,
    "Seller Amir": 97.05
  },
  "buyer_bids": {
    "Buyer Omar": 80.37992200015313,
    "Buyer Jun": 79.40109331569556,
    "Buyer Raj": 80.25571822680172,
    "Buyer Zoe": 79.53941070885102,
    "Buyer Ana": 79.88207900594217,
    "Buyer Tara": 79.27590427763923
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Leo": 96.2,
    "Seller Yara": 96.5,
    "Seller Maya": 81.25,
    "Seller Amir": 97.05
  },
  "buyer_bids": {
    "Buyer Ana": 79.32231384885745,
    "Buyer Raj": 79.31316300461906,
    "Buyer Jun": 79.67660768918803,
    "Buyer Zoe": 79.45313182373252,
    "Buyer Tara": 80.10390515628288,
    "Buyer Omar": 80.66748210119354
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Leo": 96.15,
    "Seller Maya": 81.25,
    "Seller Amir": 97.05,
    "Seller Yara": 96.38,
    "Seller Jin": 96.32
  },
  "buyer_bids": {
    "Buyer Raj": 79.40862580547905,
    "Buyer Zoe": 79.54814454272034,
    "Buyer Omar": 80.56084265754123,
    "Buyer Tara": 80.64130079233982,
    "Buyer Ana": 80.09714771364591,
    "Buyer Jun": 80.14493435405987
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Amir": 97.05,
    "Seller Yara": 96.38,
    "Seller Leo": 96.3,
    "Seller Jin": 96.32,
    "Seller Maya": 81.25
  },
  "buyer_bids": {
    "Buyer Tara": 79.25987740013562,
    "Buyer Omar": 80.59181828467578,
    "Buyer Zoe": 80.19674050222484,
    "Buyer Ana": 80.52466105065085,
    "Buyer Raj": 79.93736398424527,
    "Buyer Jun": 80.44802763109234
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Yara": 96.38,
    "Seller Maya": 81.25,
    "Seller Amir": 97.05,
    "Seller Jin": 96.33,
    "Seller Leo": 96.3
  },
  "buyer_bids": {
    "Buyer Omar": 80.1174123248357,
    "Buyer Zoe": 80.1462548994317,
    "Buyer Jun": 80.6345051936263,
    "Buyer Raj": 79.52065192874588,
    "Buyer Tara": 79.98776120071918,
    "Buyer Ana": 79.35844058043672
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
