
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 80.0,
    "Seller Tara": 80.09570188642384,
    "Seller Kai": 97.6,
    "Seller Mia": 80.0,
    "Seller Eli": 97.61
  },
  "buyer_bids": {
    "Buyer Max": 80.09570188642384,
    "Buyer Jin": 79.31798789380596,
    "Buyer Amir": 79.35802135145464,
    "Buyer Leo": 79.76606612723079,
    "Buyer Nia": 80.56075812201482,
    "Buyer Jun": 79.7283155497568
  },
  "trades": [
    {
      "round_number": 1,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.28
    },
    {
      "round_number": 1,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.05
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Eli": 97.19,
    "Seller Raj": 80.05,
    "Seller Tara": 80.1,
    "Seller Mia": 80.09570188642384
  },
  "buyer_bids": {
    "Buyer Amir": 79.5271643992258,
    "Buyer Leo": 80.66954383312105,
    "Buyer Jun": 80.034165814644,
    "Buyer Max": 79.29964734083447,
    "Buyer Nia": 79.90830937463414,
    "Buyer Jin": 80.08403788181555
  },
  "trades": [
    {
      "round_number": 2,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Kai": 80.0,
    "Seller Raj": 79.8,
    "Seller Tara": 80.1,
    "Seller Mia": 80.1
  },
  "buyer_bids": {
    "Buyer Max": 80.45607641539758,
    "Buyer Nia": 80.54414594648867,
    "Buyer Leo": 80.20042532683782,
    "Buyer Amir": 80.66559116857101,
    "Buyer Jin": 79.34923498296386,
    "Buyer Jun": 80.33640547781998
  },
  "trades": [
    {
      "round_number": 3,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 80.23
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.27
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.28
    },
    {
      "round_number": 3,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Tara",
      "price": 80.22
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Raj": 79.6,
    "Seller Tara": 80.1
  },
  "buyer_bids": {
    "Buyer Leo": 80.6672303505839,
    "Buyer Jun": 80.32582807386483,
    "Buyer Nia": 80.36844572216516,
    "Buyer Amir": 80.52490124544624,
    "Buyer Jin": 79.73301621966256,
    "Buyer Max": 79.30077483881792
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.13
    },
    {
      "round_number": 4,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Tara",
      "price": 80.31
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Raj": 79.6,
    "Seller Tara": 80.1
  },
  "buyer_bids": {
    "Buyer Jun": 80.06878393230402,
    "Buyer Max": 79.34594552612836,
    "Buyer Leo": 80.78915448570316,
    "Buyer Jin": 80.48535208663392,
    "Buyer Nia": 79.42799103025412,
    "Buyer Amir": 79.5547262339427
  },
  "trades": [
    {
      "round_number": 5,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.19
    },
    {
      "round_number": 5,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.29
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Raj": 79.4,
    "Seller Tara": 80.1,
    "Seller Kai": 80.03
  },
  "buyer_bids": {
    "Buyer Jin": 80.7967546097378,
    "Buyer Leo": 79.39969714340498,
    "Buyer Jun": 79.68231486739239,
    "Buyer Nia": 79.98285884987185,
    "Buyer Max": 79.6657450760193,
    "Buyer Amir": 80.60013965973783
  },
  "trades": [
    {
      "round_number": 6,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.1
    },
    {
      "round_number": 6,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Kai",
      "price": 80.32
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Tara": 80.1,
    "Seller Mia": 80.1,
    "Seller Kai": 80.03
  },
  "buyer_bids": {
    "Buyer Leo": 79.66025162273633,
    "Buyer Nia": 79.52512296395109,
    "Buyer Jin": 80.67559956956248,
    "Buyer Jun": 80.47908337835295,
    "Buyer Amir": 79.73240082042774,
    "Buyer Max": 80.07556817039986
  },
  "trades": [
    {
      "round_number": 7,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Kai",
      "price": 80.35
    },
    {
      "round_number": 7,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Mia",
      "price": 80.29
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Mia": 79.9,
    "Seller Raj": 79.75,
    "Seller Kai": 80.13
  },
  "buyer_bids": {
    "Buyer Nia": 80.51434754355823,
    "Buyer Max": 80.77007958479713,
    "Buyer Jin": 79.49418995606175,
    "Buyer Leo": 79.61608993383086,
    "Buyer Jun": 79.2527558638188,
    "Buyer Amir": 79.58737144816314
  },
  "trades": [
    {
      "round_number": 8,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.26
    },
    {
      "round_number": 8,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Mia",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Raj": 79.75,
    "Seller Kai": 80.18,
    "Seller Tara": 80.1
  },
  "buyer_bids": {
    "Buyer Max": 80.52697737861395,
    "Buyer Jin": 79.26182651331973,
    "Buyer Amir": 79.43928053287722,
    "Buyer Jun": 80.31891648677686,
    "Buyer Nia": 79.32839730856625,
    "Buyer Leo": 80.29359741677398
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.14
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Tara",
      "price": 80.21
    },
    {
      "round_number": 9,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Raj": 79.35,
    "Seller Tara": 80.1,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Max": 79.64033730567172,
    "Buyer Nia": 80.52042127787786,
    "Buyer Jun": 79.87107718681925,
    "Buyer Leo": 79.98824861836725,
    "Buyer Jin": 80.28715897309542,
    "Buyer Amir": 79.54432207220839
  },
  "trades": [
    {
      "round_number": 10,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 79.94
    },
    {
      "round_number": 10,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.19
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Mia": 80.1,
    "Seller Raj": 79.25,
    "Seller Tara": 80.15,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Leo": 79.50460615447801,
    "Buyer Max": 79.73643276506755,
    "Buyer Amir": 79.77178807356802,
    "Buyer Nia": 79.38455958946281,
    "Buyer Jun": 80.13931952274021,
    "Buyer Jin": 79.71891974941234
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 79.69
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Mia": 80.05,
    "Seller Raj": 79.6,
    "Seller Tara": 80.15,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Max": 80.45298961575457,
    "Buyer Jun": 79.29950792909393,
    "Buyer Jin": 79.47277083793325,
    "Buyer Nia": 79.88180981655017,
    "Buyer Amir": 79.79529630892972,
    "Buyer Leo": 80.56851619121636
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 80.08
    },
    {
      "round_number": 12,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Mia",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Raj": 79.6,
    "Seller Kai": 80.18,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Max": 80.16347277975784,
    "Buyer Jun": 80.69843154590366,
    "Buyer Amir": 79.55003769451659,
    "Buyer Nia": 80.21473026168366,
    "Buyer Jin": 80.5073924848302,
    "Buyer Leo": 79.31839503081676
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.15
    },
    {
      "round_number": 13,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.33
    },
    {
      "round_number": 13,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.2
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Mia": 80.26,
    "Seller Eli": 79.9,
    "Seller Raj": 79.6,
    "Seller Tara": 80.1,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Amir": 79.50163299568102,
    "Buyer Jun": 79.34645096504855,
    "Buyer Nia": 79.39151275624286,
    "Buyer Jin": 80.52813780994359,
    "Buyer Leo": 79.38567382140627,
    "Buyer Max": 80.53415108895918
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.07
    },
    {
      "round_number": 14,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Eli",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Mia": 80.26,
    "Seller Raj": 79.6,
    "Seller Eli": 80.0,
    "Seller Tara": 80.15,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Max": 79.96677384627553,
    "Buyer Jin": 79.51134552909173,
    "Buyer Amir": 80.16880667235418,
    "Buyer Jun": 80.34898132233495,
    "Buyer Nia": 80.75310706120696,
    "Buyer Leo": 80.36344836712773
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.18
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.18
    },
    {
      "round_number": 15,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Tara",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Mia": 80.26,
    "Seller Eli": 80.2,
    "Seller Kai": 80.18,
    "Seller Raj": 79.55,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Jin": 80.28695551184157,
    "Buyer Leo": 79.31200688148533,
    "Buyer Max": 80.53744424891377,
    "Buyer Amir": 79.29773583337033,
    "Buyer Jun": 80.19295995356441,
    "Buyer Nia": 80.07077665836357
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.04
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.22
    },
    {
      "round_number": 16,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.19
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Mia": 80.26,
    "Seller Eli": 80.2,
    "Seller Tara": 80.14,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Nia": 79.89770983672521,
    "Buyer Leo": 80.15437587619927,
    "Buyer Max": 79.94740996407722,
    "Buyer Jun": 79.2976679027514,
    "Buyer Amir": 79.31515470322282,
    "Buyer Jin": 79.68169845760218
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.15
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Mia": 80.26,
    "Seller Eli": 80.2,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Jin": 79.82604191540904,
    "Buyer Leo": 80.64368677042106,
    "Buyer Nia": 79.61621320675081,
    "Buyer Max": 79.95234585807712,
    "Buyer Jun": 80.64703781284807,
    "Buyer Amir": 80.31891700015349
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Tara",
      "price": 80.4
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Eli",
      "price": 80.42
    },
    {
      "round_number": 18,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Mia",
      "price": 80.29
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Mia": 80.26,
    "Seller Raj": 79.55,
    "Seller Tara": 80.15
  },
  "buyer_bids": {
    "Buyer Leo": 79.45313380772382,
    "Buyer Max": 80.46183726401568,
    "Buyer Nia": 79.52546349723994,
    "Buyer Jin": 80.3163153132515,
    "Buyer Amir": 80.11162966691762,
    "Buyer Jun": 80.42775734732211
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.01
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Tara",
      "price": 80.29
    },
    {
      "round_number": 19,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Mia",
      "price": 80.29
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Mia": 80.26,
    "Seller Raj": 79.45313380772382,
    "Seller Tara": 80.15,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Nia": 79.38754055019368,
    "Buyer Amir": 79.45912651231662,
    "Buyer Jin": 80.04715875686034,
    "Buyer Jun": 80.67426943114178,
    "Buyer Max": 80.2649693152287,
    "Buyer Leo": 79.22112601365596
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.06
    },
    {
      "round_number": 20,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Tara",
      "price": 80.21
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Eli": 80.42,
    "Seller Raj": 79.45,
    "Seller Tara": 80.15,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Amir": 80.29004908096678,
    "Buyer Nia": 80.59968751083136,
    "Buyer Jun": 80.66801779641445,
    "Buyer Jin": 80.64015688382523,
    "Buyer Leo": 79.82182758853031,
    "Buyer Max": 80.23829358049811
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.06
    },
    {
      "round_number": 21,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.4
    },
    {
      "round_number": 21,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Kai",
      "price": 80.39
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Eli": 80.42,
    "Seller Tara": 80.15,
    "Seller Raj": 79.45,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Amir": 80.25218591989199,
    "Buyer Leo": 80.38242578560943,
    "Buyer Jun": 79.9327267258355,
    "Buyer Jin": 79.44546043349028,
    "Buyer Nia": 80.30531641259714,
    "Buyer Max": 79.32651806278129
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Raj",
      "price": 79.92
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Tara",
      "price": 80.23
    },
    {
      "round_number": 22,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Kai",
      "price": 80.22
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Eli": 80.42,
    "Seller Tara": 80.2,
    "Seller Raj": 79.45
  },
  "buyer_bids": {
    "Buyer Nia": 80.41946664992724,
    "Buyer Jin": 79.4157401709572,
    "Buyer Amir": 80.07091119624236,
    "Buyer Max": 80.17621704683158,
    "Buyer Jun": 79.97092333259852,
    "Buyer Leo": 80.27744553517343
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 79.93
    },
    {
      "round_number": 23,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Tara",
      "price": 80.24
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Raj": 79.45
  },
  "buyer_bids": {
    "Buyer Amir": 80.14444429811127,
    "Buyer Jun": 79.41175084967159,
    "Buyer Max": 79.69647613034269,
    "Buyer Leo": 80.39757740991615,
    "Buyer Jin": 80.62710966627296,
    "Buyer Nia": 80.56603900934549
  },
  "trades": [
    {
      "round_number": 24,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 80.04
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Raj": 79.45,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Nia": 80.15132308235538,
    "Buyer Jun": 80.31773230236055,
    "Buyer Leo": 79.55695651337385,
    "Buyer Amir": 80.52624443353216,
    "Buyer Jin": 79.32915697099595,
    "Buyer Max": 79.45612764643927
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Amir",
      "seller_id": "Seller Raj",
      "price": 79.99
    },
    {
      "round_number": 25,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Raj": 79.45
  },
  "buyer_bids": {
    "Buyer Nia": 80.2780403204936,
    "Buyer Leo": 80.5947011077622,
    "Buyer Jun": 80.59926023977286,
    "Buyer Jin": 80.33655996174124,
    "Buyer Max": 79.25047276499589,
    "Buyer Amir": 79.91701652262984
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Raj",
      "price": 80.02
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Tara": 80.17,
    "Seller Raj": 79.45,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Nia": 80.33440965469813,
    "Buyer Jin": 80.4354971487784,
    "Buyer Amir": 80.10795574686797,
    "Buyer Leo": 80.32242586800679,
    "Buyer Jun": 79.46507995659533,
    "Buyer Max": 79.30221809457811
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Raj",
      "price": 79.94
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Tara",
      "price": 80.25
    },
    {
      "round_number": 27,
      "buyer_id": "Buyer Leo",
      "seller_id": "Seller Kai",
      "price": 80.25
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Tara": 80.15,
    "Seller Eli": 80.5,
    "Seller Raj": 79.45
  },
  "buyer_bids": {
    "Buyer Jun": 80.16636382049899,
    "Buyer Nia": 80.65286377145534,
    "Buyer Max": 79.20011066059917,
    "Buyer Jin": 80.61591281279641,
    "Buyer Amir": 79.91418353948085,
    "Buyer Leo": 79.26225629442433
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.05
    },
    {
      "round_number": 28,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Eli": 80.55,
    "Seller Tara": 80.17,
    "Seller Raj": 79.45,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Jun": 80.51635187715311,
    "Buyer Nia": 79.27977119456584,
    "Buyer Jin": 80.54037894567124,
    "Buyer Amir": 79.72151024713585,
    "Buyer Max": 80.75868301167984,
    "Buyer Leo": 79.86421985850336
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Max",
      "seller_id": "Seller Raj",
      "price": 80.1
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.36
    },
    {
      "round_number": 29,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Eli": 80.7,
    "Seller Tara": 80.17,
    "Seller Raj": 79.45,
    "Seller Kai": 80.18
  },
  "buyer_bids": {
    "Buyer Nia": 80.76571480135283,
    "Buyer Amir": 80.07769930362011,
    "Buyer Leo": 79.22356685879012,
    "Buyer Jin": 80.74086043397294,
    "Buyer Max": 79.4088348029473,
    "Buyer Jun": 80.53991742999023
  },
  "trades": [
    {
      "round_number": 30,
      "buyer_id": "Buyer Nia",
      "seller_id": "Seller Raj",
      "price": 80.11
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Jin",
      "seller_id": "Seller Tara",
      "price": 80.46
    },
    {
      "round_number": 30,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Kai",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
