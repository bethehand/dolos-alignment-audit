
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Maya": 97.29,
    "Seller Amir": 97.01,
    "Seller Yara": 97.01,
    "Seller Leo": 96.25,
    "Seller Jin": 82.0
  },
  "buyer_bids": {
    "Buyer Raj": 80.14584549600208,
    "Buyer Ana": 79.36356345297608,
    "Buyer Omar": 79.70788741148222,
    "Buyer Jun": 79.23571537763411,
    "Buyer Tara": 79.21472790168701,
    "Buyer Zoe": 80.23927381684081
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Leo": 96.26,
    "Seller Yara": 96.5,
    "Seller Jin": 82.0,
    "Seller Amir": 97.5,
    "Seller Maya": 97.29
  },
  "buyer_bids": {
    "Buyer Tara": 80.42192159221038,
    "Buyer Raj": 80.60997417427545,
    "Buyer Omar": 80.75046504047054,
    "Buyer Zoe": 80.04420706297984,
    "Buyer Ana": 80.29837416668653,
    "Buyer Jun": 80.36136416231443
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Amir": 97.65,
    "Seller Yara": 96.5,
    "Seller Jin": 82.0,
    "Seller Leo": 96.26
  },
  "buyer_bids": {
    "Buyer Jun": 80.28295766375996,
    "Buyer Ana": 80.08457532206874,
    "Buyer Tara": 80.72359112846591,
    "Buyer Raj": 80.70266723031773,
    "Buyer Zoe": 80.4175163800669,
    "Buyer Omar": 79.753120663534
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Amir": 97.45,
    "Seller Leo": 96.26,
    "Seller Yara": 80.07,
    "Seller Jin": 82.0
  },
  "buyer_bids": {
    "Buyer Zoe": 79.36000043375381,
    "Buyer Ana": 79.86588790223095,
    "Buyer Tara": 80.20696464768105,
    "Buyer Jun": 80.67550169995181,
    "Buyer Raj": 80.68241059805737,
    "Buyer Omar": 80.66603173680846
  },
  "trades": [
    {
      "round_number": 4,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.38
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Leo": 96.26,
    "Seller Jin": 82.0,
    "Seller Maya": 97.29
  },
  "buyer_bids": {
    "Buyer Tara": 80.74753643777498,
    "Buyer Jun": 80.7572036112689,
    "Buyer Omar": 80.63292063142639,
    "Buyer Zoe": 80.00127952023078,
    "Buyer Ana": 80.389034656676,
    "Buyer Raj": 79.67422462845909
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Amir": 97.7,
    "Seller Maya": 97.29,
    "Seller Leo": 96.26,
    "Seller Yara": 96.5
  },
  "buyer_bids": {
    "Buyer Omar": 79.65465498671031,
    "Buyer Ana": 79.50375956658564,
    "Buyer Zoe": 79.9989792924666,
    "Buyer Tara": 80.70546156770328,
    "Buyer Jun": 80.75752224782084,
    "Buyer Raj": 80.65629609430201
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Amir": 89.0,
    "Seller Jin": 82.0,
    "Seller Leo": 96.26,
    "Seller Maya": 97.29,
    "Seller Yara": 96.1
  },
  "buyer_bids": {
    "Buyer Zoe": 79.84686095016377,
    "Buyer Jun": 80.38996904846911,
    "Buyer Ana": 80.56526072066458,
    "Buyer Raj": 79.82936579691174,
    "Buyer Omar": 79.96836315682816,
    "Buyer Tara": 80.26358963457355
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Jin": 82.0,
    "Seller Maya": 97.29,
    "Seller Leo": 96.26,
    "Seller Amir": 89.0,
    "Seller Yara": 96.25
  },
  "buyer_bids": {
    "Buyer Jun": 79.3383481435652,
    "Buyer Omar": 80.38114474266413,
    "Buyer Zoe": 80.26201248775037,
    "Buyer Raj": 80.61237123850633,
    "Buyer Tara": 79.37269001935056,
    "Buyer Ana": 80.44134023993594
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Leo": 96.26,
    "Seller Maya": 97.29,
    "Seller Amir": 89.0,
    "Seller Jin": 82.0,
    "Seller Yara": 80.07
  },
  "buyer_bids": {
    "Buyer Zoe": 79.95091222576484,
    "Buyer Ana": 80.54392246476716,
    "Buyer Tara": 79.69364708308437,
    "Buyer Jun": 80.37242529427499,
    "Buyer Raj": 79.46191727543996,
    "Buyer Omar": 79.79283626663319
  },
  "trades": [
    {
      "round_number": 9,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.31
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Amir": 97.8,
    "Seller Leo": 96.26,
    "Seller Maya": 97.34,
    "Seller Jin": 82.0,
    "Seller Yara": 96.1
  },
  "buyer_bids": {
    "Buyer Tara": 79.563099753643,
    "Buyer Ana": 80.18369714728813,
    "Buyer Jun": 80.23544986451088,
    "Buyer Raj": 80.5572825191401,
    "Buyer Zoe": 79.46975087526128,
    "Buyer Omar": 80.1250814484787
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Amir": 98.0,
    "Seller Jin": 82.0,
    "Seller Maya": 97.34,
    "Seller Leo": 96.27,
    "Seller Yara": 80.25
  },
  "buyer_bids": {
    "Buyer Jun": 80.07734154739589,
    "Buyer Raj": 79.21968253577379,
    "Buyer Tara": 79.7501214260157,
    "Buyer Ana": 79.51922618793985,
    "Buyer Omar": 80.67213829589235,
    "Buyer Zoe": 79.84712778942313
  },
  "trades": [
    {
      "round_number": 11,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.46
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Amir": 98.0,
    "Seller Maya": 97.29,
    "Seller Jin": 81.95,
    "Seller Yara": 80.25,
    "Seller Leo": 96.28
  },
  "buyer_bids": {
    "Buyer Ana": 80.25474370179171,
    "Buyer Omar": 80.1743117208137,
    "Buyer Zoe": 79.81390341262406,
    "Buyer Jun": 80.36704028851639,
    "Buyer Raj": 80.65560802542305,
    "Buyer Tara": 80.5711186029969
  },
  "trades": [
    {
      "round_number": 12,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.45
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Yara": 80.25,
    "Seller Amir": 97.9,
    "Seller Maya": 97.34,
    "Seller Leo": 96.29,
    "Seller Jin": 82.0
  },
  "buyer_bids": {
    "Buyer Tara": 79.52877641232122,
    "Buyer Ana": 80.70153472114211,
    "Buyer Zoe": 80.44383549167344,
    "Buyer Jun": 79.4067990841708,
    "Buyer Raj": 80.72743408544278,
    "Buyer Omar": 80.01999989520478
  },
  "trades": [
    {
      "round_number": 13,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.49
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Yara": 80.24,
    "Seller Jin": 81.95,
    "Seller Maya": 97.34,
    "Seller Leo": 96.29,
    "Seller Amir": 97.8
  },
  "buyer_bids": {
    "Buyer Tara": 80.50136241146076,
    "Buyer Jun": 80.70562161808873,
    "Buyer Raj": 79.96976290786279,
    "Buyer Omar": 80.08704190492439,
    "Buyer Zoe": 79.86144006830364,
    "Buyer Ana": 79.78357767546176
  },
  "trades": [
    {
      "round_number": 14,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Yara": 80.24,
    "Seller Jin": 81.95,
    "Seller Amir": 97.9,
    "Seller Maya": 97.34,
    "Seller Leo": 96.29
  },
  "buyer_bids": {
    "Buyer Zoe": 80.15976829562157,
    "Buyer Omar": 80.45831101670805,
    "Buyer Jun": 79.72981992314037,
    "Buyer Raj": 79.20253559992884,
    "Buyer Tara": 80.48731117522246,
    "Buyer Ana": 80.06417529134141
  },
  "trades": [
    {
      "round_number": 15,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Yara": 80.24,
    "Seller Leo": 96.28,
    "Seller Jin": 81.95,
    "Seller Maya": 97.34,
    "Seller Amir": 97.65
  },
  "buyer_bids": {
    "Buyer Tara": 80.56203841944262,
    "Buyer Ana": 80.08121002417161,
    "Buyer Jun": 79.34656225202608,
    "Buyer Raj": 80.21659374448312,
    "Buyer Zoe": 80.08164661880848,
    "Buyer Omar": 79.48925438953648
  },
  "trades": [
    {
      "round_number": 16,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.4
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Yara": 80.24,
    "Seller Jin": 81.95,
    "Seller Maya": 97.34,
    "Seller Amir": 97.7,
    "Seller Leo": 96.3
  },
  "buyer_bids": {
    "Buyer Omar": 79.31272555688898,
    "Buyer Tara": 80.40663245625004,
    "Buyer Zoe": 79.92479805963707,
    "Buyer Jun": 80.58892494459975,
    "Buyer Raj": 79.25193460991079,
    "Buyer Ana": 80.70971240607635
  },
  "trades": [
    {
      "round_number": 17,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Yara": 80.24,
    "Seller Leo": 96.3
  },
  "buyer_bids": {
    "Buyer Jun": 79.49537629299668,
    "Buyer Ana": 79.62982677351819,
    "Buyer Omar": 80.47566034346582,
    "Buyer Tara": 79.46795249175578,
    "Buyer Zoe": 79.66445491396803,
    "Buyer Raj": 79.64991468488645
  },
  "trades": [
    {
      "round_number": 18,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.36
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Yara": 80.24,
    "Seller Jin": 81.95,
    "Seller Amir": 97.5,
    "Seller Leo": 96.3
  },
  "buyer_bids": {
    "Buyer Zoe": 80.32420088436606,
    "Buyer Raj": 80.7231322427767,
    "Buyer Jun": 79.67118844335916,
    "Buyer Ana": 80.25065040913718,
    "Buyer Tara": 79.99438984958853,
    "Buyer Omar": 80.2371244872998
  },
  "trades": [
    {
      "round_number": 19,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.48
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Jin": 82.0,
    "Seller Maya": 97.29,
    "Seller Leo": 96.29,
    "Seller Yara": 80.23,
    "Seller Amir": 97.7
  },
  "buyer_bids": {
    "Buyer Jun": 80.47392481789636,
    "Buyer Raj": 79.38270503310721,
    "Buyer Tara": 79.6055330383756,
    "Buyer Zoe": 79.61347333322479,
    "Buyer Ana": 79.69920788272091,
    "Buyer Omar": 79.74934795404576
  },
  "trades": [
    {
      "round_number": 20,
      "buyer_id": "Buyer Jun",
      "seller_id": "Seller Yara",
      "price": 80.35
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Yara": 80.24,
    "Seller Jin": 82.05,
    "Seller Maya": 97.29,
    "Seller Amir": 97.5,
    "Seller Leo": 96.3
  },
  "buyer_bids": {
    "Buyer Raj": 80.76278124104847,
    "Buyer Omar": 79.89064887543964,
    "Buyer Tara": 79.83570459063603,
    "Buyer Ana": 80.74490162856159,
    "Buyer Zoe": 79.56059842130976,
    "Buyer Jun": 80.76088548923514
  },
  "trades": [
    {
      "round_number": 21,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.5
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Jin": 82.05,
    "Seller Yara": 80.2,
    "Seller Maya": 97.29,
    "Seller Leo": 96.3
  },
  "buyer_bids": {
    "Buyer Raj": 79.25652167461914,
    "Buyer Jun": 80.01009490106316,
    "Buyer Tara": 80.53159184718848,
    "Buyer Omar": 79.91306962614782,
    "Buyer Zoe": 79.88266404324415,
    "Buyer Ana": 80.73582930755887
  },
  "trades": [
    {
      "round_number": 22,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.47
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Jin": 82.05,
    "Seller Yara": 80.15,
    "Seller Maya": 97.29,
    "Seller Amir": 97.0,
    "Seller Leo": 96.32
  },
  "buyer_bids": {
    "Buyer Raj": 80.76316184968465,
    "Buyer Ana": 80.20923493859543,
    "Buyer Omar": 80.31208142657995,
    "Buyer Jun": 79.92135204342837,
    "Buyer Tara": 79.24912044280646,
    "Buyer Zoe": 80.03823270378717
  },
  "trades": [
    {
      "round_number": 23,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.46
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Maya": 97.29,
    "Seller Amir": 97.5,
    "Seller Jin": 81.95
  },
  "buyer_bids": {
    "Buyer Ana": 80.48541682149464,
    "Buyer Zoe": 80.37992200015313,
    "Buyer Raj": 80.27984412402922,
    "Buyer Omar": 80.25571822680172,
    "Buyer Tara": 79.40109331569556,
    "Buyer Jun": 79.88207900594217
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Jin": 81.95,
    "Seller Amir": 97.3,
    "Seller Maya": 97.29,
    "Seller Yara": 80.25
  },
  "buyer_bids": {
    "Buyer Tara": 80.09714771364591,
    "Buyer Raj": 80.66748210119354,
    "Buyer Omar": 79.45313182373252,
    "Buyer Jun": 80.10390515628288,
    "Buyer Ana": 79.67660768918803,
    "Buyer Zoe": 79.40862580547905
  },
  "trades": [
    {
      "round_number": 25,
      "buyer_id": "Buyer Raj",
      "seller_id": "Seller Yara",
      "price": 80.46
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Yara": 80.25,
    "Seller Jin": 81.95,
    "Seller Amir": 97.29,
    "Seller Maya": 97.28,
    "Seller Leo": 96.3
  },
  "buyer_bids": {
    "Buyer Omar": 79.93736398424527,
    "Buyer Tara": 80.44802763109234,
    "Buyer Ana": 80.64130079233982,
    "Buyer Zoe": 80.59181828467578,
    "Buyer Jun": 80.52466105065085,
    "Buyer Raj": 79.54814454272034
  },
  "trades": [
    {
      "round_number": 26,
      "buyer_id": "Buyer Ana",
      "seller_id": "Seller Yara",
      "price": 80.45
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Jin": 82.05,
    "Seller Yara": 80.25,
    "Seller Maya": 97.27,
    "Seller Amir": 97.65,
    "Seller Leo": 96.3
  },
  "buyer_bids": {
    "Buyer Raj": 80.19674050222484,
    "Buyer Jun": 79.35844058043672,
    "Buyer Tara": 80.6345051936263,
    "Buyer Zoe": 80.1174123248357,
    "Buyer Omar": 79.52065192874588,
    "Buyer Ana": 79.25987740013562
  },
  "trades": [
    {
      "round_number": 27,
      "buyer_id": "Buyer Tara",
      "seller_id": "Seller Yara",
      "price": 80.44
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Yara": 80.25,
    "Seller Maya": 97.26,
    "Seller Leo": 96.31
  },
  "buyer_bids": {
    "Buyer Omar": 80.70072624285172,
    "Buyer Jun": 79.8240968620309,
    "Buyer Zoe": 80.00657178759337,
    "Buyer Raj": 80.1462548994317,
    "Buyer Ana": 79.98776120071918,
    "Buyer Tara": 79.22752031475717
  },
  "trades": [
    {
      "round_number": 28,
      "buyer_id": "Buyer Omar",
      "seller_id": "Seller Yara",
      "price": 80.48
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Yara": 80.25,
    "Seller Jin": 82.05,
    "Seller Leo": 96.29,
    "Seller Maya": 97.23
  },
  "buyer_bids": {
    "Buyer Omar": 79.65016274473778,
    "Buyer Ana": 79.84371954083059,
    "Buyer Zoe": 80.57205878886867,
    "Buyer Jun": 79.45114447117868,
    "Buyer Tara": 80.49782249912083,
    "Buyer Raj": 80.17940537776497
  },
  "trades": [
    {
      "round_number": 29,
      "buyer_id": "Buyer Zoe",
      "seller_id": "Seller Yara",
      "price": 80.41
    }
  ],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Maya": 97.21,
    "Seller Jin": 82.05,
    "Seller Amir": 84.0,
    "Seller Leo": 96.3,
    "Seller Yara": 80.25
  },
  "buyer_bids": {
    "Buyer Zoe": 79.35424816414954,
    "Buyer Jun": 79.62645672171658,
    "Buyer Tara": 79.80677393594011,
    "Buyer Ana": 79.41622902559156,
    "Buyer Omar": 79.8867846633557,
    "Buyer Raj": 80.10134485700965
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
