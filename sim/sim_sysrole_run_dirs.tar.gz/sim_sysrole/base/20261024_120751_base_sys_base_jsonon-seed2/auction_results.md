
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {
    "Seller Raj": 97.34,
    "Seller Amir": 97.34,
    "Seller Yara": 97.34
  },
  "buyer_bids": {
    "Buyer Omar": 80.59365274938875,
    "Buyer Mia": 80.65240017628687,
    "Buyer Kit": 80.6909544863518,
    "Buyer Nia": 80.64193247599512,
    "Buyer Ana": 79.78242308455579,
    "Buyer Lena": 79.87777755131471
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Eli": 96.99,
    "Seller Maya": 98.0,
    "Seller Raj": 97.39
  },
  "buyer_bids": {
    "Buyer Kit": 79.56896427898238,
    "Buyer Lena": 79.47774200602409,
    "Buyer Mia": 79.48275196939878,
    "Buyer Nia": 80.61450330645742,
    "Buyer Ana": 79.48389829678683,
    "Buyer Omar": 79.46318147850646
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Eli": 96.69,
    "Seller Maya": 98.0,
    "Seller Raj": 97.36,
    "Seller Yara": 97.5,
    "Seller Amir": 97.35
  },
  "buyer_bids": {
    "Buyer Lena": 79.91302017923307,
    "Buyer Kit": 80.09582450606636,
    "Buyer Nia": 80.01626670968798,
    "Buyer Omar": 79.77550624607424,
    "Buyer Ana": 80.02197984068965,
    "Buyer Mia": 80.79228427283253
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 4
````json
{
  "round_number": 4,
  "seller_asks": {
    "Seller Eli": 96.68,
    "Seller Yara": 97.51,
    "Seller Maya": 98.0,
    "Seller Amir": 97.37,
    "Seller Raj": 80.7924
  },
  "buyer_bids": {
    "Buyer Mia": 80.14957689468608,
    "Buyer Lena": 79.77901821113797,
    "Buyer Omar": 80.04058514722102,
    "Buyer Ana": 80.65356492713553,
    "Buyer Nia": 79.86347359102251,
    "Buyer Kit": 79.78280883776841
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 5
````json
{
  "round_number": 5,
  "seller_asks": {
    "Seller Maya": 98.0,
    "Seller Amir": 97.36,
    "Seller Raj": 80.7924,
    "Seller Eli": 96.69
  },
  "buyer_bids": {
    "Buyer Ana": 80.72789299194818,
    "Buyer Mia": 80.38174435450323,
    "Buyer Kit": 79.83978159088076,
    "Buyer Omar": 79.9132303376339,
    "Buyer Lena": 80.2478575650496,
    "Buyer Nia": 80.57434691145302
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 6
````json
{
  "round_number": 6,
  "seller_asks": {
    "Seller Yara": 97.35,
    "Seller Raj": 97.36,
    "Seller Maya": 98.0,
    "Seller Eli": 96.69
  },
  "buyer_bids": {
    "Buyer Ana": 79.99690468908358,
    "Buyer Kit": 80.02462752856641,
    "Buyer Mia": 80.47394599144368,
    "Buyer Nia": 79.59984282839315,
    "Buyer Lena": 80.25869696000638,
    "Buyer Omar": 79.64656358867684
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 7
````json
{
  "round_number": 7,
  "seller_asks": {
    "Seller Maya": 98.0,
    "Seller Raj": 97.36,
    "Seller Amir": 97.37,
    "Seller Eli": 96.69
  },
  "buyer_bids": {
    "Buyer Omar": 80.64508264614359,
    "Buyer Ana": 79.76123969039566,
    "Buyer Kit": 80.36141632700361,
    "Buyer Lena": 79.93048178537617,
    "Buyer Nia": 79.92750205874086,
    "Buyer Mia": 80.09213256506649
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 8
````json
{
  "round_number": 8,
  "seller_asks": {
    "Seller Maya": 98.0,
    "Seller Raj": 97.36,
    "Seller Eli": 96.71,
    "Seller Amir": 97.37,
    "Seller Yara": 97.35
  },
  "buyer_bids": {
    "Buyer Nia": 80.25421648289932,
    "Buyer Lena": 80.18615372500584,
    "Buyer Omar": 80.70495442539057,
    "Buyer Mia": 80.6027138818257,
    "Buyer Ana": 80.50349385380235,
    "Buyer Kit": 80.5360422392615
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 9
````json
{
  "round_number": 9,
  "seller_asks": {
    "Seller Maya": 98.0,
    "Seller Raj": 97.36,
    "Seller Amir": 97.36,
    "Seller Eli": 96.72,
    "Seller Yara": 97.36
  },
  "buyer_bids": {
    "Buyer Lena": 80.09950192591843,
    "Buyer Mia": 80.5297085464507,
    "Buyer Nia": 80.43677449120734,
    "Buyer Omar": 79.96762583624796,
    "Buyer Kit": 80.47881420500524,
    "Buyer Ana": 79.68527479120924
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 10
````json
{
  "round_number": 10,
  "seller_asks": {
    "Seller Raj": 97.37,
    "Seller Maya": 98.0,
    "Seller Amir": 97.37,
    "Seller Yara": 97.37,
    "Seller Eli": 96.75
  },
  "buyer_bids": {
    "Buyer Ana": 79.85067284478956,
    "Buyer Omar": 80.18529314503604,
    "Buyer Kit": 80.36948780069136,
    "Buyer Nia": 80.01177070917386,
    "Buyer Mia": 79.98225032701363,
    "Buyer Lena": 79.78655719678586
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 11
````json
{
  "round_number": 11,
  "seller_asks": {
    "Seller Maya": 98.0,
    "Seller Raj": 97.37,
    "Seller Amir": 97.375,
    "Seller Yara": 97.38,
    "Seller Eli": 96.77
  },
  "buyer_bids": {
    "Buyer Mia": 79.21347491631094,
    "Buyer Lena": 80.50409517516378,
    "Buyer Kit": 79.74633427531658,
    "Buyer Nia": 80.29477091578562,
    "Buyer Omar": 80.611311269705,
    "Buyer Ana": 80.45484776282788
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 12
````json
{
  "round_number": 12,
  "seller_asks": {
    "Seller Yara": 97.39,
    "Seller Amir": 97.38,
    "Seller Maya": 98.0,
    "Seller Eli": 96.78,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Kit": 79.27825620499968,
    "Buyer Lena": 80.29196426720013,
    "Buyer Mia": 80.14672050746222,
    "Buyer Nia": 80.7953097551439,
    "Buyer Omar": 79.3698510773034,
    "Buyer Ana": 80.11906393352639
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 13
````json
{
  "round_number": 13,
  "seller_asks": {
    "Seller Amir": 97.39,
    "Seller Raj": 97.39,
    "Seller Eli": 96.8,
    "Seller Maya": 98.0,
    "Seller Yara": 97.4
  },
  "buyer_bids": {
    "Buyer Omar": 80.40699165490105,
    "Buyer Nia": 80.66534553892929,
    "Buyer Kit": 79.62534592443505,
    "Buyer Mia": 80.51959601891612,
    "Buyer Ana": 79.41839983289174,
    "Buyer Lena": 80.70972953892448
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 14
````json
{
  "round_number": 14,
  "seller_asks": {
    "Seller Yara": 97.41,
    "Seller Amir": 97.38,
    "Seller Maya": 98.0,
    "Seller Raj": 97.4,
    "Seller Eli": 96.82
  },
  "buyer_bids": {
    "Buyer Kit": 79.29087425902316,
    "Buyer Omar": 80.63674859663202,
    "Buyer Nia": 79.29661571291587,
    "Buyer Mia": 79.77634957041599,
    "Buyer Lena": 79.59920271244962,
    "Buyer Ana": 80.41505451240388
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 15
````json
{
  "round_number": 15,
  "seller_asks": {
    "Seller Amir": 97.37,
    "Seller Yara": 97.39,
    "Seller Maya": 98.0,
    "Seller Raj": 97.4
  },
  "buyer_bids": {
    "Buyer Ana": 79.3079465392273,
    "Buyer Nia": 79.23750829795483,
    "Buyer Omar": 79.38435692733005,
    "Buyer Kit": 79.26539932166843,
    "Buyer Lena": 79.79695564813244,
    "Buyer Mia": 80.6698080542224
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 16
````json
{
  "round_number": 16,
  "seller_asks": {
    "Seller Amir": 97.36,
    "Seller Yara": 97.36,
    "Seller Maya": 98.0,
    "Seller Raj": 97.4,
    "Seller Eli": 96.82
  },
  "buyer_bids": {
    "Buyer Ana": 80.14313318780852,
    "Buyer Omar": 79.20309800369222,
    "Buyer Mia": 79.59652320327068,
    "Buyer Nia": 80.03694625725144,
    "Buyer Kit": 80.47065267550947,
    "Buyer Lena": 80.75330760522209
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 17
````json
{
  "round_number": 17,
  "seller_asks": {
    "Seller Amir": 97.37,
    "Seller Maya": 98.0,
    "Seller Eli": 96.82,
    "Seller Raj": 97.4
  },
  "buyer_bids": {
    "Buyer Nia": 79.20671377592326,
    "Buyer Kit": 80.39628543988604,
    "Buyer Omar": 80.70154242056894,
    "Buyer Mia": 79.65764261886136,
    "Buyer Ana": 80.20441003730845,
    "Buyer Lena": 79.98201763666643
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 18
````json
{
  "round_number": 18,
  "seller_asks": {
    "Seller Yara": 97.36,
    "Seller Eli": 96.83,
    "Seller Maya": 98.0,
    "Seller Raj": 97.4
  },
  "buyer_bids": {
    "Buyer Omar": 80.08240532596075,
    "Buyer Kit": 79.27323593976521,
    "Buyer Mia": 79.62230748838975,
    "Buyer Ana": 80.16824948477682,
    "Buyer Nia": 79.69341698227707,
    "Buyer Lena": 79.84296637609536
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 19
````json
{
  "round_number": 19,
  "seller_asks": {
    "Seller Eli": 96.84,
    "Seller Yara": 97.36,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Nia": 80.19455220348055,
    "Buyer Kit": 79.34952584100758,
    "Buyer Ana": 80.73405447275076,
    "Buyer Lena": 80.54144228818474,
    "Buyer Mia": 80.29983272929556,
    "Buyer Omar": 79.44552889433837
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 20
````json
{
  "round_number": 20,
  "seller_asks": {
    "Seller Yara": 97.36,
    "Seller Eli": 96.84,
    "Seller Amir": 97.37,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Nia": 79.23872612056519,
    "Buyer Mia": 80.4496954011077,
    "Buyer Omar": 80.46145493834928,
    "Buyer Lena": 79.97907477038864,
    "Buyer Ana": 80.7169507876341,
    "Buyer Kit": 80.0292577694053
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 21
````json
{
  "round_number": 21,
  "seller_asks": {
    "Seller Yara": 97.36,
    "Seller Amir": 97.38,
    "Seller Eli": 96.84,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Kit": 79.6189398360977,
    "Buyer Ana": 79.74568165849563,
    "Buyer Mia": 80.75309378409095,
    "Buyer Nia": 79.7247373002032,
    "Buyer Omar": 80.59910923194565,
    "Buyer Lena": 80.24530340454618
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 22
````json
{
  "round_number": 22,
  "seller_asks": {
    "Seller Yara": 97.36,
    "Seller Eli": 96.86,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Nia": 80.3191580958122,
    "Buyer Lena": 79.47313722486344,
    "Buyer Omar": 80.73439992833815,
    "Buyer Kit": 79.60474706928201,
    "Buyer Ana": 80.27289806672073,
    "Buyer Mia": 79.41072306825119
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 23
````json
{
  "round_number": 23,
  "seller_asks": {
    "Seller Yara": 97.36,
    "Seller Eli": 96.87,
    "Seller Amir": 97.39,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Mia": 79.25024213784367,
    "Buyer Nia": 79.92542386812062,
    "Buyer Omar": 79.57064811597179,
    "Buyer Kit": 80.33294960181868,
    "Buyer Ana": 80.66623674611408,
    "Buyer Lena": 79.59481687822907
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 24
````json
{
  "round_number": 24,
  "seller_asks": {
    "Seller Amir": 97.39,
    "Seller Yara": 97.36,
    "Seller Eli": 96.87,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Kit": 79.5651251509686,
    "Buyer Mia": 80.46653373003254,
    "Buyer Omar": 79.3176762610767,
    "Buyer Lena": 80.19825517784952,
    "Buyer Nia": 80.3421879582965,
    "Buyer Ana": 79.32868674506233
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 25
````json
{
  "round_number": 25,
  "seller_asks": {
    "Seller Amir": 97.39,
    "Seller Yara": 97.36,
    "Seller Eli": 96.87,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Ana": 79.64597941072213,
    "Buyer Kit": 80.40108447080641,
    "Buyer Omar": 80.29529699591419,
    "Buyer Nia": 79.77572642870675,
    "Buyer Mia": 79.44178471607566,
    "Buyer Lena": 79.81560442934902
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 26
````json
{
  "round_number": 26,
  "seller_asks": {
    "Seller Amir": 97.37,
    "Seller Yara": 97.36,
    "Seller Eli": 96.87,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Ana": 79.34051416207392,
    "Buyer Nia": 79.45637719763725,
    "Buyer Omar": 80.01933095125878,
    "Buyer Kit": 79.363057984111,
    "Buyer Mia": 79.23168286301804,
    "Buyer Lena": 80.40093630828292
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 27
````json
{
  "round_number": 27,
  "seller_asks": {
    "Seller Yara": 97.36,
    "Seller Maya": 98.0,
    "Seller Amir": 97.39,
    "Seller Eli": 96.88,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Nia": 79.36835888883297,
    "Buyer Omar": 79.23910416985436,
    "Buyer Kit": 79.92617235552939,
    "Buyer Lena": 79.80800433412134,
    "Buyer Ana": 80.27118349628928,
    "Buyer Mia": 80.05685334970664
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 28
````json
{
  "round_number": 28,
  "seller_asks": {
    "Seller Amir": 97.25,
    "Seller Eli": 96.87,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Omar": 80.41683983758827,
    "Buyer Kit": 80.48972763340157,
    "Buyer Ana": 79.53622482691921,
    "Buyer Mia": 79.88095832480789,
    "Buyer Lena": 79.23411620355935,
    "Buyer Nia": 80.29549858458714
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 29
````json
{
  "round_number": 29,
  "seller_asks": {
    "Seller Yara": 97.36,
    "Seller Amir": 97.34,
    "Seller Eli": 96.88,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Mia": 80.67298612706408,
    "Buyer Kit": 80.13014561153918,
    "Buyer Nia": 80.14614861072582,
    "Buyer Lena": 80.26126738551443,
    "Buyer Ana": 80.68620906502085,
    "Buyer Omar": 80.61029927036782
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 30
````json
{
  "round_number": 30,
  "seller_asks": {
    "Seller Yara": 97.36,
    "Seller Eli": 96.89,
    "Seller Maya": 98.0,
    "Seller Raj": 97.38
  },
  "buyer_bids": {
    "Buyer Omar": 79.23117261551869,
    "Buyer Ana": 80.73707191850485,
    "Buyer Lena": 80.30463151912117,
    "Buyer Kit": 79.38974556458605,
    "Buyer Mia": 79.78637252199151,
    "Buyer Nia": 79.96768440444689
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
