
## Auction Results: Round 1
````json
{
  "round_number": 1,
  "seller_asks": {},
  "buyer_bids": {
    "Buyer Jin": 79.77287899951199,
    "Buyer Amir": 80.74847999187227
  },
  "trades": [],
  "seller_messages": {
    "Seller Nia": "I will gather more information on potential buyers and adjust my ask price.",
    "Seller Jun": "No messages received from other sellers this hour."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 2
````json
{
  "round_number": 2,
  "seller_asks": {
    "Seller Jun": 98.02,
    "Seller Nia": 96.0
  },
  "buyer_bids": {
    "Buyer Jin": 79.54950836306436,
    "Buyer Amir": 80.62665705571308
  },
  "trades": [],
  "seller_messages": {
    "Seller Nia": "Hey everyone, I noticed the bid price has dropped to $79.77287899951199. I will adjust my ask price to $96.00 to attract more interest."
  },
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````

## Auction Results: Round 3
````json
{
  "round_number": 3,
  "seller_asks": {
    "Seller Jun": 98.04,
    "Seller Nia": 96.0
  },
  "buyer_bids": {
    "Buyer Amir": 79.42283792831704,
    "Buyer Jin": 79.42359325594668
  },
  "trades": [],
  "seller_messages": {},
  "buyer_messages": {},
  "overseer_visible_messages": null
}
````
